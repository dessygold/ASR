# Enterprise Gitops Application

[ArgoCD App-of-apps](https://argo-cd.readthedocs.io/en/stable/operator-manual/cluster-bootstrapping/#app-of-apps-pattern-alternative) Helm chart for the **Enterprise** system.

Deployed by the [argocd-spoke terraform module](https://code.cdso.army.mil/dsop/modules/argocd-spoke) and managed remotely by core's ArgoCD.

## Dev -> Test -> Prod Promotion

Each environment's ArgoCD instance tracks a different branch of this repo. Argo-dev tracks `dev`, argo-test tracks `test`, argo-prod tracks `prod`.

Environment-specific facts (`vpc_id`, `cluster_name`, `account_id`, etc.) are **not** committed here. They're passed in as Helm values by the [argocd-spoke terraform module](https://code.cdso.army.mil/dsop/modules/argocd-spoke) when it creates the `enterprise-gitops` Application, sourced from the AWS account data.

To promote a change, merge forward from `dev` -> `test` -> `prod`. ArgoCD will pick up the changes and apply them to the cluster.
