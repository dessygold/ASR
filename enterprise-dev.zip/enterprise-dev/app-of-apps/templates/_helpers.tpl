{{/* Template AC2SP AMI owner ID */}}
{{- define "ami_owner_id" -}}
  {{- if eq .Values.environment "dev" -}}
    "103873143660"
  {{- else -}}
    "091602470583"
  {{- end -}}
{{- end }}
