# Nexus IQ

Sonatype Nexus IQ Server (the foundational engine powering Sonatype Lifecycle and Firewall) is an enterprise Software Composition Analysis (SCA) and policy-enforcement platform designed to automate open-source software (OSS) governance across the entire Software Development Life Cycle (SDLC). Leveraging Sonatype’s proprietary intelligence database, the platform continuously scans codebases, dependencies, and container images to identify security vulnerabilities, license compliance risks, and architectural issues with high precision. Nexus IQ integrates directly into IDEs, SCMs, build tools, and binary repositories, enabling automated remediation—such as blocking malicious packages at the gateway, generating "Golden Pull Requests" for safe dependency upgrades, and establishing custom policy controls tailored to an organization's specific risk tolerances.

This application is deployed to Enterprise.

Project Labels:
- app::nexusiq

## References
- [source code repository](https://github.com/sonatype/docker-nexus-iq-server.git)
- [docker container repository](https://github.com/sonatype/docker-nexus-iq-server/tags)
- [helm chart repository](https://github.com/sonatype/helm3-charts)
- [official documentation](https://help.sonatype.com/en/sonatype-iq-server.html)
- [Sonatype guide](https://help.sonatype.com/en/sonatype-guide.html)

- [**DSOP**: applications terraform module](https://code.cdso.army.mil/dsop/modules/nexus-iq.git)

### Documentation

- [DEPLOYMENT.md](./docs/DEPLOYMENT.md)
- [BACKUP-RESTORE.md](./docs/BACKUP-RESTORE.md)
- [SECURITY.md](./docs/SECURITY.md)
- [TROUBLESHOOTING.md](./docs/TROUBLESHOOTING.md)
- [CDSO_STATUS.md](./docs/CDSO_STATUS.md)

## Reference Commands

```bash

helm repo add some-repo https://github.com/sonatype/docker-nexus-iq-server.git
helm repo update

...
```

### Database Storage
Use these commands to check the database storage in test and prod. Run these commands in the AWS CLI in their respective environments.

#### Test
```
DB="nexusiq-20260605034255695900000006"; ALLOC=$(aws rds describe-db-instances --db-instance-identifier $DB --query "DBInstances[0].AllocatedStorage" --output text); FREE_B=$(aws cloudwatch get-metric-statistics --namespace AWS/RDS --metric-name FreeStorageSpace --dimensions Name=DBInstanceIdentifier,Value=$DB --start-time $(date -u -d "15 minutes ago" +%Y-%m-%dT%H:%M:%SZ) --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) --period 300 --statistics Minimum --query "Datapoints[-1].Minimum" --output text); FREE_G=$(awk "BEGIN {print $FREE_B / 1024^3}"); USED_G=$(awk "BEGIN {print $ALLOC - $FREE_G}"); PCT=$(awk "BEGIN {print ($USED_G / $ALLOC) * 100}"); printf "\n[TEST] Database: %s\nAllocated: %s GiB\nFree Space: %.2f GiB\nUsed Space: %.2f GiB\nUtilization: %.2f%%\n\n" "$DB" "$ALLOC" "$FREE_G" "$USED_G" "$PCT"
```

#### Prod
```
DB="nexusiq-20260505173954628000000016"; ALLOC=$(aws rds describe-db-instances --db-instance-identifier $DB --query "DBInstances[0].AllocatedStorage" --output text); FREE_B=$(aws cloudwatch get-metric-statistics --namespace AWS/RDS --metric-name FreeStorageSpace --dimensions Name=DBInstanceIdentifier,Value=$DB --start-time $(date -u -d "15 minutes ago" +%Y-%m-%dT%H:%M:%SZ) --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) --period 300 --statistics Minimum --query "Datapoints[-1].Minimum" --output text); FREE_G=$(awk "BEGIN {print $FREE_B / 1024^3}"); USED_G=$(awk "BEGIN {print $ALLOC - $FREE_G}"); PCT=$(awk "BEGIN {print ($USED_G / $ALLOC) * 100}"); printf "\n[PROD] Database: %s\nAllocated: %s GiB\nFree Space: %.2f GiB\nUsed Space: %.2f GiB\nUtilization: %.2f%%\n\n" "$DB" "$ALLOC" "$FREE_G" "$USED_G" "$PCT"
```
