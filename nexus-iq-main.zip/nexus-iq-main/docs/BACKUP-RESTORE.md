# Backup & Restoration

Refer to the [Sonatype NexusIQ Backup Procedure guide](https://help.sonatype.com/en/backing-up-the-iq-server.html).

Ultimately there is no DSOP-specific backup procedure for this application. 