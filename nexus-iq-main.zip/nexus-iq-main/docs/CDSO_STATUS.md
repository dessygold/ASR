# cDSO Pipeline Status

## Container `N`
# Layer Scan
```
============================================================
 IMAGE SCAN REPORT
============================================================
 Image:    registry.cdso.army.mil/dsop/apps/nexus-iq/nexus-iq-server
 Platform: linux/amd64
 Size:     419.42 MB
 User:     nexus
============================================================
 STATUS SUMMARY
 [FAIL]   0 Critical Issues
 [WARN]   6 Warnings
 [SUPPRESSED] 0 Suppressed Findings
============================================================
 WARNINGS:
  - No HEALTHCHECK defined.
  - Package manager cache leftover lacks explicit justification: var/cache/yum
  - Package manager cache leftover lacks explicit justification: var/cache/yum/lock
  - Package manager cache leftover lacks explicit justification: var/cache/yum
  - Package manager cache leftover lacks explicit justification: var/cache/yum/metadata
  - Package manager cache leftover lacks explicit justification: var/cache/yum/solv
------------------------------------------------------------
============================================================
```

# Syft Grype Scan
```
[-] 56 unmitigated vulnerabilities
 »  CVE-2025-48924 (Medium)
    Description: Apache Commons Lang is vulnerable to Uncontrolled Recursion when processing long
    inputs
    Artifact: commons-lang
    - Current version: 2.6
    - Vulnerable version(s): >=2.0,<=2.6 (unknown)
    - Locations: /opt/sonatype/nexus-iq-server/jars/insight-brain-service-1.207.1-04-server.jar
 »  CVE-2026-18798 (Medium)
    Description: A flaw was found in OpenSSL. A malformed INITIAL packet with an invalid DCID (destination
    connection ID) can cause the QUIC server to double free the QRX object. This issue leads to memory corruption,
    causing the termination of the QUIC server process and resulting in a denial of service.
    Artifact: openssl
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): < 1:3.5.8-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: openssl-libs
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): < 1:3.5.8-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-63076 (Medium)
    Description: A flaw was found in OpenSSL. A crafted CMP (Certificate Management Protocol) message can
    cause an invalid pointer dereference due to a missing type check in the password-based protection verification. A
    remote, unauthenticated attacker can crash applications acting as a CMP server or client, resulting in a denial of
    service.
    Artifact: openssl
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): < 1:3.5.8-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: openssl-libs
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): < 1:3.5.8-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-19931 (Medium)
    Description: A flaw was found in libcurl. This vulnerability allows an attacker to reuse an HTTP
    connection set up for a given hostname using Negotiate authentication. When an initial request is made with empty
    credentials, a subsequent user's request can be sent over a previously authenticated connection belonging to another
    user. This could lead to information disclosure or unauthorized access to sensitive data.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-14456 (High)
    Description: A flaw was found in OpenSSL. A remote attacker could exploit this by sending a large
    number of QUIC Initial packets to an OpenSSL QUIC server. This can cause the server to allocate and queue new
    incoming channels without limit, leading to unbounded memory growth. The excessive memory consumption can result in
    a Denial of Service (DoS) condition, making the QUIC listener unavailable.
    Artifact: openssl
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): < 1:3.5.8-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: openssl-libs
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): < 1:3.5.8-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-63382 (High)
    Description: A flaw was found in libevent. The evhttp parser in libevent's http.c component
    inconsistently handles HTTP Transfer-Encoding headers and chunked framing. This inconsistency allows an
    unauthenticated remote attacker to desynchronize request boundaries when libevent is used behind a proxy. Successful
    exploitation could lead to request smuggling, potentially bypassing access controls or poisoning caches.
    Artifact: libevent
    - Current version: 2.1.12-8.el9_4
    - Vulnerable version(s): < 0:2.1.13-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-63072 (Medium)
    Description: A flaw was found in OpenSSL. A crafted CMS (Cryptographic Message Syntax) message can
    cause an 8-byte out-of-bounds heap write when it is decrypted with CMS_decrypt(). This issue occurs because the CMS
    decryption process incorrectly sizes the key-unwrap output buffer when using the AES-WRAP-PAD unwrap primitive. This
    can lead to memory corruption, resulting in a denial of service.
    Artifact: openssl
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): < 1:3.5.8-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: openssl-libs
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): < 1:3.5.8-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-49268 (High)
    Description: Apache Shiro: LDAP DN Injection in DefaultLdapRealm
    Artifact: shiro-core
    - Current version: 2.2.0
    - Vulnerable version(s): <2.2.1 (unknown)
    - Locations: /opt/sonatype/nexus-iq-server/jars/insight-brain-service-1.207.1-04-server.jar
 »  CVE-2026-11856 (Medium)
    Description: A flaw was found in curl. When `libcurl` performs a transfer to an HTTP origin using
    Digest authentication and then reuses the same connection handle for a subsequent transfer to a different origin, it
    may incorrectly send the authentication header intended for the first origin to the second. This could lead to
    unintended information disclosure, potentially allowing an attacker to gain unauthorized access to sensitive
    data.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-8924 (Medium)
    Description: A flaw was found in curl's cookie parsing logic. A malicious HTTP server can exploit this
    by setting 'super cookies' that bypass the Public Suffix List check. This allows an attacker-controlled origin to
    inject cookies that curl then transmits to unrelated third-party domains, leading to compromising request
    integrity.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-8927 (High)
    Description: A flaw was found in libcurl. When reusing a libcurl handle for sequential transfers with
    environment-variable proxy configuration, the library does not properly clear the proxy authentication state. This
    oversight can lead to the unintended disclosure of `Proxy-Authorization` headers to an incorrect proxy, potentially
    exposing sensitive authentication information to an unauthorized entity. This is an information disclosure
    vulnerability.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-6253 (Medium)
    Description: A flaw was found in curl. When curl is configured to use distinct proxies for different
    URL schemes, a redirect from a URL using an authenticated proxy to one using an unauthenticated proxy can
    inadvertently expose the initial proxy's credentials. This improper credential management (CWE-522) may allow an
    attacker to gain unauthorized access or information by intercepting these disclosed credentials.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-5773 (Medium)
    Description: A flaw was found in libcurl. Due to a logical error in the connection reuse mechanism for
    SMB (Server Message Block) transfers, libcurl might reuse an existing SMB connection with a different share than
    intended. This vulnerability, categorized as CWE-488 (Exposure of Data Element to Wrong Session), could lead to the
    download of an incorrect file or the upload of a file to an unintended location when an application uses libcurl for
    SMB transfers.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-70906 (High)
    Description: Vulnerability in Oracle Java SE (component: 2D).  Supported versions that are affected
    are Oracle Java SE: 25.0.4 and  26.0.2. Easily exploitable vulnerability allows unauthenticated attacker with
    network access via multiple protocols to compromise Oracle Java SE.  Successful attacks of this vulnerability can
    result in unauthorized ability to cause a hang or frequently repeatable crash (complete DOS) of Oracle Java SE.
    Note: This vulnerability can be exploited by using APIs in the specified Component, e.g., through a web service
    which supplies data to the APIs. This vulnerability also applies to Java deployments, typically in clients running
    sandboxed Java Web Start applications or sandboxed Java applets, that load and run untrusted code (e.g., code that
    comes from the internet) and rely on the Java sandbox for security. CVSS 3.1 Base Score 7.5 (Availability impacts).
    CVSS Vector: (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:H).
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): >= 22, < 25.0.4.1||>= 26, < 26.0.2.1 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2026-63387 (High)
    Description: A flaw was found in Libevent, an event notification library. An off-by-one stack buffer
    overflow exists in the `dnsname_to_labels` function when processing a name-bearing DNS record. A remote attacker
    could send a specially crafted DNS server response, which may lead to a crash or corruption of the process,
    resulting in a denial of service or potential information disclosure and integrity impact.
    Artifact: libevent
    - Current version: 2.1.12-8.el9_4
    - Vulnerable version(s): < 0:2.1.13-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-63385 (High)
    Description: A flaw was found in libevent. The evhttp_decode_uri_internal function in http.c decodes
    percent-encoded %00 bytes into literal NUL characters without rejecting them, allowing an attacker to craft a URI
    such as /admin/secret%00.jpg where extension-based access checks see .jpg but the server processes /admin/secret,
    bypassing path-based access controls. Additionally, evhttp_header_is_valid_value accepts obsolete HTTP header line
    folding (CRLF followed by SP/HT), which RFC 9112 states new implementations should reject, creating a header
    injection vector in proxy chains where the frontend rejects obs-fold but libevent accepts it. This could lead to
    access control bypass, header injection, or request smuggling.
    Artifact: libevent
    - Current version: 2.1.12-8.el9_4
    - Vulnerable version(s): < 0:2.1.13-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-6429 (Medium)
    Description: A flaw was found in libcurl. When configured to use a .netrc file for credentials and
    follow HTTP redirects, libcurl can inadvertently send the password from the initial connection to the redirected
    host. This sensitive information disclosure occurs when both the original and redirect URLs use clear text HTTP, are
    performed over the same HTTP proxy, and the same connection is reused. This vulnerability, categorized as an
    Exposure of Sensitive Information to an Unauthorized Actor (CWE-200), could allow an attacker to obtain user
    credentials.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-63379 (Medium)
    Description: A flaw was found in Libevent, an event notification library. An unauthenticated remote
    attacker can exploit a vulnerability where chunked HTTP (Hypertext Transfer Protocol) trailers are incorrectly
    merged into request headers. This allows the attacker to place security-sensitive fields in trailers, causing an
    upstream proxy and the Libevent application to interpret different effective headers. This can lead to header
    smuggling, authorization bypass, proxy-header spoofing, or cache poisoning.
    Artifact: libevent
    - Current version: 2.1.12-8.el9_4
    - Vulnerable version(s): < 0:2.1.13-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-86145 (High)
    Description: A flaw was found in PCRE2. An out-of-bounds write vulnerability exists in the
    `pcre2_dfa_match` function due to improper size checking when reusing cached workspace blocks. A remote attacker
    could exploit this by providing a specially crafted regular expression or a recursive pattern in conjunction with a
    small heap limit. This could lead to data corruption or potentially arbitrary code execution, compromising the
    integrity and availability of the system.
    Artifact: pcre2
    - Current version: 10.40-6.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: pcre2-syntax
    - Current version: 10.40-6.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-8458 (High)
    Description: A flaw was found in libcurl. A logical error in the connection pooling mechanism may
    cause libcurl to reuse an authenticated connection for an unintended service. This could allow an application to
    wrongfully reuse an existing connection to the same server that was authenticated for a different service,
    potentially leading to unauthorized access or information disclosure.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-63384 (High)
    Description: A flaw was found in Libevent. An incorrect integer conversion in the
    `evtag_unmarshal_header` function allows a remote attacker to provide a specially crafted payload length. This can
    lead to a wrapped large allocation request, resulting in a denial of service (DoS) for the affected system.
    Artifact: libevent
    - Current version: 2.1.12-8.el9_4
    - Vulnerable version(s): < 0:2.1.13-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-63383 (High)
    Description: A flaw was found in Libevent, an event notification library. A remote attacker could
    exploit an out-of-bounds read vulnerability in the `decode_tag_internal()` function by sending specially crafted,
    attacker-controlled tagged RPC (Remote Procedure Call) data. This could lead to a denial of service, causing the
    process that decodes the data to crash.
    Artifact: libevent
    - Current version: 2.1.12-8.el9_4
    - Vulnerable version(s): < 0:2.1.13-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-2673 (Medium)
    Description: A key group selection preference flaw has been discovered in OpenSSL. An OpenSSL TLS 1.3
    server may fail to negotiate the expected preferred key exchange group when its key exchange group configuration
    includes the default by using the "DEFAULT" keyword. A less preferred key exchange may be used even when a more
    preferred group is supported by both client and server, if the group was not included among the client's initial
    predicated keyshares. This will sometimes be the case with the new hybrid post-quantum groups, if the client chooses
    to defer their use until specifically requested by the server. No OpenSSL FIPS modules are affected by this issue,
    the code in question lies outside the FIPS boundary.
    Artifact: openssl
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: openssl-fips-provider
    - Current version: 3.0.7-11.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: openssl-fips-provider-so
    - Current version: 3.0.7-11.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: openssl-libs
    - Current version: 1:3.5.5-6.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-8932 (Medium)
    Description: A flaw was found in curl. The libcurl library, used for transferring data with URLs,
    could improperly reuse existing network connections. This occurred even when changes to mutual Transport Layer
    Security (mTLS) settings, particularly those for client certificates, should have prevented such reuse. This issue
    could lead to a security feature bypass, where a client might use a connection with an unintended or weaker security
    configuration, potentially compromising the integrity or confidentiality of data.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-7168 (Medium)
    Description: A flaw was found in libcurl. When a user performs a transfer over an HTTP proxy using
    Digest authentication and then reuses the same handle for a second transfer with a different proxy host, libcurl
    incorrectly sends the `Proxy-Authorization` header intended for the first proxy to the second proxy. This could lead
    to the disclosure of sensitive authentication information to an unintended proxy, potentially allowing an attacker
    to gain unauthorized access or impersonate the user.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-41254 (High)
    Description: Little CMS (lcms2) through 2.18 has an integer overflow in CubeSize in cmslut.c because
    the overflow check is performed after the multiplication.
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): < 1.8.0_502||>= 1.9, < 8.0.502||>= 12, < 17.0.20||>= 18, < 21.0.12||>= 22, <
    25.0.4||>= 26, < 26.0.2||>= 9, < 11.0.32 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2026-5545 (Medium)
    Description: A flaw was found in libcurl. An application using libcurl that performs an authenticated
    HTTP(S) request after a Negotiate-authenticated one to the same host may incorrectly reuse the previous connection.
    This authentication bypass vulnerability allows the second request to be sent over a connection authenticated with
    different credentials, potentially leading to unauthorized access or information disclosure.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-3784 (Medium)
    Description: A flaw was found in curl. This vulnerability allows curl to wrongly reuse an existing
    HTTP proxy connection when performing a CONNECT request to a server, even if the new request uses different
    authentication credentials for the HTTP proxy. This improper connection reuse could lead to an attacker gaining
    unauthorized access to resources or information intended for a different user.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-80489 (Medium)
    Description: A flaw was found in glibc. A remote attacker could exploit this vulnerability by
    providing specially crafted input during SHIFT_JISX0213 to UCS-4 text conversion. This crafted input can cause the
    application to repeatedly process a buffered character without consuming further input, leading to a persistent loop
    and a denial of service (DoS) condition. This could make the affected application unresponsive.
    Artifact: glibc
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-common
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-langpack-en
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-minimal-langpack
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2025-48386 (Medium)
    Description: A credential handling flaw has been discovered in git. The wincred credential helper uses
    a static buffer (target) as a unique key for storing and comparing against internal storage. This credential helper
    does not properly bounds check the available space remaining in the buffer before appending to it with wcsncat(),
    which can lead to buffer overflows.
    Artifact: git-core
    - Current version: 2.52.0-1.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-47063 (High)
    Description: Vulnerability in the Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition product of Oracle Java SE (component: Libraries).  Supported versions that are affected are Oracle Java SE:
    8u491, 8u491-perf, 11.0.31, 17.0.19, 21.0.11, 25.0.3, 26.0.1; Oracle GraalVM for JDK: 17.0.19 and  21.0.11; Oracle
    GraalVM Enterprise Edition: 21.3.18. Easily exploitable vulnerability allows unauthenticated attacker with network
    access via multiple protocols to compromise Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition.  Successful attacks of this vulnerability can result in  unauthorized creation, deletion or modification
    access to critical data or all Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition accessible
    data. Note: This vulnerability can be exploited by using APIs in the specified Component, e.g., through a web
    service which supplies data to the APIs. This vulnerability also applies to Java deployments, typically in clients
    running sandboxed Java Web Start applications or sandboxed Java applets, that load and run untrusted code (e.g.,
    code that comes from the internet) and rely on the Java sandbox for security. CVSS 3.1 Base Score 7.5 (Integrity
    impacts).  CVSS Vector: (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:H/A:N).
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): < 1.8.0_502||>= 1.9, < 8.0.502||>= 12, < 17.0.20||>= 18, < 21.0.12||>= 22, <
    25.0.4||>= 26, < 26.0.2||>= 9, < 11.0.32 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2026-61308 (Medium)
    Description: Vulnerability in the Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition product of Oracle Java SE (component: Networking).  Supported versions that are affected are Oracle Java SE:
    8u501, 11.0.32, 17.0.20, 21.0.12, 25.0.4, 26.0.2; Oracle GraalVM for JDK: 17.0.20 and  21.0.12; Oracle GraalVM
    Enterprise Edition: 21.3.19. Difficult to exploit vulnerability allows unauthenticated attacker with network access
    via HTTP to compromise Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition.  While the
    vulnerability is in Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition, attacks may
    significantly impact additional products (scope change).  Successful attacks of this vulnerability can result in
    unauthorized access to critical data or complete access to all Oracle Java SE, Oracle GraalVM for JDK, Oracle
    GraalVM Enterprise Edition accessible data. Note: This vulnerability can be exploited by using APIs in the specified
    Component, e.g., through a web service which supplies data to the APIs. This vulnerability also applies to Java
    deployments, typically in clients running sandboxed Java Web Start applications or sandboxed Java applets, that load
    and run untrusted code (e.g., code that comes from the internet) and rely on the Java sandbox for security. CVSS 3.1
    Base Score 6.8 (Confidentiality impacts).  CVSS Vector: (CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:C/C:H/I:N/A:N).
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): < 1.8.0_504||>= 1.9, < 8.0.504||>= 12, < 17.0.20.1||>= 18, < 21.0.12.1||>=
    22, < 25.0.4.1||>= 26, < 26.0.2.1||>= 9, < 11.0.32.1 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2026-4873 (Medium)
    Description: A flaw was found in curl. A remote attacker could exploit this by initiating an
    unencrypted connection (via IMAP, SMTP, or POP3) and then making a subsequent request to the same host that requires
    Transport Layer Security (TLS). Due to incorrect connection reuse, the subsequent request would bypass the TLS
    requirement, leading to the transmission of sensitive information in cleartext. This vulnerability, categorized as
    Cleartext Transmission of Sensitive Information (CWE-319), results in information disclosure.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-60147 (Medium)
    Description: Vulnerability in the Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition product of Oracle Java SE (component: Security).  Supported versions that are affected are Oracle Java SE:
    8u491, 8u491-perf, 11.0.31, 17.0.19, 21.0.11, 25.0.3, 26.0.1; Oracle GraalVM for JDK: 17.0.19 and  21.0.11; Oracle
    GraalVM Enterprise Edition: 21.3.18. Easily exploitable vulnerability allows unauthenticated attacker with network
    access via multiple protocols to compromise Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition.  Successful attacks of this vulnerability can result in  unauthorized update, insert or delete access to
    some of Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition accessible data as well as
    unauthorized read access to a subset of Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition
    accessible data. Note: This vulnerability can be exploited by using APIs in the specified Component, e.g., through a
    web service which supplies data to the APIs. This vulnerability also applies to Java deployments, typically in
    clients running sandboxed Java Web Start applications or sandboxed Java applets, that load and run untrusted code
    (e.g., code that comes from the internet) and rely on the Java sandbox for security. CVSS 3.1 Base Score 6.5
    (Confidentiality and Integrity impacts).  CVSS Vector: (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N).
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): < 1.8.0_502||>= 1.9, < 8.0.502||>= 12, < 17.0.20||>= 18, < 21.0.12||>= 22, <
    25.0.4||>= 26, < 26.0.2||>= 9, < 11.0.32 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2026-46968 (Medium)
    Description: Vulnerability in Oracle Java SE (component: JSSE).  Supported versions that are affected
    are Oracle Java SE: 8u491, 8u491-perf, 11.0.31, 17.0.19, 21.0.11, 25.0.3, 26.0.1; Oracle GraalVM for JDK: 17.0.19
    and  21.0.11; Oracle GraalVM Enterprise Edition: 21.3.18. Difficult to exploit vulnerability allows unauthenticated
    attacker with network access via TLS to compromise Oracle Java SE.  Successful attacks of this vulnerability can
    result in  unauthorized creation, deletion or modification access to critical data or all Oracle Java SE accessible
    data. Note: This vulnerability can only be exploited by supplying data to APIs in the specified Component without
    using Untrusted Java Web Start applications or Untrusted Java applets, such as through a web service. CVSS 3.1 Base
    Score 5.9 (Integrity impacts).  CVSS Vector: (CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:H/A:N).
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): < 1.8.0_502||>= 1.9, < 8.0.502||>= 12, < 17.0.20||>= 18, < 21.0.12||>= 22, <
    25.0.4||>= 26, < 26.0.2||>= 9, < 11.0.32 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2026-8674 (Medium)
    Description: A flaw was found in the GNU C Library (glibc) DNS stub resolver. This vulnerability
    allows a remote attacker on the local network to cause a denial of service by providing a specially crafted,
    excessively long search domain. When the resolver attempts to initialize with this long domain from /etc/resolv.conf
    or the LOCALDOMAIN environment variable, it triggers an assertion failure, which aborts the process. This can be
    exploited without privileges on the target system, potentially through network configuration mechanisms like DHCP or
    a VPN server.
    Artifact: glibc
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-common
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-langpack-en
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-minimal-langpack
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-47021 (Medium)
    Description: Vulnerability in the Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition product of Oracle Java SE (component: 2D).  Supported versions that are affected are Oracle Java SE: 8u491,
    8u491-perf, 11.0.31, 17.0.19, 21.0.11, 25.0.3, 26.0.1; Oracle GraalVM for JDK: 17.0.19 and  21.0.11; Oracle GraalVM
    Enterprise Edition: 21.3.18. Easily exploitable vulnerability allows unauthenticated attacker with network access
    via multiple protocols to compromise Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition.
    Successful attacks of this vulnerability can result in unauthorized ability to cause a partial denial of service
    (partial DOS) of Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition. Note: This vulnerability
    can be exploited by using APIs in the specified Component, e.g., through a web service which supplies data to the
    APIs. This vulnerability also applies to Java deployments, typically in clients running sandboxed Java Web Start
    applications or sandboxed Java applets, that load and run untrusted code (e.g., code that comes from the internet)
    and rely on the Java sandbox for security. CVSS 3.1 Base Score 5.3 (Availability impacts).  CVSS Vector:
    (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L).
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): < 1.8.0_502||>= 1.9, < 8.0.502||>= 12, < 17.0.20||>= 18, < 21.0.12||>= 22, <
    25.0.4||>= 26, < 26.0.2||>= 9, < 11.0.32 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2026-46917 (Medium)
    Description: Vulnerability in the Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition product of Oracle Java SE (component: JSSE).  Supported versions that are affected are Oracle Java SE:
    11.0.31, 17.0.19, 21.0.11, 25.0.3, 26.0.1; Oracle GraalVM for JDK: 17.0.19 and  21.0.11; Oracle GraalVM Enterprise
    Edition: 21.3.18. Easily exploitable vulnerability allows unauthenticated attacker with network access via TLS to
    compromise Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition.  Successful attacks of this
    vulnerability can result in unauthorized ability to cause a partial denial of service (partial DOS) of Oracle Java
    SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition. Note: This vulnerability can only be exploited by
    supplying data to APIs in the specified Component without using Untrusted Java Web Start applications or Untrusted
    Java applets, such as through a web service. CVSS 3.1 Base Score 5.3 (Availability impacts).  CVSS Vector:
    (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L).
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): >= 12, < 17.0.20||>= 18, < 21.0.12||>= 22, < 25.0.4||>= 26, < 26.0.2||>= 9, <
    11.0.32 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2026-47027 (Medium)
    Description: Vulnerability in Oracle Java SE (component: Libraries).  Supported versions that are
    affected are Oracle Java SE: 8u491, 8u491-perf, 11.0.31, 17.0.19, 21.0.11, 25.0.3, 26.0.1; Oracle GraalVM for JDK:
    17.0.19 and  21.0.11; Oracle GraalVM Enterprise Edition: 21.3.18. Easily exploitable vulnerability allows
    unauthenticated attacker with network access via multiple protocols to compromise Oracle Java SE.  Successful
    attacks of this vulnerability can result in unauthorized ability to cause a partial denial of service (partial DOS)
    of Oracle Java SE. Note: This vulnerability can be exploited by using APIs in the specified Component, e.g., through
    a web service which supplies data to the APIs. This vulnerability also applies to Java deployments, typically in
    clients running sandboxed Java Web Start applications or sandboxed Java applets, that load and run untrusted code
    (e.g., code that comes from the internet) and rely on the Java sandbox for security. CVSS 3.1 Base Score 5.3
    (Availability impacts).  CVSS Vector: (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L).
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): < 1.8.0_502||>= 1.9, < 8.0.502||>= 12, < 17.0.20||>= 18, < 21.0.12||>= 22, <
    25.0.4||>= 26, < 26.0.2||>= 9, < 11.0.32 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2026-70907 (Medium)
    Description: Vulnerability in the Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition product of Oracle Java SE (component: JSSE).  Supported versions that are affected are Oracle Java SE:
    8u501, 11.0.32, 17.0.20, 21.0.12, 25.0.4, 26.0.2; Oracle GraalVM for JDK: 17.0.20 and  21.0.12; Oracle GraalVM
    Enterprise Edition: 21.3.19. Easily exploitable vulnerability allows unauthenticated attacker with network access
    via TLS to compromise Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition.  Successful attacks
    of this vulnerability can result in unauthorized ability to cause a partial denial of service (partial DOS) of
    Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition. Note: This vulnerability can only be
    exploited by supplying data to APIs in the specified Component without using Untrusted Java Web Start applications
    or Untrusted Java applets, such as through a web service. CVSS 3.1 Base Score 5.3 (Availability impacts).  CVSS
    Vector: (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L).
    Artifact: openjdk
    - Current version: 25.0.3
    - Vulnerable version(s): < 1.8.0_504||>= 1.9, < 8.0.504||>= 12, < 17.0.20.1||>= 18, < 21.0.12.1||>=
    22, < 25.0.4.1||>= 26, < 26.0.2.1||>= 9, < 11.0.32.1 (jvm)
    - Locations: /opt/sonatype/nexus-iq-server/release
 »  CVE-2025-13034 (Medium)
    Description: A flaw was found in curl. When configured to use public key pinning with QUIC connections
    and GnuTLS, and with standard certificate verification explicitly disabled, curl could bypass the intended public
    key check. This oversight allows a malicious server to impersonate a legitimate one, potentially leading to
    unauthorized access or information disclosure due to a failure in verifying the server's identity.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-11850 (Medium)
    Description: An integer underflow vulnerability was found in MIT krb5 in the berval2tl_data() function
    in plugins/kdb/ldap/libkdb_ldap/ldap_principal2.c. The function performs an unsigned subtraction (bv_len - 2)
    without a prior bounds check. When bv_len is 0 or 1, the subtraction wraps to a large value which is then truncated
    to uint16_t, yielding 0xFFFE (65534) or 0xFFFF (65535). The subsequent malloc succeeds and memcpy reads up to 65534
    bytes from a 0-1 byte buffer, resulting in a heap out-of-bounds read. The attack vector involves a malicious or
    compromised LDAP KDB backend returning a krbExtraData attribute with bv_len < 2, triggering the underflow when the
    KDC or kadmind reads principal data.
    Artifact: krb5-libs
    - Current version: 1.21.1-10.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-19542 (Medium)
    Description: A flaw was found in glibc. An out-of-bounds array write vulnerability exists within the
    `tdelete` function. This issue occurs due to incorrect management of array sizes, which can lead to memory
    corruption. A local attacker with low privileges could potentially exploit this to cause a denial of service or
    disclose sensitive information.
    Artifact: glibc
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-common
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-langpack-en
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-minimal-langpack
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-89158 (Medium)
    Description: A flaw was found in PCRE2. On 32-bit platforms, an integer overflow in the
    `pcre2_compile_32` function can lead to an out-of-bounds write. This vulnerability could allow a remote attacker to
    achieve a high integrity impact and a low availability impact, potentially leading to data corruption or denial of
    service.
    Artifact: pcre2
    - Current version: 10.40-6.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: pcre2-syntax
    - Current version: 10.40-6.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-89157 (Medium)
    Description: A flaw was found in PCRE2. On 32-bit platforms, an attacker can provide a specially
    crafted large pattern, leading to an out-of-bounds write within the pcre2_pattern_convert function. This
    vulnerability can result in high integrity impact, such as data corruption, and potentially a low availability
    impact, causing a denial of service.
    Artifact: pcre2
    - Current version: 10.40-6.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: pcre2-syntax
    - Current version: 10.40-6.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-6791 (Medium)
    Description: A flaw was found in glibc. When processing paths that start with a tilde (~) followed by
    a username, the `wordexp` function can be forced to allocate an excessive amount of memory on the program's stack. A
    remote attacker could exploit this by providing a very long username, leading to a stack exhaustion and causing a
    denial of service (DoS) for the affected application.
    Artifact: glibc
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-common
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-langpack-en
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-minimal-langpack
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-63388 (High)
    Description: A flaw was found in Libevent. A heap out-of-bounds write vulnerability in the
    `bufferevent_socket_set_conn_address_` function allows an unauthenticated local peer to achieve arbitrary code
    execution. By connecting to an AF_UNIX listener, an attacker can overwrite critical heap data, leading to memory
    corruption and potentially full control over the affected system. This can severely impact the confidentiality,
    integrity, and availability of data and services.
    Artifact: libevent
    - Current version: 2.1.12-8.el9_4
    - Vulnerable version(s): < 0:2.1.13-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-89092 (Medium)
    Description: A flaw was found in glibc, specifically within the nscd service. A remote attacker,
    operating a malicious Domain Name System (DNS) server, could send an overly large DNS response. This could trigger a
    stack overflow in the nscd service, causing it to crash and leading to degraded DNS resolution for the system. There
    is also a remote possibility of nscd cache corruption.
    Artifact: glibc
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-common
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-langpack-en
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-minimal-langpack
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-89161 (High)
    Description: A flaw was found in PCRE2, a library for processing regular expressions. The
    `pcre2_jit_match` function, which handles just-in-time (JIT) compilation for regular expressions, incorrectly
    manages memory when processing certain inputs. This memory corruption vulnerability could allow a local attacker to
    cause the application to crash, leading to a denial of service, or potentially execute unauthorized code.
    Artifact: pcre2
    - Current version: 10.40-6.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: pcre2-syntax
    - Current version: 10.40-6.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-5958 (Medium)
    Description: A Time-of-Check Time-of-Use (TOCTOU) race condition was found in GNU sed. When the -i
    (in-place) and --follow-symlinks options are used together, sed resolves the symlink but reopens the path for
    writing. An attacker with write access to the directory containing the symlink can swap it between the check and the
    open operations. If a privileged user executes sed in this manner on a path influenced by the attacker, it can lead
    to arbitrary file overwrites and potential privilege escalation.
    Artifact: sed
    - Current version: 4.8-10.el9
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-18374 (Medium)
    Description: A flaw was found in the GNU C Library (glibc). This vulnerability could allow an attacker
    with local access to trigger a heap buffer overflow by manipulating how the `fopen` function handles certain input.
    This could lead to minor disruptions in system operations or limited access to sensitive information.
    Artifact: glibc
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-common
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-langpack-en
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-minimal-langpack
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-56391 (Medium)
    Description: A flaw was found in GNU coreutils uniq. When processing specially crafted multibyte input
    with the --check-chars option, an attacker can trigger an out-of-bounds read. This vulnerability can lead to a
    denial of service (DoS) due to an application crash and potentially expose sensitive information from adjacent
    memory.
    Artifact: coreutils-single
    - Current version: 8.32-41.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-63381 (Medium)
    Description: A flaw was found in Libevent, an event notification library. A use-after-free
    vulnerability exists in the `evbuffer_add_buffer_reference` function when it processes an output buffer with a zero
    length. This can lead to a dangling pointer, which an attacker could exploit to cause memory corruption or crash the
    application.
    Artifact: libevent
    - Current version: 2.1.12-8.el9_4
    - Vulnerable version(s): < 0:2.1.13-1.el9_8 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-56392 (Medium)
    Description: A flaw was found in GNU coreutils, specifically in the `unexpand` utility. This
    vulnerability, a heap-based buffer overflow, occurs due to an integer overflow when `unexpand` processes unusually
    large tab stop values provided by a local attacker. This can lead to an undersized memory buffer, allowing
    subsequent operations to write beyond its boundaries. Successful exploitation can cause the `unexpand` utility to
    crash, potentially resulting in a denial of service or enabling further memory manipulation.
    Artifact: coreutils-single
    - Current version: 8.32-41.el9_8
    - Vulnerable version(s): < 0:8.32-41.el9_8.1 (rpm)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2025-14017 (Medium)
    Description: A flaw was found in curl. When performing multi-threaded LDAPS (Lightweight Directory
    Access Protocol Secure) transfers, changes to Transport Layer Security (TLS) options in one thread could
    inadvertently apply globally, affecting other concurrent transfers. This could lead to unintended security posture
    changes, such as disabling certificate verification for other threads. This vulnerability can result in a security
    bypass, where expected security checks are not performed.
    Artifact: curl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: libcurl-minimal
    - Current version: 7.76.1-40.el9_8.5
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
 »  CVE-2026-6368 (Medium)
    Description: A flaw was found in glibc (GNU C Library). A local attacker or application using the
    wordexp function with the WRDE_APPEND flag can trigger the interface to return invalid memory in the we_wordv
    member. This invalid memory, when subsequently processed by wordfree, may cause the process to abort, leading to a
    Denial of Service (DoS).
    Artifact: glibc
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-common
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-langpack-en
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
    Artifact: glibc-minimal-langpack
    - Current version: 2.34-275.el9_8
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/rpm/rpmdb.sqlite
[✓] 0 non applicable vulnerabilities
[✓] 0 mitigated vulnerabilities
[•] 35 suppressed vulnerabilities
 »  CVE-2024-7264 (Low)
 »  CVE-2024-9681 (Low)
 »  CVE-2025-9232 (Low)
 »  CVE-2024-11053 (Low)
 »  CVE-2026-14457 (Low)
 »  CVE-2024-41996 (Low)
 »  CVE-2022-41409 (Low)
 »  CVE-2023-50495 (Low)
 »  CVE-2026-63073 (Low)
 »  CVE-2026-28388 (Low)
 »  CVE-2022-27943 (Low)
 »  CVE-2026-28389 (Low)
 »  CVE-2025-14524 (Low)
 »  CVE-2026-18924 (Low)
 »  CVE-2025-15079 (Low)
 »  CVE-2026-54874 (Low)
 »  CVE-2026-63074 (Low)
 »  CVE-2026-63075 (Low)
 »  CVE-2021-46195 (Low)
 »  CVE-2024-13176 (Low)
 »  CVE-2026-28387 (Low)
 »  CVE-2025-15224 (Low)
 »  CVE-2026-82209 (Low)
 »  CVE-2026-31789 (Low)
 »  CVE-2026-47059 (Low)
 »  CVE-2026-6276 (Low)
 »  CVE-2026-60589 (Low)
 »  CVE-2026-47010 (Low)
 »  CVE-2026-75803 (Low)
 »  CVE-2026-27171 (Low)
 »  CVE-2026-89160 (Low)
 »  CVE-2026-89156 (Low)
 »  CVE-2026-18743 (Low)
 »  CVE-2026-18739 (Low)
 »  CVE-2026-18839 (Low)
```
