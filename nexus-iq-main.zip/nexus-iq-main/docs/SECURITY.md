# Security

At this time, we are required to deploy this application to DSOP. Because of this requirement, all known risks with Confluence are automatically assumed with the condition that the application stay updated to the most recently released version.