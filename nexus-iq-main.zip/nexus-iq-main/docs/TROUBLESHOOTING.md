# Troubleshooting

This document describes troubleshooting, scripts, tips and tricks for managing this application.

## Scenario `N`

**For General Troubleshooting**: When troubleshooting general problems.

**response**: [Sonatype Help](https://help.sonatype.com/index.html?lang=en)

### NexusIQ SAML Login Hanging on nexusiq.dso.army.mil/saml/Login

- https://[nexusiq-instance].dso.army.mil/assets/index.html#/saml

Ensure that:

```
<md:SingleSignOnService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect" Location="https://keycloak-test.dso.army.mil/realms/DSOPTestEnv/protocol/saml"/>
```

Appears **before** the HTTP-POST option

** Example **
```
<md:SingleSignOnService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect" Location="https://keycloak.dso.army.mil/realms/DSOP/protocol/saml"/>
<md:SingleSignOnService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" Location="https://keycloak.dso.army.mil/realms/DSOP/protocol/saml"/>
```

### Need a NexusIQ-Server image that is not listed in the vendor's values.yaml file.
Occasionally, Sonatype will release a new container version without updating the helm charts. E.g., helm chart version 208.0 might list container 1.208.0. Sonatype will release container 1.208.1 but NOT update the helm chart.

When this happens, you can refer to the value-overrides.yaml file in the root directory of the NexusIQ project. Update the tag to the container version you need, run a new pipeline, and use the following variable:

HELM_VALUES_FILE || values-override.yaml