# Deployment
- Helm charts are pulled from https://github.com/sonatype/docker-nexus-iq-server.git.
- Containers are pulled from https://hub.docker.com/r/sonatype/nexus-iq-server/tags.
- We use default-helm-values.yaml, values.yaml, and values-[env].yaml to deploy to Test and Prod.
- Containers are deployed as appname-# and increase sequentially with the number of replicas.

## Prerequisite Infrastructure
- Terraform creates a PostgreSQL database for this application.
- Nodes are labeled with **enterprise-stateful**. The values.yaml file specifically uses this label for its nodeSelector:
```
nodeSelector:
  workload: enterprise-stateful
```
- Nodes are tainted with **enterprise-stateful**. The values.yaml file specifically uses this label for its toleration:
```
tolerations:
  - key: "dedicated"
    operator: "Equal"
    value: "enterprise-stateful"
    effect: "NoSchedule"
```

## Networking Requirements
- This application utilizes the AWS ALB. Ingress configuration can be found in the yaml files.
- Test and Prod all use the AWS ingress, though the ARN is slightly different for each. You will notice that values-test.yaml and values-prod.yaml each have a similar ingress entry with different numeric characters.

## Security Considerations
- None. Because we are required to deploy this application in DSOP, all risk is assumed.
- DSOP does have a responsibility to ensure the latest version of the application is deployed.
- Application upgrades typically occur every two weeks. In the event of a critical security risk, upgrades will be performed as soon as the vendor publishes a fix.

## Authentication Configuration
- Authentication is performed through Keycloak >> EAMS-A.
- Keycloak Production handles all dev, test, and production logins for MOST applications. Currently, all Keycloak logins are stored in the DSOP realm, though we are currently working to separate test and dev logins into corresponding realms inside Keycloak prod.
- Keycloak authentication information -- including required URLs for successful authentication pairing -- can be found [here](https://keycloak.dso.army.mil/admin/master/console/#/DSOP/realm-settings).

## Integrations
- Integrated with Nexus. There are in-app configurations required -- like pointing Nexus at the NexusIQ URL -- to setup this integration but the process is mostly painless.
- NexusIQ will not identify the Nexus application until a pull is performed through the Nexus repository.

## Application Version Upgrade Process
1. Run a new pipeline to identify containers.
2. If there is an available upgrade, pipeline will push the new container version to AWS Core-Test.
3. Review application patch notes for any breaking changes.
4. Update the values-test.yaml file with the new container tag.
5. Use ArgoCD-Test to refresh the application.
6. Monitor for successful deployment.
7. Repeat steps 4, 5, and 6 in values-prod.yaml; refresh with ArgoCD-Prod.

## Helm Chart Version Upgrade Process
1. Run a new pipeline to identify helm charts.
2. If there is an available upgrade, pipeline will push the new container version to AWS Core-Test and create a work item in Gitlab.
3. Review patch notes for any breaking changes.
4. In Gitlab, replace the default-helm-values.yaml values with the latest version's values. NOTE: This file is for reference only. It does not impact the deployment of your application.
5. Navigate to the [Deployment repository](https://code.cdso.army.mil/dsop/deploy/gitops/enterprise/-/tree/dev/app-of-apps/templates?ref_type=heads) and cut a new branch off **dev**.
6. In your new branch, update values with the proper ECR location and targetRevision (i.e. your latest helm chart version).
```
  sources:
    - repoURL: 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com # core-test
      chart: charts/
      targetRevision:
```
7. Merge your branch with the **dev** branch.
8. Resync/refresh the dev deployment in ArgoCD. Monitor for successful deployment.
9. In the Deployment repository, create a Merge Request to merge **dev** into **test**. Complete the merge.
10. Proceed to ArgoCD-Test. Resync/refresh the deployment. Monitor for successful deployment.
11. In the Deployment repository, create a Merge Request to merge **test** into **prod**. Complete the merge.
12. Navigate to ArgoCD-Prod. Refresh/resync the deployment. Monitor for successful deployment.