# manually created secrets

for evaluation only. 

future plan is to create random secrets in the terraform module, push into AWS Secrets Manager and pull with `ExternalSecret`.


run these commnads before applying helm chart values

```bash

kubectl create secret generic nexusiq-admin-creds -n nexusiq \
  --from-literal=password="$(head -c 64 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 32)"

kubectl create secret generic nexusiq-truststore-creds -n nexusiq \
  --from-literal=password="$(head -c 96 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 32)"

```


# push JMX exporter jar into ECR and mount as volume

need to create pipeline for this...

```bash
# run on core-test mgmt node
brew install crane

mkdir -p /tmp/jmx-agent && cd /tmp/jmx-agent

curl -fsSLO https://repo1.maven.org/maven2/io/prometheus/jmx/jmx_prometheus_javaagent/1.0.1/jmx_prometheus_javaagent-1.0.1.jar
curl -fsSLO https://repo1.maven.org/maven2/io/prometheus/jmx/jmx_prometheus_javaagent/1.0.1/jmx_prometheus_javaagent-1.0.1.jar.sha1

# validate checksum, expect OK
echo "$(cat jmx_prometheus_javaagent-1.0.1.jar.sha1)  jmx_prometheus_javaagent-1.0.1.jar" | sha1sum -c -

# convert to layer for crane
mv jmx_prometheus_javaagent-1.0.1.jar jmx_prometheus_javaagent.jar
tar --owner=0 --group=0 -cf layer.tar jmx_prometheus_javaagent.jar

# crane push to ecr
aws ecr get-login-password --region us-gov-west-1 | crane auth login 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com -u AWS --password-stdin
crane append -f layer.tar -t 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/artifacts/jmx-exporter-agent:1.0.1
crane mutate 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/artifacts/jmx-exporter-agent:1.0.1 --set-platform linux/amd64

# verify platform and jar is at image root, expect { "os": "linux", "architecture": "amd64" }
crane config 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/artifacts/jmx-exporter-agent:1.0.1 | jq '{os,architecture}'
# expect jmx_prometheus_javaagent.jar
crane export 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/artifacts/jmx-exporter-agent:1.0.1 - | tar -tf -

```

test with pod: apply manifest, run `k logs oci-vol-test -n nexusiq` and expect `/opt/jmx/jmx_prometheus_javaagent.jar`

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: oci-vol-test
  namespace: nexusiq
  labels:
    app.kubernetes.io/name: oci-vol-test
spec:
  restartPolicy: Never
  nodeSelector:
    workload: enterprise-stateful
  tolerations:
    - key: dedicated
      operator: Equal
      value: enterprise-stateful
      effect: NoSchedule
  containers:
    - name: t
      image: 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/containers/nexus-iq-server-ha/busybox:1.28
      command: ["find", "/opt/jmx"]
      volumeMounts:
        - name: jmx
          mountPath: /opt/jmx
          readOnly: true
  volumes:
    - name: jmx
      image:
        reference: 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/artifacts/jmx-exporter-agent:1.0.1
        pullPolicy: Always
```



mount this in the deployment
