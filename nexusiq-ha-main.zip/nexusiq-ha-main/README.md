# Project Name

This template serves as an example for how to use cDSOv2 for a monorepo. This means you can now have multiple containers in the same project! For each container you must:

1. Include the cdso review component (see .gitlab-ci.yml) and set the `pipeline_type` and `name` input
2. Ensure there is a top level key in the cdso_config.yml that matches the `name` specified in the component from step 1.

Please see the [.gitlab-ci.yml](.gitlab-ci.yml) and [cdso_config.yml](cdso_config.yml) for examples on the ranges of configurations possible

Note: `name` field must be a valid yml key (Regex: `^[a-zA-Z0-9_]+$`)