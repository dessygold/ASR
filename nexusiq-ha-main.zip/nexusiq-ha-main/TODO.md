1. update terraform module

```hcl

  parameter {
    name         = "statement_timeout"
    value        = "10000"   # set to "14400000" (4h) for the migration
    apply_method = "immediate"
  }

```


watch for statement timeouts from mgmt node

```bash
k logs -n nexusiq -l name=nexusiq-iq-server -c nexusiq-iq-server-container --tail=2000 | grep -c "statement timeout"
```


2. verify oci artifact jmx exporter is working for grafana / victoriametrics 

```
up{namespace="nexusiq"}
count by (__name__) ({namespace="nexusiq"})

count by (__name__, job) ({__name__=~".*blobstore.*"})


# show all metrics from nexus jobs
count by (__name__, job) ({__name__=~"nexus_.*"})

```
