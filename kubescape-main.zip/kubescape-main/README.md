# Application Template

Overview on what this application is.

System(s) this application deploys to.

CODEOWNERS: add individual users **by username** to [CODEOWNERS file](https://docs.gitlab.com/user/project/codeowners/reference/)

Badges (optional):
- cdso pipeline status
- latest helm chart version
- latest application version
- application (internal/external)
- ArgoCD status badge

**References**
- [source code repository](https://someurl)
- [official documentation](https://someurl)
- [relevant article or guide](https://someurl)
- [**DSOP**: applications terraform module (if applicable)](https://someurl)

## Documentation

- [DEPLOYMENT.md](./docs/DEPLOYMENT.md)
- [BACKUP-RESTORE.md](./docs/BACKUP-RESTORE.md)
- [SECURITY.md](./docs/SECURITY.md)
- [TROUBLESHOOTING.md](./docs/TROUBLESHOOTING.md)
- [CDSO_STATUS.md](./docs/CDSO_STATUS.md)

## Reference Commands

```bash

helm repo add some-repo https://some-repo.github.io/org/
helm repo update

...
```
