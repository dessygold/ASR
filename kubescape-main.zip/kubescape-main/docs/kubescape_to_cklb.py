#!/usr/bin/env python3
"""
kubescape_to_cklb.py

Converts Kubescape JSON scan results into DISA STIG Viewer 3.x (.cklb) JSON format.
Resolves failedPath/fixPath against the raw Kubernetes resource manifest in 'resources[]'
to show exact current configurations and missing attributes for eMASS POA&M evidence.

Includes dynamic check procedure generation to replace static check text.
"""

import argparse
import json
import re
import sys
import uuid
from datetime import datetime, timezone

# ==============================================================================
# DISA STIG / NIST SP 800-53 Rev 5 CCI MAPPING TABLE
# ==============================================================================
K8S_CCI_MAP = {
    # Category A: Least Privilege & Access Enforcement (NIST AC-6 / CCI-000366)
    "C-0001": ["CCI-000366"],  # Allowed Privilege Escalation
    "C-0002": ["CCI-000366"],  # Host PID/IPC Sharing
    "C-0009": ["CCI-000366"],  # Host Network Namespace Sharing
    "C-0016": ["CCI-000366"],  # Non-Root Container Execution
    "C-0020": ["CCI-000366"],  # Privileged Container Execution
    "C-0034": ["CCI-000366"],  # Automatic ServiceAccount Token Mounts
    "C-0035": ["CCI-000366"],  # RBAC: Cluster-Admin Role Bindings
    "C-0036": ["CCI-000366"],  # RBAC: Wildcard (*) Rules in Roles/ClusterRoles
    "C-0038": ["CCI-000366"],  # RBAC: Secrets List/Get Access
    "C-0039": ["CCI-000366"],  # RBAC: Core API Groups Verb Access
    "C-0057": ["CCI-000366"],  # RBAC: User/Group Admin Cluster-wide Privileges
    "C-0256": ["CCI-000366"],  # Host Ports Binding Access

    # Category B: Information Flow & System Isolation (NIST AC-4 / CCI-002235)
    "C-0012": ["CCI-002235"],  # Dangerous Container Linux Capabilities
    "C-0013": ["CCI-002235"],  # HostPath Directory Storage Mounts
    "C-0030": ["CCI-002235"],  # Missing NetworkPolicies
    "C-0041": ["CCI-002235"],  # Host IPC/Namespace Shared Drivers

    # Category C: System Integrity & Memory Safety (NIST SI-7 / CCI-001813)
    "C-0017": ["CCI-001813"],  # Read-Only Root Filesystems
    "C-0018": ["CCI-001813"],  # Insecure Docker Socket Bindings

    # Category D: Resource Allocation & Denial of Service (NIST SC-5 / CCI-001094)
    "C-0005": ["CCI-001094"],  # Missing CPU/Memory Limits
    "C-0006": ["CCI-001095"],  # Missing CPU/Memory Requests
    "C-0008": ["CCI-001094"],  # Missing Namespace Resource Quotas

    # Category E: Authentication & Credential Management (NIST IA-5 / CCI-002367)
    "C-0255": ["CCI-002367"],  # Plaintext Hardcoded Credentials in Env Vars
    "C-0015": ["CCI-002367"],  # Insecure Kubelet Authentication

    # Category F: Auditing & Contingency Management (NIST CP-2 / CCI-002385)
    "C-0046": ["CCI-002385"],  # Missing Liveness Probes
    "C-0048": ["CCI-002385"],  # Missing Readiness Probes
    "C-0053": ["CCI-002385"],  # Host Node Logging and Auditing Unconfigured
}

# ==============================================================================
# SPECIFIC MANUAL REVIEW PROCEDURES & FINDING CRITERIA CATALOG
# ==============================================================================
CONTROL_CHECK_PROCEDURES = {
    "C-0001": {
        "inspect_field": ".spec.template.spec.containers[*].securityContext.allowPrivilegeEscalation",
        "procedure": (
            "Review the workload pod specification to verify allowPrivilegeEscalation is set to false.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": allowPrivilegeEscalation=\"}}{{.securityContext.allowPrivilegeEscalation}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If 'allowPrivilegeEscalation' is not explicitly set to 'false' for all containers, this is a finding."
        ),
    },
    "C-0002": {
        "inspect_field": ".spec.template.spec.hostPID and .spec.template.spec.hostIPC",
        "procedure": (
            "Review the workload pod specification to ensure host PID and IPC sharing are disabled.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{.metadata.name}}{{\": hostPID=\"}}{{.spec.template.spec.hostPID}}{{\", hostIPC=\"}}{{.spec.template.spec.hostIPC}}{{\"\\n\"}}'"
        ),
        "finding_condition": (
            "If 'hostPID' or 'hostIPC' is set to 'true', this is a finding."
        ),
    },
    "C-0005": {
        "inspect_field": ".spec.template.spec.containers[*].resources.limits",
        "procedure": (
            "Review the container resource configuration to verify CPU and memory limits are defined.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": limits=\"}}{{.resources.limits}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If any container lacks defined CPU or memory limits in 'resources.limits', this is a finding."
        ),
    },
    "C-0006": {
        "inspect_field": ".spec.template.spec.containers[*].resources.requests",
        "procedure": (
            "Review the container resource configuration to verify CPU and memory requests are defined.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": requests=\"}}{{.resources.requests}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If any container lacks CPU or memory requests in 'resources.requests', this is a finding."
        ),
    },
    "C-0009": {
        "inspect_field": ".spec.template.spec.hostNetwork",
        "procedure": (
            "Review the workload pod specification to ensure host network namespace sharing is disabled.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{.metadata.name}}{{\": hostNetwork=\"}}{{.spec.template.spec.hostNetwork}}{{\"\\n\"}}'"
        ),
        "finding_condition": (
            "If 'hostNetwork' is set to 'true', this is a finding."
        ),
    },
    "C-0012": {
        "inspect_field": ".spec.template.spec.containers[*].securityContext.capabilities",
        "procedure": (
            "Inspect the Linux capabilities configured for all containers in the workload.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": capabilities=\"}}{{.securityContext.capabilities}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If 'capabilities.drop' does not include 'ALL', or if dangerous capabilities such as 'CAP_SYS_ADMIN', "
            "'CAP_NET_ADMIN', or 'CAP_SYS_PTRACE' are added under 'capabilities.add', this is a finding."
        ),
    },
    "C-0013": {
        "inspect_field": ".spec.template.spec.volumes[*].hostPath",
        "procedure": (
            "Review workload volume mounts to ensure the host filesystem is not directly exposed.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.volumes[*]}}{{.name}}{{\": hostPath=\"}}{{.hostPath.path}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If any volume uses a 'hostPath' volume source, this is a finding."
        ),
    },
    "C-0016": {
        "inspect_field": ".spec.template.spec.securityContext.runAsNonRoot and container securityContext",
        "procedure": (
            "Verify that containers are configured to run as a non-root user.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": runAsNonRoot=\"}}{{.securityContext.runAsNonRoot}}{{\", runAsUser=\"}}{{.securityContext.runAsUser}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If 'runAsNonRoot' is not set to 'true' at the pod or container securityContext, or if 'runAsUser' is set to 0, this is a finding."
        ),
    },
    "C-0017": {
        "inspect_field": ".spec.template.spec.containers[*].securityContext.readOnlyRootFilesystem",
        "procedure": (
            "Verify that the container's root filesystem is mounted as read-only.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": readOnlyRootFilesystem=\"}}{{.securityContext.readOnlyRootFilesystem}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If 'readOnlyRootFilesystem' is not set to 'true' for all containers, this is a finding."
        ),
    },
    "C-0018": {
        "inspect_field": ".spec.template.spec.volumes[*].hostPath.path (docker.sock)",
        "procedure": (
            "Check volume mounts for exposure of the Docker or container runtime socket.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.volumes[*]}}{{.name}}{{\": \"}}{{.hostPath.path}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If any volume mounts '/var/run/docker.sock' or the container runtime socket, this is a finding."
        ),
    },
    "C-0020": {
        "inspect_field": ".spec.template.spec.containers[*].securityContext.privileged",
        "procedure": (
            "Check that containers are not running in privileged mode.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": privileged=\"}}{{.securityContext.privileged}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If 'securityContext.privileged' is set to 'true' on any container, this is a finding."
        ),
    },
    "C-0030": {
        "inspect_field": "NetworkPolicy objects targeting workload pod labels",
        "procedure": (
            "Verify that an active NetworkPolicy applies to the workload pod selector in the namespace.\n\n"
            "Run the following command:\n"
            "kubectl get networkpolicy -n {namespace}"
        ),
        "finding_condition": (
            "If no NetworkPolicy exists in namespace '{namespace}' restricting ingress and egress traffic to the workload, this is a finding."
        ),
    },
    "C-0034": {
        "inspect_field": ".spec.template.spec.automountServiceAccountToken",
        "procedure": (
            "Check whether automatic ServiceAccount token mounting is disabled when not required.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{.metadata.name}}{{\": automountServiceAccountToken=\"}}{{.spec.template.spec.automountServiceAccountToken}}{{\"\\n\"}}'"
        ),
        "finding_condition": (
            "If 'automountServiceAccountToken' is not explicitly set to 'false' and the workload does not interact with the Kubernetes API, this is a finding."
        ),
    },
    "C-0046": {
        "inspect_field": ".spec.template.spec.containers[*].livenessProbe",
        "procedure": (
            "Verify that all containers define a liveness probe to support automatic container recovery.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": livenessProbe=\"}}{{.livenessProbe}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If any long-running application container lacks a configured 'livenessProbe', this is a finding."
        ),
    },
    "C-0048": {
        "inspect_field": ".spec.template.spec.containers[*].readinessProbe",
        "procedure": (
            "Verify that all containers define a readiness probe to prevent traffic routing to unready pods.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": readinessProbe=\"}}{{.readinessProbe}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If any container serving network traffic lacks a configured 'readinessProbe', this is a finding."
        ),
    },
    "C-0255": {
        "inspect_field": ".spec.template.spec.containers[*].env",
        "procedure": (
            "Inspect container environment variables for plaintext secrets or credential values.\n\n"
            "Run the following command:\n"
            "kubectl get {kind} {name} -n {namespace} -o jsonpath='{{range .spec.template.spec.containers[*]}}{{.name}}{{\": env=\"}}{{.env}}{{\"\\n\"}}{{end}}'"
        ),
        "finding_condition": (
            "If sensitive data (passwords, tokens, private keys) is defined directly in 'value' rather than referenced via 'valueFrom.secretKeyRef', this is a finding."
        ),
    },
}


def normalize_status(raw_status):
    """Normalize Kubescape status string into DISA STIG Viewer 3.x status."""
    if not raw_status:
        return "not_reviewed"
    s = str(raw_status).strip().lower()
    if s in ["failed", "failure", "alert", "deny"]:
        return "open"
    if s in ["passed", "pass", "success"]:
        return "not_a_finding"
    if s in ["action_required", "manual_review", "skipped", "error"]:
        return "not_reviewed"
    if s in ["not_applicable", "na"]:
        return "not_applicable"
    return "not_reviewed"


def resolve_manifest_path(manifest_obj, path_str):
    """
    Traverse a Kubernetes manifest dict using Kubescape path notation
    and return the actual live configuration value/snippet.
    """
    if not manifest_obj or not path_str:
        return None

    clean_path = path_str.strip("./")
    tokens = re.split(r"\.", clean_path)
    curr = manifest_obj

    try:
        for token in tokens:
            if not token:
                continue
            match = re.match(r"^([^\[\]]+)\[(\d+)\]$", token)
            if match:
                key, idx = match.group(1), int(match.group(2))
                curr = curr.get(key, [])[idx]
            else:
                if isinstance(curr, dict) and token in curr:
                    curr = curr[token]
                else:
                    return "<Attribute Not Present in Live Manifest>"
        return curr
    except (IndexError, KeyError, TypeError, AttributeError):
        return "<Unable to Resolve Path in Manifest>"


def build_resource_map(data):
    """Build a lookup dictionary mapping resourceID -> raw Kubernetes manifest object."""
    resource_map = {}
    if not isinstance(data, dict):
        return resource_map

    for res in data.get("resources", []):
        res_id = res.get("resourceID")
        obj = res.get("object")
        if res_id and isinstance(obj, dict):
            resource_map[res_id] = obj

    return resource_map


def get_workload_summary(manifest_obj, fallback_id):
    """Extract clean Kind, Namespace, and Name from the raw K8s manifest object."""
    if not isinstance(manifest_obj, dict):
        return {"kind": "Resource", "namespace": "default", "name": fallback_id}

    kind = manifest_obj.get("kind", "Resource")
    metadata = manifest_obj.get("metadata", {})
    name = metadata.get("name", fallback_id)
    namespace = metadata.get("namespace", "cluster-scoped")
    return {"kind": kind, "namespace": namespace, "name": name}


def extract_kubescape_records(data):
    """Extract control definitions, failed paths, and actual live manifest values."""
    records = {}
    resource_map = build_resource_map(data)

    # 1. Base Controls Definition from summaryDetails
    summary_details = data.get("summaryDetails", {}) if isinstance(data, dict) else {}
    control_summaries = summary_details.get("controls", {})

    for ctrl_id, ctrl_meta in control_summaries.items():
        records[ctrl_id] = {
            "controlID": ctrl_id,
            "name": ctrl_meta.get("name") or ctrl_id,
            "description": ctrl_meta.get("description") or ctrl_meta.get("long_description") or "",
            "remediation": ctrl_meta.get("remediation") or "",
            "status": ctrl_meta.get("status"),
            "scoreFactor": ctrl_meta.get("scoreFactor", 5),
            "failedResources": ctrl_meta.get("failedResources", 0),
            "evidence_entries": [],
            "rules": ctrl_meta.get("rulesNames") or [],
            "evaluated_paths": [],
        }

    # 2. Extract Detailed Evidence & Resolve Live Configs from 'results'
    results = data.get("results", []) if isinstance(data, dict) else []

    for res_block in results:
        raw_res_id = res_block.get("resourceID", "")
        manifest_obj = resource_map.get(raw_res_id) or res_block.get("rawObject")
        wk_meta = get_workload_summary(manifest_obj, raw_res_id)

        for ctrl in res_block.get("controls", []):
            cid = ctrl.get("controlID") or ctrl.get("id")
            if not cid:
                continue

            if cid not in records:
                records[cid] = {
                    "controlID": cid,
                    "name": ctrl.get("name", cid),
                    "description": ctrl.get("description", ""),
                    "remediation": ctrl.get("remediation", ""),
                    "status": ctrl.get("status"),
                    "scoreFactor": 5,
                    "failedResources": 0,
                    "evidence_entries": [],
                    "rules": [],
                    "evaluated_paths": [],
                }

            raw_ctrl_status = ctrl.get("status")
            if isinstance(raw_ctrl_status, dict):
                raw_ctrl_status = raw_ctrl_status.get("status")
            c_status = str(raw_ctrl_status or "").lower()

            if c_status in ["failed", "failure"]:
                records[cid]["status"] = "failed"

                for rule in ctrl.get("rules", []):
                    rule_name = rule.get("name", "Unnamed Rule")
                    raw_paths = rule.get("paths", [])
                    resolved_checks = []

                    for p in raw_paths:
                        if isinstance(p, dict):
                            failed_p = p.get("failedPath", "")
                            fix_p_obj = p.get("fixPath", {})
                            fix_path_str = fix_p_obj.get("path", "") if isinstance(fix_p_obj, dict) else str(fix_p_obj)
                            fix_val_str = fix_p_obj.get("value", "") if isinstance(fix_p_obj, dict) else ""

                            if failed_p:
                                records[cid]["evaluated_paths"].append(failed_p)
                                actual_val = resolve_manifest_path(manifest_obj, failed_p)
                                val_formatted = (
                                    json.dumps(actual_val, indent=2)
                                    if isinstance(actual_val, (dict, list))
                                    else str(actual_val)
                                )
                                resolved_checks.append(
                                    f"Failed Path   : {failed_p}\n"
                                    f"      Current Config: {val_formatted}"
                                )
                            if fix_path_str:
                                records[cid]["evaluated_paths"].append(fix_path_str)
                                parent_path = ".".join(fix_path_str.split(".")[:-1])
                                parent_val = resolve_manifest_path(manifest_obj, parent_path) if parent_path else None
                                parent_formatted = (
                                    json.dumps(parent_val)
                                    if isinstance(parent_val, (dict, list))
                                    else str(parent_val)
                                )
                                resolved_checks.append(
                                    f"Missing Config: {fix_path_str} (Setting is absent)\n"
                                    f"      Parent Context: {parent_path} -> {parent_formatted}\n"
                                    f"      Required Value: {fix_path_str} = {fix_val_str}"
                                )
                        elif isinstance(p, str):
                            records[cid]["evaluated_paths"].append(p)
                            actual_val = resolve_manifest_path(manifest_obj, p)
                            resolved_checks.append(
                                f"Failed Path   : {p}\n"
                                f"      Current Config: {json.dumps(actual_val) if isinstance(actual_val, (dict, list)) else actual_val}"
                            )

                    records[cid]["evidence_entries"].append({
                        "namespace": wk_meta["namespace"],
                        "kind": wk_meta["kind"],
                        "name": wk_meta["name"],
                        "rule_name": rule_name,
                        "checks": resolved_checks,
                    })

    return list(records.values())


def generate_check_content(item, target_name, target_ns, target_kind="StatefulSet"):
    """
    Build detailed, control-specific check content for DISA STIG Viewer 3.x.
    Provides clear review steps, kubectl verification commands, and finding conditions.
    """
    control_id = item.get("controlID", "")
    rule_name = item.get("name", control_id)
    description = item.get("description", "")
    paths = item.get("evaluated_paths", [])

    # Check for known control procedure in catalog
    if control_id in CONTROL_CHECK_PROCEDURES:
        proc = CONTROL_CHECK_PROCEDURES[control_id]
        procedure_text = proc["procedure"].format(
            name=target_name,
            namespace=target_ns,
            kind=target_kind.lower()
        )
        finding_text = proc["finding_condition"]
        inspect_field = proc["inspect_field"]
    else:
        # Dynamic fallback based on evaluated manifest paths and control description
        path_hint = paths[0] if paths else "spec.template.spec"
        inspect_field = path_hint
        procedure_text = (
            f"Review the configuration of {target_kind} '{target_name}' in namespace '{target_ns}'.\n\n"
            f"1. Query the live resource manifest:\n"
            f"   kubectl get {target_kind.lower()} {target_name} -n {target_ns} -o yaml\n\n"
            f"2. Inspect the relevant configuration field ({path_hint}):\n"
            f"   Verify that the configuration adheres to {rule_name}."
        )
        finding_text = (
            f"If the live configuration violates the following requirement, this is a finding:\n"
            f"{description}"
        )

    check_text = (
        f"=== DISA STIG CHECK PROCEDURE ===\n"
        f"TARGET WORKLOAD   : {target_kind}/{target_name} (Namespace: {target_ns})\n"
        f"CONTROL CHECK     : {control_id} - {rule_name}\n"
        f"INSPECTED FIELD   : {inspect_field}\n\n"
        f"--- REVIEW PROCEDURE ---\n"
        f"{procedure_text}\n\n"
        f"--- AUTOMATED TOOL VERIFICATION ---\n"
        f"To verify using Kubescape CLI:\n"
        f"kubescape scan control {control_id} --verbose\n\n"
        f"--- FINDING CRITERIA ---\n"
        f"{finding_text}"
    )
    return check_text


def generate_finding_details(item, target_name, status, control_id, rule_name, description):
    """Build Finding Details showing exact current configuration values that triggered the failure."""
    if status == "open":
        evidence_entries = item.get("evidence_entries", [])
        evidence_blocks = []

        if evidence_entries:
            for idx, entry in enumerate(evidence_entries, 1):
                checks_text = (
                    "\n      ---\n      ".join(entry["checks"])
                    if entry["checks"]
                    else "Resource-level violation (No specific sub-path returned by Kubescape rule)"
                )
                evidence_blocks.append(
                    f"[{idx}] Resource : {entry['kind']}/{entry['name']} (Namespace: {entry['namespace']})\n"
                    f"    Rule     : {entry['rule_name']}\n"
                    f"    Check Results:\n"
                    f"      {checks_text}"
                )
            evidence_body = "\n\n".join(evidence_blocks)
        else:
            evidence_body = (
                f"Kubescape marked control {control_id} as FAILED, but no resource object was embedded in 'resources[]'.\n"
                f"Run Kubescape with '--format json --format-version v2' to include full resource objects."
            )

        return (
            f"=== DISA / eMASS FINDING EVIDENCE ===\n"
            f"VULNERABILITY STATE : OPEN (Failed Check)\n"
            f"CONTROL IDENTIFIER  : {control_id} - {rule_name}\n"
            f"AFFECTED ASSET      : {target_name}\n\n"
            f"--- LIVE CONFIGURATION CHECK RESULTS ---\n"
            f"{evidence_body}\n\n"
            f"--- CONTROL REQUIREMENT ---\n"
            f"{description}"
        )

    elif status == "not_a_finding":
        return (
            f"=== DISA / eMASS FINDING EVIDENCE ===\n"
            f"VULNERABILITY STATE : NOT A FINDING (Passed Check)\n"
            f"Workload '{target_name}' passed all Kubescape policy checks for {control_id} ({rule_name})."
        )
    else:
        return (
            f"=== DISA / eMASS FINDING EVIDENCE ===\n"
            f"VULNERABILITY STATE : {status.upper().replace('_', ' ')}\n"
            f"Manual review required for {control_id}.\n"
            f"Description: {description}"
        )


def generate_comments_poam_block(item, target_name, status, remediation):
    """Generate structured eMASS POA&M Comments including affected container/resource summary."""
    if status != "open":
        return f"Automated evaluation via Kubescape on '{target_name}' passed."

    affected_resources = sorted({
        f"{e['namespace']}/{e['kind']}/{e['name']}" for e in item.get("evidence_entries", [])
    })
    res_list_str = ", ".join(affected_resources) if affected_resources else target_name

    return (
        f"--- eMASS POA&M ENTRY DETAILS ---\n"
        f"WEAKNESS: {item.get('controlID')} - {item.get('name')}\n"
        f"AFFECTED K8S RESOURCES: {res_list_str}\n"
        f"ROOT CAUSE: Live workload manifest configuration violates DoD Kubernetes hardening baselines.\n"
        f"MITIGATIONS / COMPENSATING CONTROLS:\n"
        f"  - EKS cluster nodes reside in isolated private subnets protected by AWS Security Groups.\n"
        f"  - Pod-to-Pod traffic and IAM access are constrained via VPC CNI and IRSA.\n"
        f"REMEDIATION PLAN:\n"
        f"  {remediation}\n"
        f"MILESTONES:\n"
        f"  1. Update Helm chart / Kustomize manifest with required securityContext/spec fields (+15 Days).\n"
        f"  2. Validate manifest changes in Non-Prod EKS environment (+30 Days).\n"
        f"  3. Promote to Production EKS and re-verify via Kubescape scan (+45 Days)."
    )


def extract_dynamic_metadata(data):
    """
    Dynamically extract the target name, namespace, workload kind, and IP address.
    Prioritizes workload resources (StatefulSet, Deployment, etc.) over Pods and cluster-scoped objects.
    """
    detected_name = None
    detected_ns = None
    detected_ip = None
    detected_kind = "StatefulSet"

    HIGH_PRIORITY_WORKLOADS = {"StatefulSet", "Deployment", "DaemonSet", "Job", "CronJob"}
    LOW_PRIORITY_WORKLOADS = {"Pod"}

    resources = data.get("resources", []) if isinstance(data, dict) else []

    # 1. Discover active pod / service IP addresses
    for res in resources:
        obj = res.get("object")
        if not isinstance(obj, dict):
            continue
        kind = obj.get("kind", "")
        if kind == "Pod":
            status = obj.get("status", {})
            pod_ip = status.get("podIP") or status.get("hostIP")
            if pod_ip and not detected_ip:
                detected_ip = pod_ip
        elif kind == "Service":
            spec = obj.get("spec", {})
            cluster_ip = spec.get("clusterIP")
            if cluster_ip and cluster_ip != "None" and not detected_ip:
                detected_ip = cluster_ip

    # 2. Pass 1: Identify higher-level workloads
    for res in resources:
        obj = res.get("object")
        if not isinstance(obj, dict):
            continue
        kind = obj.get("kind", "")
        metadata = obj.get("metadata", {})
        ns = metadata.get("namespace")
        name = metadata.get("name")

        if kind in HIGH_PRIORITY_WORKLOADS and name:
            if ns and ns != "default":
                detected_name = name
                detected_ns = ns
                detected_kind = kind
                break
            elif not detected_name:
                detected_name = name
                detected_ns = ns or "default"
                detected_kind = kind

    # 3. Pass 2: Fallback to Pods if no higher workload exists or namespace defaulted
    if not detected_name or detected_ns == "default":
        for res in resources:
            obj = res.get("object")
            if not isinstance(obj, dict):
                continue
            kind = obj.get("kind", "")
            metadata = obj.get("metadata", {})
            ns = metadata.get("namespace")
            name = metadata.get("name")

            if kind in LOW_PRIORITY_WORKLOADS and name:
                if ns and ns != "default":
                    detected_name = name
                    detected_ns = ns
                    detected_kind = kind
                    break
                elif not detected_name:
                    detected_name = name
                    detected_ns = ns or "default"
                    detected_kind = kind

    # 4. Fallback 3: Parse results[].resourceID using regex
    if not detected_name or detected_ns == "default":
        results = data.get("results", []) if isinstance(data, dict) else []
        for res_block in results:
            res_id = res_block.get("resourceID", "")
            match = re.search(r"namespaces/([^/]+)/([^/]+)/([^/]+)", res_id)
            if match:
                ns, kind, name = match.group(1), match.group(2), match.group(3)
                if kind in HIGH_PRIORITY_WORKLOADS or kind in LOW_PRIORITY_WORKLOADS:
                    if ns != "default":
                        detected_name = name
                        detected_ns = ns
                        detected_kind = kind
                        if kind in HIGH_PRIORITY_WORKLOADS:
                            break
                    elif not detected_name:
                        detected_name = name
                        detected_ns = "default"
                        detected_kind = kind

    final_name = detected_name or "k8s-workload"
    final_ns = detected_ns or "default"
    final_ip = detected_ip or "127.0.0.1"

    return final_name, final_ns, final_ip, detected_kind


def kubescape_to_cklb(input_path, output_path, target_name=None, target_ip=None, fqdn=None):
    try:
        with open(input_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        sys.exit(f"[-] Error loading input JSON '{input_path}': {e}")

    # Dynamic Metadata Extraction
    detected_name, detected_ns, detected_ip, detected_kind = extract_dynamic_metadata(data)

    final_target_name = target_name if target_name else detected_name
    final_ns = detected_ns
    final_ip = target_ip if target_ip else detected_ip
    final_fqdn = fqdn if fqdn else f"{final_target_name}.{final_ns}.svc.cluster.local"

    print(f"[*] Target Identity Resolved:")
    print(f"    - Target Name : {final_target_name} ({detected_kind})")
    print(f"    - Namespace   : {final_ns}")
    print(f"    - IP Address  : {final_ip}")
    print(f"    - FQDN        : {final_fqdn}")

    extracted_records = extract_kubescape_records(data)
    rules = []
    status_summary = {"open": 0, "not_a_finding": 0, "not_reviewed": 0, "not_applicable": 0}

    for idx, item in enumerate(extracted_records):
        control_id = item.get("controlID") or f"K8S-{idx+1:04d}"
        rule_name = item.get("name") or f"Kubescape Control {control_id}"
        description = item.get("description") or "Kubernetes configuration posture check."
        remediation = item.get("remediation") or f"Update workload manifest for {final_target_name} to comply with {control_id}."

        # Generate control-specific check content
        check_content = generate_check_content(item, final_target_name, final_ns, detected_kind)

        status = normalize_status(item.get("status"))
        status_summary[status] = status_summary.get(status, 0) + 1
        score = float(item.get("scoreFactor", 5) or 5)
        severity = "high" if score >= 8 else ("medium" if score >= 4 else "low")

        finding_details = generate_finding_details(item, final_target_name, status, control_id, rule_name, description)
        comments = generate_comments_poam_block(item, final_target_name, status, remediation)

        clean_cid = re.sub(r"[^A-Za-z0-9]", "", control_id)
        ccis = K8S_CCI_MAP.get(control_id, item.get("rules", []))
        if not ccis or not isinstance(ccis, list):
            ccis = ["CCI-000366"]

        rules.append({
            "group_id": f"V-{clean_cid}",
            "rule_id": f"SV-{clean_cid}r1_rule",
            "rule_version": control_id,
            "severity": severity,
            "status": status,
            "rule_title": rule_name,
            "discussion": description,
            "check_content": check_content,
            "fix_text": remediation,
            "finding_details": finding_details,
            "comments": comments,
            "ccis": ccis,
        })

    now_utc = datetime.now(timezone.utc)
    cklb_payload = {
        "title": f"Kubescape Workload Assessment - {final_target_name}",
        "id": str(uuid.uuid4()),
        "cklb_version": "1.0",
        "generated_timestamp": now_utc.isoformat(),
        "target_data": {
            "host_name": final_target_name,
            "ip_address": final_ip,
            "fqdn": final_fqdn,
            "role": "Workload",
            "asset_type": "Computing",
            "technology_area": "Kubernetes",
        },
        "stigs": [
            {
                "stig_name": "Kubernetes Security Technical Implementation Guide",
                "display_name": "Kubernetes STIG / Kubescape Scan",
                "stig_id": "Kubernetes_STIG",
                "version": "1",
                "release_info": "Release: 1 Benchmark Date: " + now_utc.strftime("%d %b %Y"),
                "rules": rules,
            }
        ],
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(cklb_payload, f, indent=2)

    print(f"[+] Wrote {len(rules)} rules to {output_path} (Open: {status_summary['open']})")


def main():
    parser = argparse.ArgumentParser(description="Convert Kubescape v2 JSON into DISA STIG Viewer 3.x .cklb.")
    parser.add_argument("-i", "--input", default="results.json", help="Input Kubescape JSON")
    parser.add_argument("-o", "--output", default="results.cklb", help="Output .cklb file")
    parser.add_argument("--target-name", default=None, help="Target workload name (auto-detected if omitted)")
    parser.add_argument("--ip", default=None, help="Target IP (auto-detected if omitted)")
    parser.add_argument("--fqdn", default=None, help="Target FQDN (auto-generated if omitted)")
    args = parser.parse_args()

    kubescape_to_cklb(args.input, args.output, args.target_name, args.ip, args.fqdn)


if __name__ == "__main__":
    main()
