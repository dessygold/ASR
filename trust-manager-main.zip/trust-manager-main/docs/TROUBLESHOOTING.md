# Troubleshooting

This document describes troubleshooting, scripts, tips and tricks for managing this application.

## Using the `dsop-certs` configmap or secret with `SSL_CERT_DIR` variable

trust manager writes a configmap or secret, which can be mounted to a pod.

depending on the application, it may be helpful or required to set the `SSL_CERT_DIR` environmenet variable in order to take advantage of the mounted certificate.


**Note:** this will probably not work if multiple certificates are mounted, this probably only works with using `dsop-certs` as the sole mounted certificate... if you need more certificates, consider updating the trust bundle


```yaml
# configmap example

spec:
  containers:
    - name: some-app
      image: some-image:latest
      env:
        # POINT CRYPTO LIBRARIES TO THE MOUNTED DIRECTORY
        - name: SSL_CERT_DIR
          value: /etc/ssl/custom-certs
      volumeMounts:
        - name: trust-bundle-volume
          mountPath: /etc/ssl/custom-certs
  volumes:
    - name: trust-bundle-volume
      configMap:
        name: dsop-certs
```
