# cDSO Pipeline Status

## Container `trust-manager:v0.25.0`

[pipeline run](https://code.cdso.army.mil/cdso/cdso/-/pipelines/5282296)

pipeline came back clean
