# Deployment

This document describes the deployment process for `Trust-Manager`.

## Overview

[`trust-manager`](https://cert-manager.io/docs/trust/trust-manager/) is a sub-project of cert-manager. It solves a narrow problem: keeping a set of **trusted CA certificates** consistent and up to date across every namespace in a cluster, without anyone having to rebuild a container image or manually copy a ConfigMap around every time a CA changes. It has no runtime dependency on cert-manager itself — it just happens to ship alongside it and is commonly used to distribute the CAs that a cert-manager `Issuer`/`ClusterIssuer` trusts.

The whole model is one CRD: **`Bundle`**.

- A `Bundle`'s **`sources`** list where to pull CA certificates from — a `ConfigMap` (by name or label selector), a `Secret` (same), an `inLine` PEM block, or the public CA set (`useDefaultCAs`). 
- Source `ConfigMap`s/`Secret`s  must live in trust-manager's configured **trust namespace** (`cert-manager`)
- A `Bundle`'s **`target`** says where the *combined* result gets written — a `ConfigMap` and/or `Secret`, under a given key.
- If `target.namespaceSelector` is left empty, trust-manager writes that target into **every namespace in the cluster**, not just one.

Trust-manager watches a set of source CAs, concatenates them, and mirrors the result into a ConfigMap/Secret in every namespace, and keeps re-syncing whenever a source or a namespace changes.

- [trust-manager overview](https://cert-manager.io/docs/trust/trust-manager/)
- [trust-manager API reference (`Bundle` spec)](https://cert-manager.io/docs/trust/trust-manager/api-reference/)
- [trust-manager installation / trust namespace](https://cert-manager.io/docs/trust/trust-manager/installation/)

## How we deploy it to DSOP

This repository contains three plain `ConfigMap`s in the `support-manifests/` directory with the label `dsop-certs: enabled`:

- **`dod-certs`**: DoD root/WCF CA bundles. Starts empty (`data: {}`) and is populated/refreshed by the `dod-cert-updater` `CronJob`.
- **`ac2sp-root-cert-email`**: two static AC2SP root CAs, checked in directly.
- **`aws-gov-west-1-rds-bundle`**: the AWS RDS GovCloud CA bundle, also static, pulled from AWS's own published truststore.

The `dod-cert-updater` `CronJob` is a nightly job that does the following:
1. downloads the current DoD PKI/WCF certificate bundles from `dl.dod.cyber.mil`
2. converts them from PKCS7 to PEM
3. patches the two keys in the `dod-certs` ConfigMap. 

Its `ServiceAccount` /`Role` / `RoleBinding` are scoped as tightly as Kubernetes RBAC allows. The `Role` only grants `get/list/watch/update/patch` on the single named ConfigMap `dod-certs` (via `resourceNames`), with no `create`/`delete`. It can refresh that one ConfigMap's contents and nothing else. Once it patches `dod-certs`, trust-manager notices the change on its own and re-syncs the `Bundle` automatically. the `CronJob` never talks to trust-manager directly.

The `Bundle`'s `target` writes the merged result to key `dsop-certificates.crt` in both a `ConfigMap` and a `Secret` into **every namespace** in the cluster. Any workload anywhere can mount `dsop-certificates.crt` and get the full, current set of DoD, AC2SP mail certs, and AWS RDS CAs without knowing or caring which of the three source ConfigMaps a given cert came from.

Adding a another CA is as easy as adding another labeled ConfigMap. Nothing about the `Bundle` itself has to change.

### AWS RDS Certs

AWS RDS SSL documentation: https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/UsingWithRDS.SSL.html

Certificate bundle that we create the `aws-gov-west-1-rds-bundle` configmap with: https://truststore.pki.us-gov-west-1.rds.amazonaws.com/us-gov-west-1/us-gov-west-1-bundle.pem

## Environments
 
- Trust Manger is deployed to every cluster, configured in the `DSOP/Gitops/<system>` projects. Future updates will deploy this as an ArgoCD `ApplicationSet`.
- It needs no infrastructure or additional permissions. Its recommended to have cert-manager installed first, which we do (eks addon).
- No additional configuration required other than disabling the init container. Enabling the `initContainer` includes a standard set of default certificates but we probably don't want this since they could conflict with the proxy.
- Only one small container
- No terraform module
- No authentication or additional networking requirements, no stateful data.


## Risks (integrations with other systems)

- If the cronjob breaks midway, it might not update the target configmap correctly, which would result in an incomplete `dod-certs` secret/configmap. Applications that require these certificates might run into errors.


## Upgrade Process

1. run ci pipeline to identify new chart/container
2. update `DSOP/Gitops/<system>` with new chart version
3. verify rollout in `dev` environments before promoting to `test`/`prod`
