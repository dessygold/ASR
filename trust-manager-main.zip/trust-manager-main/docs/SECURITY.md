# Security

This document describes the security posture for this application.

## cronjob fails

- **situation**: if something goes bad with the cronjob, it might not load dod certs correctly, breaking applications that rely on them

- **mitigation**: make sure cronjob works. maybe add an alert if it fails 3 times (requires alertmanager to be configured)


## cert poisoning? better term?

- **situation**: if dod certs cronjob gets intercepted, it could load bad certs, which then get loaded into other workloads.

- **impact**: not really sure how this would play out, need to look into it.

- **mitigation**: maybe update the cronjob to very SSL or hash or something
