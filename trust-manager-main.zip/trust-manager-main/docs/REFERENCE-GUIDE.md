# trust-manager

## Overview

**trust-manager** is a Kubernetes operator from the cert-manager project that manages and distributes X.509 trust bundles across a Kubernetes or OpenShift cluster. It aggregates certificates from one or more sources into a single trust bundle and automatically distributes that bundle to applications through ConfigMaps or Secrets. It is designed to simplify certificate trust management and reduce the operational burden of keeping trust stores up to date.

---

## Source Code

The upstream source code is maintained by the cert-manager project.

- Repository: https://github.com/cert-manager/trust-manager
- Organization: cert-manager

---

## Helm Chart

The official Helm chart is published by Jetstack as an OCI Helm chart.

- Helm Chart:
  - `oci://quay.io/jetstack/charts/trust-manager`
- Documentation:
  - https://cert-manager.io/docs/trust/trust-manager/installation/

---

## Infrastructure Requirements

trust-manager requires:

- Kubernetes cluster
- Helm 3
- Kubernetes RBAC
- CustomResourceDefinition (CRD) support
- Admission webhooks
- ConfigMaps and optionally Secrets
- cert-manager for webhook certificate management (recommended)
- Container registry access to pull the controller image

It does **not** require cert-manager for runtime operation, although cert-manager is the recommended mechanism for provisioning webhook certificates in production.

---

## Infrastructure Configuration

Infrastructure is configured through:

- Kubernetes manifests
- Helm values
- trust-manager Custom Resources (`Bundle`)
- Kubernetes RBAC resources
- Admission Webhook configuration
- Namespace configuration

Infrastructure outside Kubernetes (cloud resources, networking, DNS, etc.) is **not** managed by trust-manager.

---

## Infrastructure Deployment

Infrastructure is deployed using:

- Helm
- Kubernetes API
- CRDs installed with the Helm chart

Typical deployment:

```bash
helm upgrade trust-manager \
  oci://quay.io/jetstack/charts/trust-manager \
  --install \
  --namespace cert-manager \
  --wait
```

The Helm installation creates:

- Deployment
- Service
- Webhook
- RBAC
- ServiceAccount
- CRDs
- Validating/Mutating webhook configuration
- Certificate resources (when using cert-manager)

---

## Application Deployment

The application is deployed via Helm.

Typical deployment steps:

1. Install cert-manager (recommended)
2. Install trust-manager Helm chart
3. Create one or more `Bundle` resources
4. Reference generated ConfigMaps or Secrets from workloads

Applications then mount or consume the generated trust bundle.

---

## Configuration

Configuration is primarily performed through:

- Helm values
- Bundle CRDs
- ConfigMaps
- Secrets
- RBAC configuration

Common Bundle configuration includes:

- Public CA bundle
- ConfigMap sources
- Secret sources
- Inline certificates
- Bundle targets

---

## Additional Setup Beyond Helm Values

Yes.

After installation, administrators typically need to:

- Create one or more `Bundle` resources
- Configure certificate sources
- Configure target ConfigMaps or Secrets
- Grant RBAC permissions if Secret targets are enabled
- Configure applications to consume the generated trust bundles

If Secret targets are enabled, additional Helm values and RBAC configuration are required.

---

## Authentication

trust-manager itself does **not** implement end-user authentication.

It relies entirely on Kubernetes authentication and authorization.

Integration includes:

- Kubernetes Service Accounts
- Kubernetes RBAC
- Kubernetes Admission Webhooks

When used with cert-manager:

- cert-manager provisions webhook TLS certificates
- Kubernetes authenticates API requests
- RBAC authorizes controller actions

No OAuth, OIDC, LDAP, SAML, or external identity provider integration is built into trust-manager itself.

---

## Supporting Projects

Common supporting projects include:

- cert-manager
- Kubernetes
- Helm
- Quay container registry
- Prometheus (optional)
- Grafana (optional)

Supporting Kubernetes resources include:

- ConfigMaps
- Secrets
- ServiceAccounts
- ClusterRoles
- ClusterRoleBindings
- CRDs

---

## CI/CD Pipelines

The upstream project is maintained using GitHub and GitHub Actions.

Typical enterprise deployments install trust-manager through:

- GitOps
  - Argo CD
  - Flux
- Helm pipelines
- GitHub Actions
- GitLab CI/CD
- Azure DevOps
- Jenkins

The project itself does not require any specific CI/CD platform.

---

## Upgrades

Upgrades are managed using Helm.

Typical process:

```bash
helm repo update

helm upgrade trust-manager \
  oci://quay.io/jetstack/charts/trust-manager \
  --namespace cert-manager
```

Upgrade considerations:

- Review release notes
- Upgrade CRDs if required
- Verify Bundle reconciliation
- Validate webhook certificates
- Confirm application trust bundles are updated

Older versions (< v0.9.0) removed Bundle CRDs during uninstall; newer releases retain them to prevent data loss.

---

## Licensing

trust-manager is licensed under the Apache License 2.0.

This is a permissive open-source license suitable for commercial and enterprise use.

---

## License Management

No license server or license key is required.

Management consists of:

- Tracking upstream releases
- Maintaining license compliance
- Preserving Apache 2.0 license notices where applicable

---

## Required Skills

Maintaining trust-manager typically requires knowledge of:

- Kubernetes
- Helm
- TLS / PKI
- X.509 certificates
- Kubernetes RBAC
- Kubernetes CRDs
- Admission Webhooks
- ConfigMaps
- Secrets
- Git
- CI/CD
- GitOps (Argo CD or Flux)
- YAML

Helpful but optional skills:

- cert-manager
- Prometheus
- Grafana
- Terraform (if Kubernetes infrastructure is managed as code)
- Docker / OCI containers

---

## Projects Used to Maintain the Application

| Project | Purpose |
|----------|---------|
| trust-manager | Trust bundle management |
| cert-manager | Certificate issuance and webhook certificates |
| Kubernetes | Runtime platform |
| Helm | Application packaging and deployment |
| Git | Source control |
| GitHub Actions / GitLab CI/CD / Jenkins | Build and deployment automation |
| Argo CD / Flux | GitOps deployment |
| Prometheus | Metrics collection |
| Grafana | Monitoring dashboards |

---

## Summary

trust-manager is a lightweight Kubernetes operator focused on centralized trust bundle management. It integrates closely with Kubernetes and complements cert-manager by distributing trusted certificate bundles to workloads. It is deployed via Helm, configured using Helm values and `Bundle` custom resources, and maintained using standard Kubernetes operational practices. No commercial licensing or proprietary infrastructure is required.