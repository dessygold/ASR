# Cert-Manager Trust Manager

Trust-manager is a small Kubernetes operator which reduces the overhead of managing TLS trust bundles in your clusters, providing a much quicker way to update trust stores when they need to change.

It adds the `Bundle` custom Kubernetes resource (CRD) which can read input from various CA sources and combine the resultant certificates into a bundle ready to be used by your applications.


**Systems:** all

## References
- [source code repository](https://github.com/cert-manager/trust-manager)
    - [helm chart repo](https://github.com/cert-manager/trust-manager/tree/main/deploy/charts/trust-manager)
    - [CRDs](https://github.com/cert-manager/trust-manager/tree/main/deploy/crds)
- [official documentation](https://cert-manager.io/docs/trust/)
  - [API reference](https://cert-manager.io/docs/trust/trust-manager/api-reference/)

### Documentation

- [DEPLOYMENT.md](./docs/DEPLOYMENT.md)
- [BACKUP-RESTORE.md](./docs/BACKUP-RESTORE.md)
- [SECURITY.md](./docs/SECURITY.md)
- [TROUBLESHOOTING.md](./docs/TROUBLESHOOTING.md)
- [CDSO_STATUS.md](./docs/CDSO_STATUS.md)

## Reference Commands

```bash
# https://cert-manager.io/docs/trust/trust-manager/installation/

# install cert-manager (recommended, if not managed by EKS addons)

helm install cert-manager oci://quay.io/jetstack/charts/cert-manager \
  --namespace cert-manager \
  --create-namespace \
  --version v1.21.1 \
  --set crds.enabled=true

# install trust-manager
helm upgrade trust-manager oci://quay.io/jetstack/charts/trust-manager \
  --install \
  --namespace cert-manager \
  --wait


# show unique containers

kubectl get pods -n cert-manager -o json | jq -r ' .items[] | (.spec.initContainers[]? | "[init] \(.name): \(.image)"), (.spec.containers[]? | "\(.name): \(.image)")' | sort -u

[init] cert-manager-package-debian: quay.io/jetstack/trust-pkg-debian-trixie:20250419.1
cert-manager-cainjector: 013241004608.dkr.ecr.us-gov-west-1.amazonaws.com/eks/cert-manager-cainjector:v1.21.1-eksbuild.1
cert-manager-controller: 013241004608.dkr.ecr.us-gov-west-1.amazonaws.com/eks/cert-manager-controller:v1.21.1-eksbuild.1
cert-manager-webhook: 013241004608.dkr.ecr.us-gov-west-1.amazonaws.com/eks/cert-manager-webhook:v1.21.1-eksbuild.1
trust-manager: quay.io/jetstack/trust-manager:v0.24.0

```
