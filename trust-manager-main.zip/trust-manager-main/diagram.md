# Diagram

```mermaid
flowchart TD
    subgraph cronjob["Nightly refresh cronjob"]
        cron["CronJob"]
        sa["ServiceAccount / Role / RoleBinding"]
        dodsite["DOD/WCF Certs"]
        sa --> cron
        dodsite <--> cron
    end

    subgraph trustns["cert-manager namespace"]
        cmDod["ConfigMap<br/>dod-certs"]
        cmAc2sp["ConfigMap<br/>ac2sp-root-cert-email"]
        cmAws["ConfigMap<br/>aws-gov-west-1-rds-bundle"]
        bundle["Bundle<br/>dsop-certs"]
        tmctrl["trust-manager controller"]
    end

    subgraph everywhere["All namespaces"]
        tgtCm["ConfigMap<br/>key: dsop-certificates.crt"]
        tgtSecret["Secret<br/>key: dsop-certificates.crt"]
        workload["Any workload pod,<br/>any namespace"]
    end

    workload["Any workload pod,<br/>any namespace"]
    tgtCm --> workload
    tgtSecret --> workload

    cronjob ~~~ trustns
    trustns ~~~ everywhere

    cron --> cmDod
    cmDod --> bundle
    cmAc2sp --> bundle
    cmAws --> bundle
    tmctrl --> bundle
    tmctrl --> tgtCm
    tmctrl --> tgtSecret
```
