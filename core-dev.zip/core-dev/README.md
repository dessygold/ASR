# Core Gitops Application

[ArgoCD App-of-apps](https://argo-cd.readthedocs.io/en/stable/operator-manual/cluster-bootstrapping/#app-of-apps-pattern-alternative) Helm chart for the **Core** system. 

Bootstrapped by the [argocd terraform module](https://code.cdso.army.mil/dsop/modules/argocd), the Core ArgoCD instance is the GitOps hub for the whole platform.

Each environment has its own ArgoCD instance, which manages Core's own cluster directly (`in-cluster`) and the remote Enterprise/Commercial/Runners clusters.

- [argo-dev.cdso.army.mil](https://argo-dev.cdso.army.mil/)
- [argo-test.cdso.army.mil](https://argo-test.cdso.army.mil/)
- [argo.cdso.army.mil](https://argo.cdso.army.mil/)

## Dev -> Test -> Prod Promotion

Each environment's ArgoCD instance tracks a different branch of this repo. Argo-dev tracks `dev`, argo-test tracks `test`, argo-prod tracks `prod`.

Environment-specific facts (`vpc_id`, `cluster_name`, `account_id`, etc.) are **not** committed here. They're passed in as Helm values by the [argocd terraform module](https://code.cdso.army.mil/dsop/modules/argocd) when it creates the `core-gitops` Application, sourced from the AWS account data.

To promote a change, merge forward from `dev` -> `test` -> `prod`. ArgoCD will pick up the changes and apply them to the cluster.