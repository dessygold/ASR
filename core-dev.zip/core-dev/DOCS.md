# Docs

- [OneUptime Blog: break glass in case of emergency for argocd](https://oneuptime.com/blog/post/2026-02-26-disable-argocd-admin-account/view)

## Patch application manifests to use new gitops application

```bash
kubectl annotate application gitlab-application -n argocd \
    argocd.argoproj.io/tracking-id="gitops-core:argoproj.io/Application:argocd/gitlab-application" \
    --overwrite
```

```bash
for app in $(kubectl get applications -n argocd -o json | jq -r '
    .items[]
    | select(.metadata.annotations["argocd.argoproj.io/tracking-id"] // "" | startswith("core-gitops:"))
    | .metadata.name
  '); do
    echo "patching $app"
    kubectl annotate application "$app" -n argocd \
      argocd.argoproj.io/tracking-id="gitops-core:argoproj.io/Application:argocd/${app}" \
      --overwrite
  done
```

```bash
# force sync
kubectl annotate application gitops-core -n argocd argocd.argoproj.io/refresh=hard --overwrite
kubectl get application gitops-core -n argocd -o jsonpath='{.status.conditions}'
```

## use argocd spoke-mgmt token 

```bash
export ARGOCD_AUTH_TOKEN=$(aws secretsmanager get-secret-value --secret-id argocd/auth_token --region us-gov-west-1 --query SecretString --output text)
export ARGOCD_SERVER=argo-dev.cdso.army.mil

argocd cluster list
```