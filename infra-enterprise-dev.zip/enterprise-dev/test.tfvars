################################################################################
# Enterprise-Test Variables
################################################################################

environment         = "test"
cluster_name        = "enterprise-test-cluster"
cluster_version     = "1.35"
logging_bucket_name = "dso-enterprise-test-logs"

jira_db_instance_class        = "db.t3.small"
jira_db_allocated_storage     = 40
jira_db_max_allocated_storage = 60
jira_shared_pv_volume_size    = 64

nexus_db_instance_class        = "db.t3.small"
nexus_db_allocated_storage     = 20
nexus_db_max_allocated_storage = 30
nexus_efs_volume_size          = 10

confluence_db_instance_class        = "db.t3.small"
confluence_db_allocated_storage     = 40
confluence_db_max_allocated_storage = 60
confluence_rds_storage_type         = "gp2"

keycloak_db_instance_class        = "db.t3.small"
keycloak_db_allocated_storage     = 20
keycloak_db_max_allocated_storage = 30

sonarqube_db_instance_class        = "db.t3.small"
sonarqube_db_allocated_storage     = 20
sonarqube_db_max_allocated_storage = 30

jira_service_desk_db_instance_class        = "db.t3.small"
jira_service_desk_db_allocated_storage     = 40
jira_service_desk_db_max_allocated_storage = 60
jira_service_desk_shared_pv_volume_size    = 64

nexusiq_db_instance_class        = "db.t3.small"
nexusiq_db_allocated_storage     = 20
nexusiq_db_max_allocated_storage = 30
nexusiq_efs_volume_size          = 10

core_aws_account_id   = "186542266927"
argocd_env_server_url = "argo-test.cdso.army.mil:443"
