# Enterprise System Infrastructure

## AWS Accounts

| Environment |    Account     |
| :---------: | :------------: |
|     Dev     | `186558936487` |
|    Test     | `186572325402` |
|    Prod     | `186588639637` |

## Deployment Commands

```bash
# paste enterprise-dev credentials

terraform init -backend-config="dev.tfbackend"

terraform plan -var-file=dev.tfvars -out=tfplan
tf-summarize tfplan

terraform apply -var-file=dev.tfvars

# paste enterprise-test credentials

terraform init -backend-config="test.tfbackend"

terraform plan -var-file=test.tfvars -out=tfplan
tf-summarize tfplan

terraform apply -var-file=test.tfvars

# paste enterprise-prod credentials

terraform init -backend-config="prod.tfbackend"

terraform plan -var-file=prod.tfvars -out=tfplan
tf-summarize tfplan

terraform apply -var-file=prod.tfvars
```

[Terraform-docs](https://terraform-docs.io/) created by running: `terraform-docs markdown table --output-file README.md --output-mode inject .`

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.10.0 |
| <a name="requirement_argocd"></a> [argocd](#requirement\_argocd) | 7.16.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 6.0 |
| <a name="requirement_helm"></a> [helm](#requirement\_helm) | ~> 3.0 |
| <a name="requirement_kubectl"></a> [kubectl](#requirement\_kubectl) | 2.1.3 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >= 3.6.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 6.61.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_argocd_spoke"></a> [argocd\_spoke](#module\_argocd\_spoke) | code.cdso.army.mil/dsop/argocd-spoke/aws | 1.1.3 |
| <a name="module_aws_ebs_csi_pod_identity"></a> [aws\_ebs\_csi\_pod\_identity](#module\_aws\_ebs\_csi\_pod\_identity) | terraform-aws-modules/eks-pod-identity/aws | 2.8.2 |
| <a name="module_aws_efs_csi_pod_identity"></a> [aws\_efs\_csi\_pod\_identity](#module\_aws\_efs\_csi\_pod\_identity) | terraform-aws-modules/eks-pod-identity/aws | 2.8.2 |
| <a name="module_aws_lbc_pod_identity"></a> [aws\_lbc\_pod\_identity](#module\_aws\_lbc\_pod\_identity) | terraform-aws-modules/eks-pod-identity/aws | 2.8.2 |
| <a name="module_confluence_storage"></a> [confluence\_storage](#module\_confluence\_storage) | code.cdso.army.mil/dsop/confluence/aws | 0.5.1 |
| <a name="module_eks_cluster"></a> [eks\_cluster](#module\_eks\_cluster) | code.cdso.army.mil/dsop/eks-cluster/aws | 3.6.0 |
| <a name="module_external_secrets_pod_identity"></a> [external\_secrets\_pod\_identity](#module\_external\_secrets\_pod\_identity) | terraform-aws-modules/eks-pod-identity/aws | 2.8.2 |
| <a name="module_jira_service_desk_storage"></a> [jira\_service\_desk\_storage](#module\_jira\_service\_desk\_storage) | code.cdso.army.mil/dsop/jira-service-desk/aws | 0.2.0 |
| <a name="module_jira_storage"></a> [jira\_storage](#module\_jira\_storage) | code.cdso.army.mil/dsop/jira/aws | 0.6.0 |
| <a name="module_karpenter"></a> [karpenter](#module\_karpenter) | code.cdso.army.mil/dsop/karpenter/aws | 1.8.0 |
| <a name="module_keycloak_storage"></a> [keycloak\_storage](#module\_keycloak\_storage) | code.cdso.army.mil/dsop/keycloak/aws | 0.5.0 |
| <a name="module_monitoring"></a> [monitoring](#module\_monitoring) | code.cdso.army.mil/dsop/monitoring/aws | 1.2.3 |
| <a name="module_nexus_storage"></a> [nexus\_storage](#module\_nexus\_storage) | code.cdso.army.mil/dsop/nexus/aws | 0.7.3 |
| <a name="module_nexusiq_storage"></a> [nexusiq\_storage](#module\_nexusiq\_storage) | code.cdso.army.mil/dsop/nexus-iq/aws | 0.2.1 |
| <a name="module_platform_load_balancer"></a> [platform\_load\_balancer](#module\_platform\_load\_balancer) | code.cdso.army.mil/dsop/platform-load-balancer/aws | 1.2.3 |
| <a name="module_sonarqube_storage"></a> [sonarqube\_storage](#module\_sonarqube\_storage) | code.cdso.army.mil/dsop/sonarqube/aws | 0.4.0 |

## Resources

| Name | Type |
|------|------|
| [aws_eks_addon.ebs_csi_driver](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eks_addon) | resource |
| [aws_eks_addon.efs_csi_driver](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eks_addon) | resource |
| [aws_eks_pod_identity_association.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eks_pod_identity_association) | resource |
| [aws_iam_policy.aws_lbc_additional](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_policy.external_secrets_resource_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_role.s3_artifacts](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.s3_artifacts](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_eks_cluster_auth.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster_auth) | data source |
| [aws_iam_policy_document.aws_lbc_additional](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.pod_identity_trust](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.s3_artifacts_read](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_instance.mgmt](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/instance) | data source |
| [aws_kms_key.ebs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/kms_key) | data source |
| [aws_kms_key.efs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/kms_key) | data source |
| [aws_route53_zone.private](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_secretsmanager_secret_version.argocd_auth_token](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret_version) | data source |
| [aws_subnets.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnets) | data source |
| [aws_subnets.primary_1a](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnets) | data source |
| [aws_subnets.primary_1b](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnets) | data source |
| [aws_subnets.primary_1c](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnets) | data source |
| [aws_vpc.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_argocd_auth_token_secret"></a> [argocd\_auth\_token\_secret](#input\_argocd\_auth\_token\_secret) | AWS Secrets Manager secret name for the argocd auth token, located in core account | `string` | `"argocd/auth_token"` | no |
| <a name="input_argocd_env_server_url"></a> [argocd\_env\_server\_url](#input\_argocd\_env\_server\_url) | This environments argocd url, exposed by an ingress configured in the core account. Requires 'gitops-core' to have a fully synced argocd application. | `string` | n/a | yes |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | The name of the EKS cluster | `string` | n/a | yes |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Kubernetes cluster version | `string` | n/a | yes |
| <a name="input_confluence_db_allocated_storage"></a> [confluence\_db\_allocated\_storage](#input\_confluence\_db\_allocated\_storage) | Confluence database allocated storage | `number` | n/a | yes |
| <a name="input_confluence_db_instance_class"></a> [confluence\_db\_instance\_class](#input\_confluence\_db\_instance\_class) | Confluence database instance class, confirm in AWS docs/console for postgres | `string` | n/a | yes |
| <a name="input_confluence_db_max_allocated_storage"></a> [confluence\_db\_max\_allocated\_storage](#input\_confluence\_db\_max\_allocated\_storage) | Confluence database max allocated storage | `number` | n/a | yes |
| <a name="input_confluence_rds_snapshot_id"></a> [confluence\_rds\_snapshot\_id](#input\_confluence\_rds\_snapshot\_id) | Snapshot ID for confluence db | `string` | `""` | no |
| <a name="input_confluence_rds_storage_type"></a> [confluence\_rds\_storage\_type](#input\_confluence\_rds\_storage\_type) | rds storage type | `string` | n/a | yes |
| <a name="input_core_aws_account_id"></a> [core\_aws\_account\_id](#input\_core\_aws\_account\_id) | The core account id, based on the environment | `string` | n/a | yes |
| <a name="input_ebs_kms_key_alias"></a> [ebs\_kms\_key\_alias](#input\_ebs\_kms\_key\_alias) | KMS key alias for EBS encryption | `string` | `"alias/aws/ebs"` | no |
| <a name="input_efs_kms_key_alias"></a> [efs\_kms\_key\_alias](#input\_efs\_kms\_key\_alias) | KMS key alias for EFS encryption | `string` | `"alias/aws/elasticfilesystem"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Environment for deployed resources: Matches Matches DSO-<system>-<env> | `string` | n/a | yes |
| <a name="input_internal_private_hosted_zone_name"></a> [internal\_private\_hosted\_zone\_name](#input\_internal\_private\_hosted\_zone\_name) | Name of the private hosted zone to use for internal DNS resolution | `string` | `"enterprise.dso"` | no |
| <a name="input_jira_db_allocated_storage"></a> [jira\_db\_allocated\_storage](#input\_jira\_db\_allocated\_storage) | Jira database allocated storage | `number` | n/a | yes |
| <a name="input_jira_db_instance_class"></a> [jira\_db\_instance\_class](#input\_jira\_db\_instance\_class) | Jira database instance class, confirm in AWS docs/console for postgres | `string` | n/a | yes |
| <a name="input_jira_db_max_allocated_storage"></a> [jira\_db\_max\_allocated\_storage](#input\_jira\_db\_max\_allocated\_storage) | Confluence database max allocated storage | `number` | n/a | yes |
| <a name="input_jira_rds_snapshot_id"></a> [jira\_rds\_snapshot\_id](#input\_jira\_rds\_snapshot\_id) | Snapshot ID for jira db | `string` | `""` | no |
| <a name="input_jira_service_desk_db_allocated_storage"></a> [jira\_service\_desk\_db\_allocated\_storage](#input\_jira\_service\_desk\_db\_allocated\_storage) | Jira Service Desk database allocated storage | `number` | n/a | yes |
| <a name="input_jira_service_desk_db_instance_class"></a> [jira\_service\_desk\_db\_instance\_class](#input\_jira\_service\_desk\_db\_instance\_class) | Jira Service Desk database instance class, confirm in AWS docs/console for postgres | `string` | n/a | yes |
| <a name="input_jira_service_desk_db_max_allocated_storage"></a> [jira\_service\_desk\_db\_max\_allocated\_storage](#input\_jira\_service\_desk\_db\_max\_allocated\_storage) | Database max allocated storage | `number` | n/a | yes |
| <a name="input_jira_service_desk_shared_pv_volume_size"></a> [jira\_service\_desk\_shared\_pv\_volume\_size](#input\_jira\_service\_desk\_shared\_pv\_volume\_size) | Size of volume for Jira Service Desk Shared Persistent Volume | `number` | n/a | yes |
| <a name="input_jira_shared_pv_volume_size"></a> [jira\_shared\_pv\_volume\_size](#input\_jira\_shared\_pv\_volume\_size) | Size of volume for Jira Shared Persistent Volume | `number` | n/a | yes |
| <a name="input_keycloak_db_allocated_storage"></a> [keycloak\_db\_allocated\_storage](#input\_keycloak\_db\_allocated\_storage) | keycloak database allocated storage | `number` | n/a | yes |
| <a name="input_keycloak_db_instance_class"></a> [keycloak\_db\_instance\_class](#input\_keycloak\_db\_instance\_class) | keycloak database instance class, confirm in AWS docs/console for postgres | `string` | n/a | yes |
| <a name="input_keycloak_db_max_allocated_storage"></a> [keycloak\_db\_max\_allocated\_storage](#input\_keycloak\_db\_max\_allocated\_storage) | Database max allocated storage | `number` | n/a | yes |
| <a name="input_logging_bucket_name"></a> [logging\_bucket\_name](#input\_logging\_bucket\_name) | The name of the s3 bucket used for logging | `string` | n/a | yes |
| <a name="input_nexus_db_allocated_storage"></a> [nexus\_db\_allocated\_storage](#input\_nexus\_db\_allocated\_storage) | nexus database allocated storage | `number` | n/a | yes |
| <a name="input_nexus_db_instance_class"></a> [nexus\_db\_instance\_class](#input\_nexus\_db\_instance\_class) | nexus database instance class, confirm in AWS docs/console for postgres | `string` | n/a | yes |
| <a name="input_nexus_db_max_allocated_storage"></a> [nexus\_db\_max\_allocated\_storage](#input\_nexus\_db\_max\_allocated\_storage) | Database max allocated storage | `number` | n/a | yes |
| <a name="input_nexus_efs_volume_size"></a> [nexus\_efs\_volume\_size](#input\_nexus\_efs\_volume\_size) | EFS volume storage size in gigabytes | `number` | n/a | yes |
| <a name="input_nexusiq_db_allocated_storage"></a> [nexusiq\_db\_allocated\_storage](#input\_nexusiq\_db\_allocated\_storage) | nexusiq database allocated storage | `number` | n/a | yes |
| <a name="input_nexusiq_db_instance_class"></a> [nexusiq\_db\_instance\_class](#input\_nexusiq\_db\_instance\_class) | nexusiq database instance class, confirm in AWS docs/console for postgres | `string` | n/a | yes |
| <a name="input_nexusiq_db_max_allocated_storage"></a> [nexusiq\_db\_max\_allocated\_storage](#input\_nexusiq\_db\_max\_allocated\_storage) | Database max allocated storage | `number` | n/a | yes |
| <a name="input_nexusiq_efs_volume_size"></a> [nexusiq\_efs\_volume\_size](#input\_nexusiq\_efs\_volume\_size) | EFS volume storage size in gigabytes | `number` | n/a | yes |
| <a name="input_sonarqube_db_allocated_storage"></a> [sonarqube\_db\_allocated\_storage](#input\_sonarqube\_db\_allocated\_storage) | sonarqube database allocated storage | `number` | n/a | yes |
| <a name="input_sonarqube_db_instance_class"></a> [sonarqube\_db\_instance\_class](#input\_sonarqube\_db\_instance\_class) | sonarqube database instance class, confirm in AWS docs/console for postgres | `string` | n/a | yes |
| <a name="input_sonarqube_db_max_allocated_storage"></a> [sonarqube\_db\_max\_allocated\_storage](#input\_sonarqube\_db\_max\_allocated\_storage) | Database max allocated storage | `number` | n/a | yes |
| <a name="input_use_confluence_db_snapshot"></a> [use\_confluence\_db\_snapshot](#input\_use\_confluence\_db\_snapshot) | User input to use restore confluence databse from snapshot | `bool` | `false` | no |
| <a name="input_use_jira_db_snapshot"></a> [use\_jira\_db\_snapshot](#input\_use\_jira\_db\_snapshot) | User input to use restore jira databse from snapshot | `bool` | `false` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->