################################################################################
# Providers
################################################################################

terraform {
  required_version = ">= 1.10.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.6.0"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 3.0"
    }
    kubectl = {
      source  = "alekc/kubectl"
      version = "2.1.3"
    }
    argocd = {
      source  = "argoproj-labs/argocd"
      version = "7.16.0"
    }
  }
}

################################################################################
################ AWS Provider Configs for applying tags ########################
################################################################################

locals {
  common_tags = {
    Platform    = "DSOP"
    System      = "enterprise"
    Environment = var.environment
    created_by  = "terraform"
    Application = "Platform"
  }
}

# default
provider "aws" {
  region = "us-gov-west-1"
  default_tags {
    tags = local.common_tags
  }
}

# override Application tag for Confluence resources
provider "aws" {
  alias  = "confluence"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Confluence" })
  }
}

# override Application tag for Jira resources
provider "aws" {
  alias  = "jira"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Jira" })
  }
}

# override Application tag for Jira Service Desk resources
provider "aws" {
  alias  = "jsd"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Jira Service Desk" })
  }
}

# override Application tag for Keycloak resources
provider "aws" {
  alias  = "keycloak"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Keycloak" })
  }
}

# override Application tag for Sonarqube resources
provider "aws" {
  alias  = "sonar"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Sonarqube" })
  }
}

# override Application tag for Nexus resources
provider "aws" {
  alias  = "nexus"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Nexus" })
  }
}

# override Application tag for Nexus IQ resources
provider "aws" {
  alias  = "nexus-iq"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Nexus IQ" })
  }
}

############# Using module outputs ###################
provider "helm" {
  kubernetes = {
    host                   = module.eks_cluster.cluster_endpoint
    cluster_ca_certificate = base64decode(module.eks_cluster.cluster_certificate_authority_data)
    token                  = data.aws_eks_cluster_auth.this.token
  }
}

provider "kubectl" {
  host                   = module.eks_cluster.cluster_endpoint
  cluster_ca_certificate = base64decode(module.eks_cluster.cluster_certificate_authority_data)
  token                  = data.aws_eks_cluster_auth.this.token
}

provider "argocd" {
  server_addr = var.argocd_env_server_url
  auth_token  = data.aws_secretsmanager_secret_version.argocd_auth_token.secret_string
}
