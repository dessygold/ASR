################################################################################
# Variables
################################################################################

variable "cluster_name" {
  description = "The name of the EKS cluster"
  type        = string
}

variable "cluster_version" {
  description = "Kubernetes cluster version"
  type        = string
}

variable "logging_bucket_name" {
  description = "The name of the s3 bucket used for logging"
  type        = string
}

variable "environment" {
  description = "Environment for deployed resources: Matches Matches DSO-<system>-<env>"
  type        = string
  validation {
    condition     = var.environment == "dev" || var.environment == "test" || var.environment == "prod"
    error_message = "Deployment environment must be either 'dev', 'test', or 'prod'."
  }
}

variable "internal_private_hosted_zone_name" {
  description = "Name of the private hosted zone to use for internal DNS resolution"
  type        = string
  default     = "enterprise.dso"
}

variable "ebs_kms_key_alias" {
  description = "KMS key alias for EBS encryption"
  type        = string
  validation {
    condition     = startswith(var.ebs_kms_key_alias, "alias/")
    error_message = "The EBS KMS key alias must start with 'alias/'."
  }
  default = "alias/aws/ebs"
}

variable "efs_kms_key_alias" {
  description = "KMS key alias for EFS encryption"
  type        = string
  validation {
    condition     = startswith(var.efs_kms_key_alias, "alias/")
    error_message = "The EFS KMS key alias must start with 'alias/'."
  }
  default = "alias/aws/elasticfilesystem"
}

################################################################################
# Jira Variables
################################################################################

variable "jira_db_instance_class" {
  description = "Jira database instance class, confirm in AWS docs/console for postgres"
  type        = string
}

variable "jira_db_allocated_storage" {
  description = "Jira database allocated storage"
  type        = number
}

variable "jira_db_max_allocated_storage" {
  description = "Confluence database max allocated storage"
  type        = number
}

variable "use_jira_db_snapshot" {
  description = "User input to use restore jira databse from snapshot"
  type        = bool
  default     = false
}

variable "jira_rds_snapshot_id" {
  description = "Snapshot ID for jira db"
  type        = string
  default     = ""
}

variable "jira_shared_pv_volume_size" {
  description = "Size of volume for Jira Shared Persistent Volume"
  type        = number
}

################################################################################
# Confluence Variables
################################################################################

variable "confluence_db_instance_class" {
  description = "Confluence database instance class, confirm in AWS docs/console for postgres"
  type        = string
}

variable "confluence_db_allocated_storage" {
  description = "Confluence database allocated storage"
  type        = number
}

variable "confluence_db_max_allocated_storage" {
  description = "Confluence database max allocated storage"
  type        = number
}

variable "use_confluence_db_snapshot" {
  description = "User input to use restore confluence databse from snapshot"
  type        = bool
  default     = false
}

variable "confluence_rds_snapshot_id" {
  description = "Snapshot ID for confluence db"
  type        = string
  default     = ""
}

variable "confluence_rds_storage_type" {
  description = "rds storage type"
  type        = string
}

################################################################################
# Nexus Variables
################################################################################

variable "nexus_db_instance_class" {
  description = "nexus database instance class, confirm in AWS docs/console for postgres"
  type        = string
}

variable "nexus_db_allocated_storage" {
  description = "nexus database allocated storage"
  type        = number
}

variable "nexus_db_max_allocated_storage" {
  description = "Database max allocated storage"
  type        = number
}

variable "nexus_efs_volume_size" {
  description = "EFS volume storage size in gigabytes"
  type        = number
}


################################################################################
# Keycloak Variables
################################################################################

variable "keycloak_db_instance_class" {
  description = "keycloak database instance class, confirm in AWS docs/console for postgres"
  type        = string
}

variable "keycloak_db_allocated_storage" {
  description = "keycloak database allocated storage"
  type        = number
}

variable "keycloak_db_max_allocated_storage" {
  description = "Database max allocated storage"
  type        = number
}

################################################################################
# Sonarqube Variables
################################################################################

variable "sonarqube_db_instance_class" {
  description = "sonarqube database instance class, confirm in AWS docs/console for postgres"
  type        = string
}

variable "sonarqube_db_allocated_storage" {
  description = "sonarqube database allocated storage"
  type        = number
}

variable "sonarqube_db_max_allocated_storage" {
  description = "Database max allocated storage"
  type        = number
}

################################################################################
# NexusIQ Variables
################################################################################

variable "nexusiq_db_instance_class" {
  description = "nexusiq database instance class, confirm in AWS docs/console for postgres"
  type        = string
}

variable "nexusiq_db_allocated_storage" {
  description = "nexusiq database allocated storage"
  type        = number
}

variable "nexusiq_db_max_allocated_storage" {
  description = "Database max allocated storage"
  type        = number
}

variable "nexusiq_efs_volume_size" {
  description = "EFS volume storage size in gigabytes"
  type        = number
}

################################################################################
# Jira Service Desk Variables
################################################################################

variable "jira_service_desk_db_instance_class" {
  description = "Jira Service Desk database instance class, confirm in AWS docs/console for postgres"
  type        = string
}

variable "jira_service_desk_db_allocated_storage" {
  description = "Jira Service Desk database allocated storage"
  type        = number
}

variable "jira_service_desk_db_max_allocated_storage" {
  description = "Database max allocated storage"
  type        = number
}

variable "jira_service_desk_shared_pv_volume_size" {
  description = "Size of volume for Jira Service Desk Shared Persistent Volume"
  type        = number
}

################################################################################
# ArgoCD Variables
################################################################################

variable "core_aws_account_id" {
  description = "The core account id, based on the environment"
  type        = string
}

variable "argocd_env_server_url" {
  description = "This environments argocd url, exposed by an ingress configured in the core account. Requires 'gitops-core' to have a fully synced argocd application."
  type        = string
}

variable "argocd_auth_token_secret" {
  description = "AWS Secrets Manager secret name for the argocd auth token, located in core account"
  type        = string
  default     = "argocd/auth_token"
}
