################################################################################
# DSOP - ENTERPRISE SYSTEM
################################################################################

module "platform_load_balancer" {
  source  = "code.cdso.army.mil/dsop/platform-load-balancer/aws"
  version = "1.2.3"


  cluster_name               = var.cluster_name
  logging_bucket_name        = var.logging_bucket_name
  default_certificate_domain = var.environment == "prod" ? "jira.dso.army.mil" : var.environment == "test" ? "jira-test.dso.army.mil" : "jira-dev.cdso.army.mil"
}

module "eks_cluster" {
  source  = "code.cdso.army.mil/dsop/eks-cluster/aws"
  version = "3.6.0"

  cluster_name    = var.cluster_name
  cluster_version = var.cluster_version
  system          = "enterprise"
  environment     = var.environment

  # phase in steps: enable cilium startup taint, validate cilium in audit mode, then disable network policy enforcement
  cilium_startup_taint  = false # false by default
  enable_network_policy = true  # true by default

  vpc_id             = local.vpc_id
  vpc_primary_cidr   = local.vpc_primary_cidr
  primary_subnet_ids = local.primary_subnet_ids
}

module "karpenter" {
  source  = "code.cdso.army.mil/dsop/karpenter/aws"
  version = "1.8.0"

  vpc_id = local.vpc_id

  ami_owner_id        = var.environment == "dev" ? "103873143660" : "091602470583"
  aws_ebs_csi_kms_arn = data.aws_kms_key.ebs.arn

  cluster_name    = module.eks_cluster.cluster_name
  cluster_version = module.eks_cluster.cluster_version
  system          = "enterprise"
}

module "argocd_spoke" {
  source  = "code.cdso.army.mil/dsop/argocd-spoke/aws"
  version = "1.1.3"

  system         = "enterprise"
  environment    = var.environment
  cluster_name   = module.eks_cluster.cluster_name
  vpc_id         = local.vpc_id
  aws_account_id = local.aws_account_id

  primary_subnet_ids = local.primary_subnet_ids
  vpc_primary_cidr   = local.vpc_primary_cidr

  core_account_id = var.core_aws_account_id
}

module "confluence_storage" {
  source  = "code.cdso.army.mil/dsop/confluence/aws"
  version = "0.5.1"
  # 0.5.1 has the access point path = "/shared-home"

  vpc_id               = local.vpc_id
  vpc_primary_cidr     = local.vpc_primary_cidr
  primary_subnet_1a_id = local.primary_subnet_1a_id
  primary_subnet_1b_id = local.primary_subnet_1b_id
  primary_subnet_1c_id = local.primary_subnet_1c_id

  aws_account_arn  = local.aws_account_arn
  aws_account_id   = local.aws_account_id
  mgmt_instance_id = local.mgmt_instance_id

  db_identifier = "confluence"
  db_username   = "confluence"
  db_name       = "confluence"

  db_instance_class        = var.confluence_db_instance_class
  db_allocated_storage     = var.confluence_db_allocated_storage
  db_max_allocated_storage = var.confluence_db_max_allocated_storage

  deletion_protection = var.environment == "prod" ? true : false

  postgres_engine_version = "16.9"

  private_zone_id                     = local.private_zone_id
  private_hosted_zone_name            = local.private_hosted_zone_name
  rds_private_hosted_zone_record_name = "confluence-db"

  aws_secretsmanager_secret_name = "confluence/db-password"
  secret_recovery_window_days    = 0

  confluence_shared_pv_volume_size = 64
  efs_kms_key_arn                  = local.efs_kms_key_arn
  enable_efs_backup_policy         = var.environment == "prod" ? true : false

  db_snapshot_identifier = var.use_confluence_db_snapshot == true && var.confluence_rds_snapshot_id != "" ? var.confluence_rds_snapshot_id : null
  rds_storage_type       = var.confluence_rds_storage_type

  # apply confluence tags
  providers = {
    aws = aws.confluence
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "jira_storage" {
  source  = "code.cdso.army.mil/dsop/jira/aws"
  version = "0.6.0"

  vpc_id               = local.vpc_id
  vpc_primary_cidr     = local.vpc_primary_cidr
  primary_subnet_1a_id = local.primary_subnet_1a_id
  primary_subnet_1b_id = local.primary_subnet_1b_id
  primary_subnet_1c_id = local.primary_subnet_1c_id

  aws_account_arn  = local.aws_account_arn
  aws_account_id   = local.aws_account_id
  mgmt_instance_id = local.mgmt_instance_id

  db_identifier = "jira"
  db_username   = "jira"
  db_name       = "jira"

  db_instance_class        = var.jira_db_instance_class
  db_allocated_storage     = var.jira_db_allocated_storage
  db_max_allocated_storage = var.jira_db_max_allocated_storage

  deletion_protection = var.environment == "prod" ? true : false

  postgres_engine_version = "16.9"

  private_zone_id                     = local.private_zone_id
  private_hosted_zone_name            = local.private_hosted_zone_name
  rds_private_hosted_zone_record_name = "jira-db"

  aws_secretsmanager_secret_name = "jira/db-password"
  secret_recovery_window_days    = 0

  jira_shared_pv_volume_size = var.jira_shared_pv_volume_size
  efs_kms_key_arn            = local.efs_kms_key_arn
  enable_efs_backup_policy   = var.environment == "prod" ? true : false

  db_snapshot_identifier = var.use_jira_db_snapshot == true && var.jira_rds_snapshot_id != "" ? var.jira_rds_snapshot_id : null

  # apply jira tags
  providers = {
    aws = aws.jira
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "jira_service_desk_storage" {
  source  = "code.cdso.army.mil/dsop/jira-service-desk/aws"
  version = "0.2.0"

  count = var.environment == "dev" ? 0 : 1

  vpc_id               = local.vpc_id
  vpc_primary_cidr     = local.vpc_primary_cidr
  primary_subnet_1a_id = local.primary_subnet_1a_id
  primary_subnet_1b_id = local.primary_subnet_1b_id
  primary_subnet_1c_id = local.primary_subnet_1c_id

  aws_account_arn  = local.aws_account_arn
  aws_account_id   = local.aws_account_id
  mgmt_instance_id = local.mgmt_instance_id

  db_identifier = "jirasd"
  db_username   = "jira_service_desk"
  db_name       = "jira_service_desk"

  db_instance_class        = var.jira_service_desk_db_instance_class
  db_allocated_storage     = var.jira_service_desk_db_allocated_storage
  db_max_allocated_storage = var.jira_service_desk_db_max_allocated_storage

  deletion_protection = var.environment == "prod" ? true : false

  postgres_engine_version = "16.9"

  private_zone_id                     = local.private_zone_id
  private_hosted_zone_name            = local.private_hosted_zone_name
  rds_private_hosted_zone_record_name = "jira-service-desk-db"

  aws_secretsmanager_secret_name = "jirasd/db-password"
  secret_recovery_window_days    = 0

  jira_service_desk_shared_pv_volume_size = var.jira_service_desk_shared_pv_volume_size
  efs_kms_key_arn                         = local.efs_kms_key_arn
  enable_efs_backup_policy                = var.environment == "prod" ? true : false

  # apply jira service desk tags
  providers = {
    aws = aws.jsd
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "keycloak_storage" {
  source  = "code.cdso.army.mil/dsop/keycloak/aws"
  version = "0.5.0"

  count = var.environment == "dev" ? 0 : 1

  vpc_id               = local.vpc_id
  vpc_primary_cidr     = local.vpc_primary_cidr
  primary_subnet_1a_id = local.primary_subnet_1a_id
  primary_subnet_1b_id = local.primary_subnet_1b_id
  primary_subnet_1c_id = local.primary_subnet_1c_id

  aws_account_id   = local.aws_account_id
  mgmt_instance_id = local.mgmt_instance_id

  db_identifier = "keycloak"
  db_username   = "keycloak"
  db_name       = "keycloak"

  db_instance_class        = var.keycloak_db_instance_class
  db_allocated_storage     = var.keycloak_db_allocated_storage
  db_max_allocated_storage = var.keycloak_db_max_allocated_storage

  deletion_protection = var.environment == "prod" ? true : false

  postgres_engine_version = "16.9"

  private_zone_id                     = local.private_zone_id
  private_hosted_zone_name            = local.private_hosted_zone_name
  rds_private_hosted_zone_record_name = "keycloak-db"

  aws_secretsmanager_secret_name = "keycloak/db-password"
  secret_recovery_window_days    = 0

  # apply keycloak tags
  providers = {
    aws = aws.keycloak
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "sonarqube_storage" {
  source  = "code.cdso.army.mil/dsop/sonarqube/aws"
  version = "0.4.0"

  count = var.environment == "dev" ? 0 : 1

  vpc_id               = local.vpc_id
  vpc_primary_cidr     = local.vpc_primary_cidr
  primary_subnet_1a_id = local.primary_subnet_1a_id
  primary_subnet_1b_id = local.primary_subnet_1b_id
  primary_subnet_1c_id = local.primary_subnet_1c_id

  aws_account_id   = local.aws_account_id
  mgmt_instance_id = local.mgmt_instance_id

  db_identifier = "sonarqube"
  db_username   = "sonarqube"
  db_name       = "sonarqube"

  db_instance_class        = var.sonarqube_db_instance_class
  db_allocated_storage     = var.sonarqube_db_allocated_storage
  db_max_allocated_storage = var.sonarqube_db_max_allocated_storage

  deletion_protection = var.environment == "prod" ? true : false

  postgres_engine_version = "16.9"

  private_zone_id                     = local.private_zone_id
  private_hosted_zone_name            = local.private_hosted_zone_name
  rds_private_hosted_zone_record_name = "sonarqube-db"

  aws_secretsmanager_secret_name = "sonarqube/db-password"
  secret_recovery_window_days    = 0

  # apply sonarqube tags
  providers = {
    aws = aws.sonar
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "nexus_storage" {
  source  = "code.cdso.army.mil/dsop/nexus/aws"
  version = "0.7.3"

  count = var.environment == "dev" ? 0 : 1

  vpc_id               = local.vpc_id
  vpc_primary_cidr     = local.vpc_primary_cidr
  primary_subnet_1a_id = local.primary_subnet_1a_id
  primary_subnet_1b_id = local.primary_subnet_1b_id
  primary_subnet_1c_id = local.primary_subnet_1c_id

  aws_account_arn  = local.aws_account_arn
  aws_account_id   = local.aws_account_id
  mgmt_instance_id = local.mgmt_instance_id

  db_identifier = "nexus"
  db_username   = "nexus_admin"
  db_name       = "nexus_database"

  db_instance_class        = var.nexus_db_instance_class
  db_allocated_storage     = var.nexus_db_allocated_storage
  db_max_allocated_storage = var.nexus_db_max_allocated_storage

  deletion_protection = var.environment == "prod" ? true : false

  postgres_engine_version = "16.9"

  private_zone_id                     = local.private_zone_id
  private_hosted_zone_name            = local.private_hosted_zone_name
  rds_private_hosted_zone_record_name = "nexus-db"

  aws_secretsmanager_secret_name = "nexus/db-password"
  secret_recovery_window_days    = 0

  nexus_efs_volume_size    = var.nexus_efs_volume_size
  efs_kms_key_arn          = local.efs_kms_key_arn
  enable_efs_backup_policy = var.environment == "prod" ? true : false

  nexus_bucket_name   = "dso-${var.environment}-nexus"
  logging_bucket_name = var.logging_bucket_name

  # apply nexus tags
  providers = {
    aws = aws.nexus
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "nexusiq_storage" {
  source  = "code.cdso.army.mil/dsop/nexus-iq/aws"
  version = "0.2.1"

  count = var.environment == "dev" ? 0 : 1

  vpc_id               = local.vpc_id
  vpc_primary_cidr     = local.vpc_primary_cidr
  primary_subnet_1a_id = local.primary_subnet_1a_id
  primary_subnet_1b_id = local.primary_subnet_1b_id
  primary_subnet_1c_id = local.primary_subnet_1c_id

  aws_account_arn  = local.aws_account_arn
  aws_account_id   = local.aws_account_id
  mgmt_instance_id = local.mgmt_instance_id

  db_identifier = "nexusiq"
  db_username   = "nexusiq_admin"
  db_name       = "nexusiq_database"

  db_instance_class        = var.nexusiq_db_instance_class
  db_allocated_storage     = var.nexusiq_db_allocated_storage
  db_max_allocated_storage = var.nexusiq_db_max_allocated_storage

  deletion_protection = var.environment == "prod" ? true : false

  postgres_engine_version = "16.9"

  private_zone_id                     = local.private_zone_id
  private_hosted_zone_name            = local.private_hosted_zone_name
  rds_private_hosted_zone_record_name = "nexusiq-db"

  aws_secretsmanager_secret_name = "nexusiq/db-password"
  secret_recovery_window_days    = 0

  nexusiq_efs_volume_size  = var.nexusiq_efs_volume_size
  efs_kms_key_arn          = local.efs_kms_key_arn
  enable_efs_backup_policy = var.environment == "prod" ? true : false

  nexusiq_bucket_name = "dso-${var.environment}-nexusiq"
  logging_bucket_name = var.logging_bucket_name

  # apply nexus iq tags
  providers = {
    aws = aws.nexus-iq
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "monitoring" {
  source  = "code.cdso.army.mil/dsop/monitoring/aws"
  version = "1.2.3"

  cluster_name       = module.eks_cluster.cluster_name
  vpc_id             = local.vpc_id
  primary_subnet_ids = local.primary_subnet_ids

  logging_bucket_name = var.logging_bucket_name
}
