################################################################################
# EKS Add-ons
################################################################################

################################################################################
# EBS CSI Driver
################################################################################

module "aws_ebs_csi_pod_identity" {
  source  = "terraform-aws-modules/eks-pod-identity/aws"
  version = "2.8.2"

  name                      = "tenant_EBS_CSI"
  aws_ebs_csi_policy_name   = "tenant_EBS_CSI"
  use_name_prefix           = false
  attach_aws_ebs_csi_policy = true

  aws_ebs_csi_kms_arns = [data.aws_kms_key.ebs.arn]
  association_defaults = {
    namespace       = "kube-system"
    service_account = "ebs-csi-controller-sa"
  }

  associations = {
    default = {
      cluster_name = module.eks_cluster.cluster_name
    }
  }
}

resource "aws_eks_addon" "ebs_csi_driver" {
  cluster_name = module.eks_cluster.cluster_name
  addon_name   = "aws-ebs-csi-driver"

  resolve_conflicts_on_create = "OVERWRITE"
  resolve_conflicts_on_update = "OVERWRITE"
}

################################################################################
# EFS CSI Driver
################################################################################

module "aws_efs_csi_pod_identity" {
  source  = "terraform-aws-modules/eks-pod-identity/aws"
  version = "2.8.2"

  name                      = "tenant_EFS_CSI"
  aws_efs_csi_policy_name   = "tenant_EFS_CSI"
  use_name_prefix           = false
  attach_aws_efs_csi_policy = true

  association_defaults = {
    namespace       = "kube-system"
    service_account = "efs-csi-controller-sa"
  }

  associations = {
    default = {
      cluster_name = module.eks_cluster.cluster_name
    }
  }
}

resource "aws_eks_addon" "efs_csi_driver" {
  cluster_name = module.eks_cluster.cluster_name
  addon_name   = "aws-efs-csi-driver"

  resolve_conflicts_on_create = "OVERWRITE"
  resolve_conflicts_on_update = "OVERWRITE"
}
