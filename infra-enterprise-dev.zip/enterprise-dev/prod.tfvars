################################################################################
# Enterprise-Prod Variables
################################################################################

environment         = "prod"
cluster_name        = "enterprise-prod-cluster"
cluster_version     = "1.35"
logging_bucket_name = "dso-enterprise-prod-logs"

jira_db_instance_class        = "db.m5.2xlarge"
jira_db_allocated_storage     = 32
jira_db_max_allocated_storage = 100
use_jira_db_snapshot          = true
jira_rds_snapshot_id          = "jira-prod-snapshot"
jira_shared_pv_volume_size    = 1024

nexus_db_instance_class        = "db.m5.2xlarge"
nexus_db_allocated_storage     = 40
nexus_db_max_allocated_storage = 80
nexus_efs_volume_size          = 10

confluence_db_instance_class        = "db.m5.2xlarge"
confluence_db_allocated_storage     = 64
confluence_db_max_allocated_storage = 128
use_confluence_db_snapshot          = true
confluence_rds_snapshot_id          = "confluence-prod-snapshot"
confluence_rds_storage_type         = "gp2"

keycloak_db_instance_class        = "db.m5.2xlarge"
keycloak_db_allocated_storage     = 40
keycloak_db_max_allocated_storage = 80

sonarqube_db_instance_class        = "db.m5.2xlarge"
sonarqube_db_allocated_storage     = 40
sonarqube_db_max_allocated_storage = 80

jira_service_desk_db_instance_class        = "db.m5.2xlarge"
jira_service_desk_db_allocated_storage     = 40
jira_service_desk_db_max_allocated_storage = 100
jira_service_desk_shared_pv_volume_size    = 64

nexusiq_db_instance_class        = "db.m5.2xlarge"
nexusiq_db_allocated_storage     = 20
nexusiq_db_max_allocated_storage = 80
nexusiq_efs_volume_size          = 10

core_aws_account_id   = "186547511399"
argocd_env_server_url = "argo.cdso.army.mil:443"
