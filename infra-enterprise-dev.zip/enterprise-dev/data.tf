################################################################################
# Data
################################################################################

locals {
  vpc_id               = data.aws_vpc.this.id
  vpc_primary_cidr     = data.aws_vpc.this.cidr_block
  primary_subnet_ids   = data.aws_subnets.primary.ids
  primary_subnet_1a_id = data.aws_subnets.primary_1a.ids[0]
  primary_subnet_1b_id = data.aws_subnets.primary_1b.ids[0]
  primary_subnet_1c_id = data.aws_subnets.primary_1c.ids[0]

  aws_account_id  = data.aws_caller_identity.current.account_id
  aws_account_arn = data.aws_caller_identity.current.arn

  private_hosted_zone_name = data.aws_route53_zone.private.name
  private_zone_id          = data.aws_route53_zone.private.zone_id

  efs_kms_key_arn = data.aws_kms_key.efs.arn

  mgmt_instance_id = data.aws_instance.mgmt.id
}

data "aws_eks_cluster_auth" "this" {
  name = module.eks_cluster.cluster_name
}

data "aws_vpc" "this" {}

data "aws_subnets" "primary" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.this.id]
  }
  filter {
    name   = "cidr-block"
    values = ["10.*"]
  }
}

data "aws_subnets" "primary_1a" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.this.id]
  }
  filter {
    name   = "availability-zone"
    values = ["us-gov-west-1a"]
  }
  filter {
    name   = "cidr-block"
    values = ["10.*"]
  }
}

data "aws_subnets" "primary_1b" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.this.id]
  }
  filter {
    name   = "availability-zone"
    values = ["us-gov-west-1b"]
  }
  filter {
    name   = "cidr-block"
    values = ["10.*"]
  }
}

data "aws_subnets" "primary_1c" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.this.id]
  }
  filter {
    name   = "availability-zone"
    values = ["us-gov-west-1c"]
  }
  filter {
    name   = "cidr-block"
    values = ["10.*"]
  }
}

data "aws_caller_identity" "current" {}

data "aws_kms_key" "ebs" {
  key_id = var.ebs_kms_key_alias
}

data "aws_kms_key" "efs" {
  key_id = var.efs_kms_key_alias
}

data "aws_route53_zone" "private" {
  name         = var.internal_private_hosted_zone_name
  private_zone = true
}

# management node
data "aws_instance" "mgmt" {
  filter {
    name   = "tag:role"
    values = ["mgmt"]
  }
}

data "aws_secretsmanager_secret_version" "argocd_auth_token" {
  # secret exists within this account, synced from core - see argocd module README
  secret_id = var.argocd_auth_token_secret
}
