# Deployment commands

```bash
# pull deploy token out of dsop group CI variables and add to ~/.bashrc
export TF_TOKEN_code_cdso_army_mil="<token>"

# install opentofu
brew install opentofu
```

## Dev

```bash
# paste AWS credentials

tofu init -backend-config="dev.tfbackend"

tofu plan -var-file=dev.tfvars -compact-warnings

tofu apply -var-file=dev.tfvars
```

## Test

```bash
# paste AWS credentials

tofu init -backend-config="test.tfbackend"

tofu plan -var-file=test.tfvars -compact-warnings
tf-summarize tfplan

tofu apply -var-file=test.tfvars
```

## Prod

```bash
# paste AWS credentials

tofu init -backend-config="prod.tfbackend"

tofu plan -var-file=prod.tfvars -compact-warnings
tf-summarize tfplan

tofu apply -var-file=prod.tfvars
```
