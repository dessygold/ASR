# TODO

```bash
# set up port forwarding

kubectl -n monitoring port-forward svc/vmagent-vm-agent 8429:8429 &
kubectl -n monitoring port-forward svc/vmselect-vm-cluster 8481:8481 &
VM_METRICS_URL="http://localhost:8481/select/multitenant/prometheus"
```

```yaml

# add support-manifests to applications that deploy service scrapes

    # support manifests
    - repoURL: https://code.cdso.army.mil/dsop/apps/trust-manager.git
      targetRevision: main
      path: support-manifests
```