plugin "aws" {
    enabled = true
}
