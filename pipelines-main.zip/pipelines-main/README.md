# DSOP Pipelines

## Overview

This repository contains Gitlab CI pipelines and jobs for usage in the **DSOP** group. 

Eventually, these may be integrated into the [cDSO](https://code.cdso.army.mil/cdso) framework. For now, they can be included into infrastructure, helm chart and container application pipelines without conflict to existing `cDSO` workflows.

## Pipelines

| Pipeline                                                                                 | Description                                                                                                                   |
|------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------|
| [`enforce-promotion-source-branch.yaml`](pipelines/enforce-promotion-source-branch.yaml) | enforces `dev -> test -> prod` promotion MR's for relevant repositories                                                       |
| [`external-application.yaml`](pipelines/external-application.yaml)                       | Identifies container images in an external app's helm chart, migrates chart + images to ECR, runs the prebuilt cDSO pipeline. |
| [`external-application-gitlab.yaml`](pipelines/external-application-gitlab.yaml)         | Same as above, specialized for the `gitlab-operator`/`gitlab` chart pair                                                      |
| [`external-application-victoria.yaml`](pipelines/external-application-victoria.yaml)     | Same as above, specialized for the VictoriaMetrics Operator and associated containers                                         |
| [`external-application-grafana.yaml`](pipelines/external-application-grafana.yaml)       | Same as above, specialized for the Grafana Operator & the Grafana image its `docs/docs/versioning.md`                         |
| [`publish-terraform-module.yaml`](pipelines/publish-terraform-module.yaml)               | Validates a terraform module and publishes it to the project's GitLab Terraform Module Registry on a plain-semver tag         |
| [`terraform-deploy.yaml`](pipelines/terraform-deploy.yaml)                               | Lints and plans an OpenTofu root module per branch (dev/test/prod) on Tiny Dancer, writes a tf-summarize report, waits for manual apply |
| [`push-container-to-ecr.yaml`](pipelines/push-container-to-ecr.yaml)                     | Builds a container image with Buildah and pushes it to ECR on tag (or dev builds via `PUSH_CONTAINER_ON_DEV`)                 |
| [`push-helm-chart-to-ecr.yaml`](pipelines/push-helm-chart-to-ecr.yaml)                   | Packages a helm chart and pushes it to ECR on tag (or dev builds via `PUSH_HELM_ON_DEV`)                                      |
| [`terraform-s3-backup.yml`](pipelines/terraform-s3-backup.yml)                           | Validates and archives a terraform module repository to S3 on tag.                                                            |
| [`migrate-plugins.yaml`](pipelines/migrate-plugins.yaml)                                 | Generic plugin migration pipeline. Reads a `.plugins` file and stages each entry to S3                                        |


## Resources
- [Gitlab Docs: CI/CD pipelines](https://docs.gitlab.com/ci/pipelines/)
- [Gitlab Docs: Pipeline architecture](https://docs.gitlab.com/ci/pipelines/pipeline_architectures/)
- [Gitlab Docs: Downstream pipelines](https://docs.gitlab.com/ci/pipelines/downstream_pipelines/)
- [Gitlab Docs: Control how jobs run](https://docs.gitlab.com/ci/jobs/job_control/)
- [Gitlab Docs: Job inputs](https://docs.gitlab.com/ci/jobs/job_inputs/)
- [Gitlab Docs: CI/CD inputs](https://docs.gitlab.com/ci/inputs/)
- [Gitlab Docs: CI/CD variables](https://docs.gitlab.com/ci/variables/)

## Pipeline Examples

### Push container to ECR (tag only)

```yaml
variables:
  APP: my-application

include:
  # container pushed on tag
  - project: 'dsop/pipelines'
    ref: main
    file: 'pipelines/push-container-to-ecr.yaml'
```

### Push container to ECR (all dev builds)

```yaml
variables:
  APP: my-application
  PUSH_CONTAINER_ON_DEV: "true"

include:
  # container pushed on all commits to main branch (all dev containers)
  - project: 'dsop/pipelines'
    ref: main
    file: 'pipelines/push-container-to-ecr.yaml'
```
### Push helm chart to ECR (tag only)

```yaml
variables:
  APP: my-application
  CHART_DIR: my-chart

include:
  # helm chart pushed on tag
  - project: 'dsop/pipelines'
    ref: main
    file: 'pipelines/push-helm-chart-to-ecr.yaml'
```

### Push helm chart to ECR (all dev builds)

```yaml
variables:
  APP: my-application
  CHART_DIR: my-chart
  PUSH_HELM_ON_DEV: "true"

include:
  # helm chart pushed on all commits to main branch (all dev versions)
  - project: 'dsop/pipelines'
    ref: main
    file: 'pipelines/push-helm-chart-to-ecr.yaml'
```
### Terraform deploy (plan + manual apply)

Each push to `dev`, `test` or `prod` lints and plans that environment with `<branch>.tfbackend` and `<branch>.tfvars` (`tflint` errors stop the plan; warnings are only printed), prints a `tf-summarize` table (also saved as `tf-summary.md`), then waits for someone to run `terraform-apply`. Commit `.terraform.lock.hcl` first: the pipeline refuses to run without it.

```yaml
include:
  - project: 'dsop/pipelines'
    ref: main
    file: 'pipelines/terraform-deploy.yaml'

# (optional) only needed if the root module isn't at the repo root
# variables:
#   TF_ROOT: infra

# (optional) only needed if the runner tag isn't td-<project name>-<branch>-tf
# .terraform-deploy-runner:
#   tags: ["td-my-env-${CI_COMMIT_BRANCH}-tf"]
```

**Why the lock file matters:** the Tiny Dancer runner shares one provider cache across jobs, and OpenTofu only uses it when `.terraform.lock.hcl` is committed. Every job runs `tofu init -lockfile=readonly`, so a missing or stale lock file fails the plan instead of quietly downloading providers. The failed job's artifacts include a corrected lock file: review it and commit it. `.terraform/` is kept between jobs (`GIT_CLEAN_FLAGS: -ffdx -e .terraform/`), so modules aren't re-downloaded each run; a changed module version still is.

**Project settings:**

- Protect `dev`, `test` and `prod`. The Tiny Dancer runners are Protected, so they only run jobs from protected branches.
- Merge only through merge requests, with **Pipelines must succeed** turned on.

**Upgrading providers** (in an MR):

```bash
tofu init -upgrade -backend=false
tofu providers lock -platform=linux_amd64
git add .terraform.lock.hcl
```

**Pre-commit hook:** [`hooks/pre-commit-tofu-lock`](hooks/pre-commit-tofu-lock) stops a commit whose `.tf` changes need a lock file update, and prints the fix. It only runs when the commit touches `*.tf` or the lock file, never edits tracked files, and does nothing in repos without a committed lock file (module repos). It runs `tofu init`, so it needs `TF_TOKEN_code_cdso_army_mil` for private modules (see the project's deployment commands). Skip it once with `git commit --no-verify`.

Install it in each infrastructure project you clone:

```bash
cp <path to dsop/pipelines>/hooks/pre-commit-tofu-lock .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

To install it once for every repo instead, use `git config --global core.hooksPath <dir containing it, renamed to pre-commit>`. That replaces each repo's own `.git/hooks`, so only do it if you don't use other hooks.

Set up a local provider cache too, so the hook and your own `tofu init` runs don't re-download providers (it's not a secret, so `~/.bashrc` is fine):

```bash
mkdir -p ~/.terraform.d/plugin-cache
echo 'export TF_PLUGIN_CACHE_DIR="$HOME/.terraform.d/plugin-cache"' >> ~/.bashrc
```

Self-check after changing the hook: `sh hooks/test-pre-commit-tofu-lock.sh`.

### External application

```yaml
variables:
  APP: argo-cd
  SOURCE_HELM_REPO: https://argoproj.github.io/argo-helm
  # OCI_CHART_URL: (use oci repository, choose between SOURCE_HELM_REPO or OCI_CHART_URL)
  # (optional) input required values and/or try to match our actual deployment to gather accurate list of containers
  HELM_VALUES_FILE: pipeline-values.yaml

include:
  - project: dsop/pipelines
    ref: main
    file: pipelines/external-application.yaml

```

### VictoriaMetrics Operator

```yaml
# APP/SOURCE_HELM_REPO already default correctly -- no variables required.
# Set FORCE_VERSION to pin an exact operator version (e.g. to test an -rc release);
# otherwise the latest STABLE (non-rc) operator release is used.

include:
  - project: dsop/pipelines
    ref: main
    file: pipelines/external-application-victoria-metrics-operator.yaml

```

### Plugin migration

Stages plugin archives to S3 so an app (e.g. Grafana) can install them from
there instead of the internet at runtime. Add a `.plugins` file to the repo
root (path configurable via `PLUGIN_FILE`):

```yaml
# .plugins
- name: victoriametrics-metrics-datasource
  version: "0.25.0"
  source: grafana-catalog
  bucketPath: dsop-artifacts/grafana-plugins
- name: victoriametrics-logs-datasource
  version: "0.27.1"
  source: github-release
  repo: VictoriaMetrics/victorialogs-datasource
  archive: tar.gz          # github-release only, defaults to zip
  bucketPath: dsop-artifacts/grafana-plugins
```

```yaml
include:
  - project: dsop/pipelines
    ref: main
    file: pipelines/external-application-plugins.yaml

# (optional) only needed if the plugin list lives somewhere other than ./.plugins
# variables:
#   PLUGIN_FILE: chart/.plugins
#   TINY_DANCER_TAG: some-tiny-dancer
```

Every pipeline run re-migrates the whole list, overwriting whatever's already
at `s3://<bucketPath>/<name>-<version>.zip` -- there's no version-diffing
against upstream, so bump `version` in `.plugins` yourself when you want a
newer release staged.
