# External Application Pipeline

## References

- [AWS: Amazon ECR now supports creating repositories on push](https://aws.amazon.com/about-aws/whats-new/2025/12/amazon-ecr-creating-repositories-on-push/)
- [AWS Docs: Templates to control repositories created during a pull through cache, create on push, or replication action](https://docs.aws.amazon.com/AmazonECR/latest/userguide/repository-creation-templates.html)

## Pipelines

![Migration Pipeline](static/external-applications-migration-pipeline.png)

![Prebuilt Container Pipeline](static/external-applications-prebuilt-pipeline.png)

## ECR Repository Creation Template

Amazon ECR can create a new private repository when you push an image to a repository that does not yet exist.

1. Navigate in the AWS Console: `Amazon ECR > Private Registry > Features & Settings > Repository creation templates`
2. Create Template
3. Template details: [x] Create on push, [x] Any prefix in your ECR registry
4. Image tag settings: [x] Immutable
5. Encryption settings: [x] AES-256 (default)
6. Repository permissions: `AllowCrossAccountPull`

```json
{
  "Version": "2012-10-17",
  "Statement": [
      {
          "Sid": "AllowCrossAccountPull",
          "Effect": "Allow",
          "Principal": {
              "AWS": [
                "arn:aws-us-gov:iam::186527172443:root", # core-dev
                "arn:aws-us-gov:iam::186542266927:root", # core-test
                "arn:aws-us-gov:iam::186547511399:root", # core-prod
                "arn:aws-us-gov:iam::186596499620:root", # runners-dev
                "arn:aws-us-gov:iam::186621868926:root", # runners-test
                "arn:aws-us-gov:iam::186630534491:root"  # runners-prod
                ]
          },
          "Action": [
              "ecr:BatchGetImage",
              "ecr:GetDownloadUrlForLayer"
          ]
      }
  ]
}
```

```bash
# helm login to core-test
<paste AWS credentials>
aws ecr get-login-password --region us-gov-west-1 | helm registry login --username AWS --password-stdin 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com

# pull some helm chart
helm pull external-dns/external-dns --version 1.20.0

# push helm chart to non-existent repository
helm push external-dns-1.20.0.tgz oci://186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/non-existent-repo/

# verify that the new repository 'non-existent-repo/external-dns' has been created and the 1.20.0 chart is present
aws ecr describe-images --repository-name non-existent-repo/external-dns --image-ids imageTag=1.20.0 > /dev/null 2>&1

if [ $? -eq 0 ]; then
    echo "Tagged helm chart found."
else
    echo "Tagged helm chart not found."
fi
```

```bash
# connect to a runners-test EC2 instance
aws sts get-caller-identity

> {
>     "UserId": "AROASW4QEUCSIWLOFQBUN:i-0d7b0f7b7bea7a3ba",
>     "Account": "186596499620",
>     "Arn": "arn:aws-us-gov:sts::186596499620:assumed-role/INSTANCEPROJADMIN/i-0d7b0f7b7bea7a3ba"
> }

# login to core-test ECR
aws ecr get-login-password --region us-gov-west-1 | helm registry login --username AWS --password-stdin 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com

# pull helm chart
helm pull oci://186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/non-existent-repo/external-dns:1.20.0

# verify chart has been pulled
ls external-dns-1.20.0.tgz
```

```bash
# install skopeo on alpine
apk add skopeo

# paste aws credentials and verify
aws sts get-caller-identity

# login to core-test ECR
aws ecr get-login-password --region us-gov-west-1 | helm registry login --username AWS --password-stdin 186542266927.dkr.ecr.us-gov-west-1.amazonaws.com

# copy image
skopeo copy docker://quay.io/jetstack/cert-manager-controller:v1.19.2 docker://186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/brand-new/cert-manager-controller:v1.19.2
```
