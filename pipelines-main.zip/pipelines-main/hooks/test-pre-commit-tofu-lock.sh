#!/bin/sh
# Self-check for pre-commit-tofu-lock. Needs git, tofu and access to registry.opentofu.org.
# Usage: sh hooks/test-pre-commit-tofu-lock.sh
set -eu
hook="$(cd "$(dirname "$0")" && pwd)/pre-commit-tofu-lock"
t=$(mktemp -d)
trap 'rm -rf "$t"' EXIT
cd "$t"
git init -q .

cat > main.tf <<'EOF'
terraform {
  required_providers {
    null = { source = "hashicorp/null", version = "3.2.3" }
  }
}
EOF
tofu init -backend=false -input=false >/dev/null
git add main.tf .terraform.lock.hcl
sh "$hook" >/dev/null || { echo "FAIL: hook rejected a matching lock file"; exit 1; }

# A provider the lock file doesn't know about.
echo 'resource "random_id" "x" { byte_length = 2 }' > extra.tf
git add extra.tf
if sh "$hook" >/dev/null 2>&1; then echo "FAIL: hook accepted a provider missing from the lock file"; exit 1; fi

tofu init -backend=false -input=false >/dev/null
git add .terraform.lock.hcl
sh "$hook" >/dev/null || { echo "FAIL: hook rejected the fixed lock file"; exit 1; }

# A repo with no committed lock file (e.g. a module repo) is left alone.
git rm -q --cached .terraform.lock.hcl
sh "$hook" >/dev/null || { echo "FAIL: hook ran in a repo without a committed lock file"; exit 1; }

echo "OK: passes a matching lock, rejects a missing provider, passes once fixed, skips repos without a lock"
