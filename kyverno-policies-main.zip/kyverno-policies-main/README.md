# Application Template

Overview on what this application is.

System(s) this application deploys to.

Badges:
- cdso pipeline status
- latest helm chart version
- latest application version
- application (internal/external)

Project Labels:
- deployed system
- application (internal/external)

## References
- [source code repository]()
- [official documentation]()
- [relevant article or guide]()

- [**DSOP**: applications terraform module (if applicable)]()

### Documentation

- [DEPLOYMENT.md](./docs/DEPLOYMENT.md)
- [BACKUP-RESTORE.md](./docs/BACKUP-RESTORE.md)
- [SECURITY.md](./docs/SECURITY.md)
- [TROUBLESHOOTING.md](./docs/TROUBLESHOOTING.md)
- [CDSO_STATUS.md](./docs/CDSO_STATUS.md)

## Reference Commands

```bash

helm repo add some-repo https://some-repo.github.io/org/
helm repo update

...
```
