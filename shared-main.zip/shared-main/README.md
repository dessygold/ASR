# Shared Applications (ArgoCD ApplicationSets)

ApplicationSet manifests for DSOP apps shared across all four systems (`core`, `enterprise`, `commercial`, `runners`). 

This repo is deployed to each `core` environment from a single `main` branch, there are no per-environment branches.

## Prerequisite: label every cluster secret with `system`

The ApplicationSets in this repo use a [Matrix generator](https://argo-cd.readthedocs.io/en/stable/operator-manual/applicationset/Generators-Matrix) that joins a git-committed `List` generator (per-system facts: targetRevision, EKS cluster name, subnet IDs, etc.) to a `Clusters` generator, matched on a `system` label:

```yaml
generators:
  - matrix:
      generators:
        - list:
            elements:
              - system: core
              - system: enterprise
              - system: runners
        - clusters:
            selector:
              matchLabels:
                system: '{{.system}}'
```

For this join to work, **every cluster registered to a given ArgoCD instance must carry a `system: <core|enterprise|commercial|runners>` label on its cluster Secret** — including the core instance's own local/core cluster.

Each of the three ArgoCD instances (core-dev, core-test, core-prod) has its own separate set of registered clusters, so the steps below run three times total (once per instance).

### 1. See what's currently registered

```bash
argocd cluster list
```

You should see the local cluster as `in-cluster`, plus one remote entry per
spoke system already reachable from this instance.

### 2. Label the already-registered remote clusters (enterprise, commercial, runners)

These clusters already have a Secret in the `argocd` namespace — just add the
label directly, without touching credentials:

```bash
# find the secret backing each registered cluster
kubectl get secret -n argocd -l argocd.argoproj.io/secret-type=cluster

# label it — repeat for each system registered to this instance
kubectl label secret -n argocd <secret-name> system=enterprise
kubectl label secret -n argocd <secret-name> system=commercial   # test/prod only
kubectl label secret -n argocd <secret-name> system=runners
```

#### Also annotate core, enterprise, and commercial with their VPC ID (for `aws-load-balancer-controller` only)

`vpc_id` has never been committed to git in this repo — it's always been
supplied at Application-creation time by whatever created the root
Application. The `aws-load-balancer-controller` ApplicationSet reads it the
same way, via a cluster Secret annotation instead of a values file. Only
needed on the three systems that run this app (not `runners`):

```bash
kubectl annotate secret -n argocd <secret-name> vpc-id=vpc-xxxxxxxxxxxxxxxxx
```

`argocd cluster list` still won't show custom labels, so confirm with:

```bash
kubectl get secret -n argocd -l argocd.argoproj.io/secret-type=cluster --show-labels
```

### 3. Register core's own cluster explicitly (replacing the implicit `in-cluster` alias)

The implicit `in-cluster` entry has no Secret, so it can't be labeled. Register
it explicitly instead, **keeping the name `in-cluster`** so every existing
Application in `applications/core/templates/` — which all hardcode
`destination.name: in-cluster` — keeps working unchanged:

```bash
argocd cluster add <local-kubeconfig-context> \
  --in-cluster \
  --name in-cluster \
  --label system=core \
  --annotation vpc-id=vpc-xxxxxxxxxxxxxxxxx
```

`--in-cluster` tells Argo CD to connect via the internal
`kubernetes.default.svc` hostname rather than an external endpoint, so this is
safe to run from the same cluster ArgoCD is installed on.

### 4. Verify

```bash
kubectl get secret -n argocd -l argocd.argoproj.io/secret-type=cluster --show-labels
```

Every row should now show a `system=<name>` label, including the `in-cluster`
row.

### If a cluster is already registered and you need to change its label later

Labels can be edited in place without re-adding the cluster:

```bash
kubectl label secret -n argocd <secret-name> system=<name> --overwrite
```

## Moving an existing Application into an ApplicationSet

An ApplicationSet adopts an Application with the same name: it patches the spec and becomes its owner. The old parent
must let go first. Otherwise both controllers self-heal the same Application (for Karpenter, the chart version flips
between old and new on every sync), and removing it from the old parent prunes it: with `resources-finalizer`, that
deletes everything it deployed. For Karpenter that includes the CRDs, so every NodePool and node.

For `commercial-karpenter` (bash, against the core-prod Argo CD cluster):

1. In the old parent's repo, on the `commercial-karpenter` Application manifest: delete the `finalizers` block and add
   these annotations, then merge and let the parent sync.
   ```yaml
   argocd.argoproj.io/sync-options: Prune=false
   argocd.argoproj.io/compare-options: IgnoreExtraneous
   ```
   Check that the live Application has no finalizer:
   ```bash
   kubectl -n argocd get application commercial-karpenter -o jsonpath='{.metadata.finalizers}{"\n"}'   # expect empty
   ```
2. Remove the Application from the old parent's repo and merge. The parent leaves the live Application alone.
3. Merge the `karpenter` enrolment in `values-prod.yaml`. Check the adoption and the upgrade:
   ```bash
   kubectl -n argocd get application commercial-karpenter \
     -o jsonpath='{.metadata.ownerReferences[0].kind}/{.metadata.ownerReferences[0].name} {.spec.sources[0].targetRevision} {.status.sync.status}/{.status.health.status}{"\n"}'
   # expect: ApplicationSet/karpenter 1.15.1 Synced/Healthy
   ```
