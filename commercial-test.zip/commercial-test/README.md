# Commercial Gitops Application

[ArgoCD App-of-apps](https://argo-cd.readthedocs.io/en/stable/operator-manual/cluster-bootstrapping/#app-of-apps-pattern-alternative) Helm chart for the **Commercial** system.

Deployed by the [argocd-spoke terraform module](https://code.cdso.army.mil/dsop/modules/argocd-spoke) and managed remotely by core's ArgoCD.

## Test -> Prod Promotion

Commercial only has **test** and **prod** environments. Each environments ArgoCD instance (running centrally in `core-test` / `core-prod`) tracks the matching branch of this repo via its own `commercial-gitops` root Application, created by the [argocd-spoke teerraform module](https://code.cdso.army.mil/dsop/modules/argocd-spoke) with `target_revision = var.environment`. This chart itself has no per-environment branch logic; the branch is the environment.

Environment-specific facts (`vpc_id`, `cluster_name`, `account_id`, etc.) are **not** committed here. They're passed in as Helm values by the [argocd-spoke terraform module](https://code.cdso.army.mil/dsop/modules/argocd-spoke) when it creates the `commercial-gitops` Application, sourced from the AWS account data.

To promote a change, merge it forward from `test` → `prod`. ArgoCD will pick up the changes and apply them to the cluster.
