{{/* Template gitlab_operator version */}}
{{- define "gitlab_operator_version" -}}
  {{- if eq .Values.environment "test" -}}
    {{ .Values.gitlab_operator_test_version | quote }}
  {{- else if eq .Values.environment "prod" -}}
    {{ .Values.gitlab_operator_prod_version | quote }}
  {{- else -}}
    "0.0.0"
  {{- end -}}
{{- end }}

{{/* Template api_marketplace version */}}
{{- define "api_marketplace_version" -}}
  {{- if eq .Values.environment "test" -}}
    {{ .Values.api_marketplace_test_version | quote }}
  {{- else if eq .Values.environment "prod" -}}
    {{ .Values.api_marketplace_prod_version | quote }}
  {{- else -}}
    "0.0.0"
  {{- end -}}
{{- end }}

{{/* Template AC2SP AMI owner ID */}}
{{- define "ami_owner_id" -}}
  {{- if eq .Values.environment "dev" -}}
    "103873143660"
  {{- else -}}
    "091602470583"
  {{- end -}}
{{- end }}
