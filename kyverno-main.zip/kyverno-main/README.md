# Kyverno

Kyverno is a cloud-native policy engine designed for Kubernetes and JSON-based environments using standard YAML and Common Expression Language to automate security, compliance, and best practices validation. This application also deploy with Openreports, this allows any Kubernetes controller, policy engine, or scanner to produce reports as a Kubernetes custom resource.

## System(s) this application deploys to:
- Core
- Enterprise
- Runners
- Commercial

Badges:
- cdso pipeline status
- latest helm chart version
- latest application version
- application (internal/external)

Project Labels:
- deployed system
- application (internal/external)

## References
- [source code repository](https://github.com/kyverno/kyverno)
- [official documentation](https://kyverno.io/docs/introduction/)
- [relevant article or guide]()

- [**DSOP**: applications terraform module (if applicable)]()

### Documentation

- [DEPLOYMENT.md](./docs/DEPLOYMENT.md)
- [BACKUP-RESTORE.md](./docs/BACKUP-RESTORE.md)
- [SECURITY.md](./docs/SECURITY.md)
- [TROUBLESHOOTING.md](./docs/TROUBLESHOOTING.md)
- [CDSO_STATUS.md](./docs/CDSO_STATUS.md)

## Reference Commands

```bash

helm repo add kyverno https://kyverno.github.io/kyverno/
helm repo update
helm install kyverno kyverno/kyverno -n kyverno --create-namespace

...
```
