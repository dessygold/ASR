# Troubleshooting

This document describes troubleshooting, scripts, tips and tricks for managing this application.

## Scenario `N`

**situation**: when this happens

**response**: do this
