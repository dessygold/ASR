# Backup & Restoration

This document describes the backup and restoration process for this application.