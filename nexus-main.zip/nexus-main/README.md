# Nexus

Sonatype Nexus Repository Manager 3 High Availability (HA) is an enterprise-grade, resilient binary artifact and dependency management platform engineered for continuous uptime and high-throughput CI/CD pipeline integration. Operating in an active-active clustered architecture across a minimum of two nodes, it utilizes an external PostgreSQL database for centralized metadata and shared cloud object storage (such as AWS S3, Azure Blob, or GCP Cloud Storage) or performant network file systems (NFSv4/EFS) for unified blob storage.

This application deploys to Enterprise.

Badges:
- cdso pipeline status
- latest helm chart version
- latest application version
- application (internal/external)

Project Labels:
- app::nexus

## References
- [source code repository](https://github.com/sonatype/nxrm3-ha-repository.git)
- [helm chart repository](https://github.com/sonatype/nxrm3-ha-repository)
- [official documentation](https://help.sonatype.com/en/sonatype-nexus-repository.html)
- [Sonatype guide](https://help.sonatype.com/en/sonatype-guide.html)

- [**DSOP**: applications terraform module](https://code.cdso.army.mil/dsop/modules/nexus.git)

### Documentation

- [DEPLOYMENT.md](./docs/DEPLOYMENT.md)
- [BACKUP-RESTORE.md](./docs/BACKUP-RESTORE.md)
- [SECURITY.md](./docs/SECURITY.md)
- [TROUBLESHOOTING.md](./docs/TROUBLESHOOTING.md)
- [CDSO_STATUS.md](./docs/CDSO_STATUS.md)

## Reference Commands

```bash

helm repo add sonatype https://github.com/sonatype/nxrm3-ha-repository.git
helm repo update

kubectl describe pod nexus-nxrm-ha-0 -n nexus-repo
kubectl exec -it pods/nexus-nxrm-ha-0 -n nexus -- sh
kubectl logs nexus-repo-nxrm-ha-0 -n nexus-repo

```

### Database Storage
Use these commands to check the database storage in test and prod. Run these commands in the AWS CLI in their respective environments.

#### Test
```
DB="nexus-20260331114522978600000016"; ALLOC=$(aws rds describe-db-instances --db-instance-identifier $DB --query "DBInstances[0].AllocatedStorage" --output text); FREE_B=$(aws cloudwatch get-metric-statistics --namespace AWS/RDS --metric-name FreeStorageSpace --dimensions Name=DBInstanceIdentifier,Value=$DB --start-time $(date -u -d "15 minutes ago" +%Y-%m-%dT%H:%M:%SZ) --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) --period 300 --statistics Minimum --query "Datapoints[-1].Minimum" --output text); FREE_G=$(awk "BEGIN {print $FREE_B / 1024^3}"); USED_G=$(awk "BEGIN {print $ALLOC - $FREE_G}"); PCT=$(awk "BEGIN {print ($USED_G / $ALLOC) * 100}"); printf "\n[TEST] Database: %s\nAllocated: %s GiB\nFree Space: %.2f GiB\nUsed Space: %.2f GiB\nUtilization: %.2f%%\n\n" "$DB" "$ALLOC" "$FREE_G" "$USED_G" "$PCT"
```

#### Prod
```
DB="nexus-20260227214508156200000024"; ALLOC=$(aws rds describe-db-instances --db-instance-identifier $DB --query "DBInstances[0].AllocatedStorage" --output text); FREE_B=$(aws cloudwatch get-metric-statistics --namespace AWS/RDS --metric-name FreeStorageSpace --dimensions Name=DBInstanceIdentifier,Value=$DB --start-time $(date -u -d "15 minutes ago" +%Y-%m-%dT%H:%M:%SZ) --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) --period 300 --statistics Minimum --query "Datapoints[-1].Minimum" --output text); FREE_G=$(awk "BEGIN {print $FREE_B / 1024^3}"); USED_G=$(awk "BEGIN {print $ALLOC - $FREE_G}"); PCT=$(awk "BEGIN {print ($USED_G / $ALLOC) * 100}"); printf "\n[PROD] Database: %s\nAllocated: %s GiB\nFree Space: %.2f GiB\nUsed Space: %.2f GiB\nUtilization: %.2f%%\n\n" "$DB" "$ALLOC" "$FREE_G" "$USED_G" "$PCT"
```

### Additional Configuration
To comply with STIG ID APSC-DV-001500 ("The application must be configured to disable non-essential capabilities), certain capabilities need to be disabled through the Nexus UI.

NOTE: Outreach Management appears to be enabled by default in NXRM3. Health Check may not be. If you do not see either of these capabilities in the list of active capabilities, they have not been configured. Please do not configure them.

#### Outreach Management
1. Log in to your NXRM3 instance as an Administrator.
2. Navigate to Administration (gear icon) -> System -> Capabilities.
3. Select the Outreach Management capability from the list.
4. Click the Disable button at the top.

#### Health Check (RHC)
1. Log in to your NXRM3 instance as an Administrator.
2. Navigate to Administration (gear icon) -> System -> Capabilities.
3. Select the Health Check capability from the list.
4. Click the Disable button at the top.