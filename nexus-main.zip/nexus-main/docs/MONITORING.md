# Monitoring Setup

## References
- https://github.com/sonatype/nexus-monitoring
- https://github.com/sonatype/nxrm3-ha-repository
- https://help.sonatype.com/en/usage-metrics.html

- https://help.sonatype.com/en/service-metrics-data-api.html
- https://help.sonatype.com/en/usage-metrics.html
- https://help.sonatype.com/en/success-metrics-data-rest-api.html
- https://help.sonatype.com/en/success-metrics-data-rest-api.html

- https://help.sonatype.com/en/prometheus.html

## Overview

- per [this documentation](https://help.sonatype.com/en/prometheus.html), the prometheus-compatible metrics endpoint is `/service/rest/metrics/prometheus`
- this requires a `nx-metrics-all` privilege to access the endpoint

## Prerequisites

1. log into nexus instance as administrator
2. navigate to **Security > privileges** and verify that `nx-metrics-all` exists
3. navigate to **Security > roles** and create a new role:
    - type: `nexus role`
    - name: `monitoring`
    - id: `monitoring`
    - description: `victoria metrics monitoring role`
    - privileges: `nx-analytics-all`, `nx-users-read`, `nx-metrics-all`, `nx-atlass-all`
4. navigate to **Settings > Security > Users**
5. create local user:
    - user id: `victoria-monitoring`
    - first name: `victoria`
    - last name: `monitoring`
    - email: `noreply@dso.army.mil`
    - initial password: `SomeInitialPassword`
    - roles: `monitoring`
6. run the following commands to verify status:
    ```bash
    # create user token in profile

    export NX_USER=<user code>
    export NX_PW=<passcode>

    # get data about victoria-monitoring user
    curl -X 'GET' \
    'https://nexus-test.dso.army.mil/service/rest/v1/security/users?userId=victoria-monitoring' \
    -H 'accept: application/json' \
    -u $NX_USER:$NX_PW

    # list active realms
    curl -X 'GET' \
    'https://nexus-test.dso.army.mil/service/rest/v1/security/realms/active' \
    -H 'accept: application/json' \
    -u $NX_USER:$NX_PW

    # create user token for victoria-monitoring user
    curl -X POST \
    'https://nexus-test.dso.army.mil/service/rest/v1/security/users/victoria-monitoring/NexusAuthenticatingRealm/user-token' \
    -H 'accept: application/json' \
    -u $NX_USER:$NX_PW

    # identify "nameCode" and "passCode"

    ```

7. create AWS Secrets Manager secret in the relevant **enterprise** account
    - name: `nexus/monitoring`
    - secret keys:
      - **username**: `<value from nameCode>`
      - **password**: `<value from passCode>`
    - description: `metrics access token for victoria-monitoring user`

## Deployed configuration

- `ExternalSecret` that fetches AWS Secrets Manager secret and converts to kubernetes secret
- `VMPodScrape` that references kubernetes secret
- open Grafana Explore and use the promql query to validate: `up{job=~"nexus"}`
