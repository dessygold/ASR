# Backup & Restoration

Refer to the [Nexus3 Backup and Restore Procedure guide](https://help.sonatype.com/en/backup-and-restore.html).

Ultimately there is no DSOP-specific backup procedure for this application. Nexus serves as a proxy repository tool and therefore there is nothing to backup.