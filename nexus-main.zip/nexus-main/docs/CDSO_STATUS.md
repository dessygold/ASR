# cDSO Pipeline Status

## Nexus Container `N`
# Layer Scan
```
============================================================
 IMAGE SCAN REPORT
============================================================
 Image:    registry.cdso.army.mil/dsop/apps/nexus/nexus3
 Platform: linux/amd64
 Size:     464.28 MB
 User:     nexus
============================================================
 STATUS SUMMARY
 [FAIL]   1 Critical Issues
 [WARN]   8 Warnings
 [SUPPRESSED] 0 Suppressed Findings
============================================================
 CRITICAL FINDINGS:
  - Potential secret in ENV variable lacks explicit justification: SONATYPE_WORK
------------------------------------------------------------
 WARNINGS:
  - No HEALTHCHECK defined.
  - Package manager cache leftover lacks explicit justification: var/cache/apk
  - Package manager cache leftover lacks explicit justification: var/cache/apk
  - Package manager cache leftover lacks explicit justification: var/cache/apk/APKINDEX.630cb808.tar.gz
  - Package manager cache leftover lacks explicit justification: var/cache/apk/APKINDEX.9c5ff2cc.tar.gz
  - Package manager cache leftover lacks explicit justification: var/cache/apk
  - Package manager cache leftover lacks explicit justification: var/cache/apk/APKINDEX.630cb808.tar.gz
  - Package manager cache leftover lacks explicit justification: var/cache/apk/APKINDEX.9c5ff2cc.tar.gz
------------------------------------------------------------
```

# Syft Grype Scan
```[•] Starting syft_grype
[•] Running syft on docker-archive:cdso_project.tar
[•] Running grype on syft generated SBOM
[•] Parsing grype results for cDSO
[•] DOCKERFILE_FOLDER: .
[!] Dockerfile not found at ./Dockerfile
Grype DB built on: 2026-09-14T06:38:38Z and has hash sha256:fcdaacfab790b3c45dc911918bab5ec5358171470cfc87b28ef0619e59f141a8
[•] Reading mitigations for nexus3 from: cdso_config.yml
[✓] 0 unmitigated KEV vulnerabilities
[✓] 0 mitigated KEV vulnerabilities
[-] 7 unmitigated vulnerabilities
 »  CVE-2026-5704 (Medium)
    Description: A flaw was found in tar. A remote attacker could exploit this vulnerability by crafting a
    malicious archive, leading to hidden file injection with fully attacker-controlled content. This bypasses
    pre-extraction inspection mechanisms, potentially allowing an attacker to introduce malicious files onto a system
    without detection.
    Artifact: tar
    - Current version: 1.35-r5
    - Vulnerable version(s): none (unknown)
    - Locations: /lib/apk/db/installed
 »  CVE-2026-61308 (Medium)
    Description: Vulnerability in the Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition product of Oracle Java SE (component: Networking).  Supported versions that are affected are Oracle Java SE:
    8u501, 11.0.32, 17.0.20, 21.0.12, 25.0.4, 26.0.2; Oracle GraalVM for JDK: 17.0.20 and  21.0.12; Oracle GraalVM
    Enterprise Edition: 21.3.19. Difficult to exploit vulnerability allows unauthenticated attacker with network access
    via HTTP to compromise Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition.  While the
    vulnerability is in Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition, attacks may
    significantly impact additional products (scope change).  Successful attacks of this vulnerability can result in
    unauthorized access to critical data or complete access to all Oracle Java SE, Oracle GraalVM for JDK, Oracle
    GraalVM Enterprise Edition accessible data. Note: This vulnerability can be exploited by using APIs in the specified
    Component, e.g., through a web service which supplies data to the APIs. This vulnerability also applies to Java
    deployments, typically in clients running sandboxed Java Web Start applications or sandboxed Java applets, that load
    and run untrusted code (e.g., code that comes from the internet) and rely on the Java sandbox for security. CVSS 3.1
    Base Score 6.8 (Confidentiality impacts).  CVSS Vector: (CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:C/C:H/I:N/A:N).
    Artifact: openjdk21
    - Current version: 21.0.12_p8-r0
    - Vulnerable version(s): < 1.8.0_504||>= 1.9, < 8.0.504||>= 12, < 17.0.20.1||>= 18, < 21.0.12.1||>=
    22, < 25.0.4.1||>= 26, < 26.0.2.1||>= 9, < 11.0.32.1 (jvm)
    - Locations: /lib/apk/db/installed
 »  CVE-2025-60876 (Medium)
    Description: BusyBox wget thru 1.3.7 accepted raw CR (0x0D)/LF (0x0A) and other C0 control bytes in
    the HTTP request-target (path/query), allowing the request line to be split and attacker-controlled headers to be
    injected. To preserve the HTTP/1.1 request-line shape METHOD SP request-target SP HTTP/1.1, a raw space (0x20) in
    the request-target must also be rejected (clients should use %20).
    Artifact: busybox
    - Current version: 1.37.0-r31
    - Vulnerable version(s): <= 1.37.0 (unknown)
    - Locations: /lib/apk/db/installed
    Artifact: busybox-binsh
    - Current version: 1.37.0-r31
    - Vulnerable version(s): <= 1.37.0 (unknown)
    - Locations: /lib/apk/db/installed
    Artifact: ssl_client
    - Current version: 1.37.0-r31
    - Vulnerable version(s): <= 1.37.0 (unknown)
    - Locations: /lib/apk/db/installed
 »  CVE-2026-70907 (Medium)
    Description: Vulnerability in the Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise
    Edition product of Oracle Java SE (component: JSSE).  Supported versions that are affected are Oracle Java SE:
    8u501, 11.0.32, 17.0.20, 21.0.12, 25.0.4, 26.0.2; Oracle GraalVM for JDK: 17.0.20 and  21.0.12; Oracle GraalVM
    Enterprise Edition: 21.3.19. Easily exploitable vulnerability allows unauthenticated attacker with network access
    via TLS to compromise Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition.  Successful attacks
    of this vulnerability can result in unauthorized ability to cause a partial denial of service (partial DOS) of
    Oracle Java SE, Oracle GraalVM for JDK, Oracle GraalVM Enterprise Edition. Note: This vulnerability can only be
    exploited by supplying data to APIs in the specified Component without using Untrusted Java Web Start applications
    or Untrusted Java applets, such as through a web service. CVSS 3.1 Base Score 5.3 (Availability impacts).  CVSS
    Vector: (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L).
    Artifact: openjdk21
    - Current version: 21.0.12_p8-r0
    - Vulnerable version(s): < 1.8.0_504||>= 1.9, < 8.0.504||>= 12, < 17.0.20.1||>= 18, < 21.0.12.1||>=
    22, < 25.0.4.1||>= 26, < 26.0.2.1||>= 9, < 11.0.32.1 (jvm)
    - Locations: /lib/apk/db/installed
 »  CVE-2026-58055 (Medium)
    Description: nghttp2's nghttpx proxy through 1.69.0 forwards an HTTP/1.1 Upgrade request that also
    carries a Content-Length header and body onto reusable keep-alive backend connections, re-adding the Upgrade and
    Connection headers while passing Content-Length verbatim. A backend that resolves the resulting ambiguous message in
    the attacker's favor enables HTTP request/response smuggling and cross-client response-queue poisoning.
    Artifact: nghttp2-libs
    - Current version: 1.69.0-r0
    - Vulnerable version(s): <= 1.69.0 (unknown)
    - Locations: /lib/apk/db/installed
 »  CVE-2026-18508 (Medium)
    Description: A flaw was found in GNU tar. When extracting an archive with the --one-top-level option,
    hardlink targets are not confined to the designated top-level directory and may resolve relative to the extraction
    working directory. A crafted archive can create hardlinks that escape the intended boundary and, when combined with
    a preexisting symbolic link under the working directory, may allow writing outside that boundary during a single
    extraction.
    Artifact: tar
    - Current version: 1.35-r5
    - Vulnerable version(s): = 1.35 (unknown)
    - Locations: /lib/apk/db/installed
 »  CVE-2026-18477 (Medium)
    Description: A TOCTOU (Time-of-Check Time-of-Use) vulnerability in GNU tar's incremental dumpdir 'X'
    rename handling allows a local attacker with write access to a directory being backed up to influence the restore
    process if the attacker has access to the system where the restore is being performed. During restoration, files or
    directories may be created, renamed or overwritten outside the intended extraction directory. This could lead to
    unauthorized file modification or, in some cases, privilege escalation. Exploitation does not require the attacker
    to modify or craft the archive, and standard backup and restore workflows—including extracting into a newly created
    directory without using the -P option do not mitigate the issue.
    Artifact: tar
    - Current version: 1.35-r5
    - Vulnerable version(s): = 1.35 (unknown)
    - Locations: /lib/apk/db/installed
[✓] 0 non applicable vulnerabilities
[✓] 0 mitigated vulnerabilities
[•] 1 suppressed vulnerabilities
 »  CVE-2026-60589 (Low)
[x] Job failed
```

## Busy Box Container `N`
No results found for Layer or Syft Grype scan.