# Troubleshooting

This document describes troubleshooting, scripts, tips and tricks for managing this application.

## Scenario `Updating IronBank Proxy Credentials`

Credentials expire every 6 months. Current ones expire: April 24, 2027

Steps to complete:

* Visit: https://repo1.dso.mil/dsop/dccscr/-/issues
* Create New Work Item
* Use Robot Account template

You will immediately receive new credentials via email.

**For General Troubleshooting**: When troubleshooting general problems.

**response**: [Sonatype Troubleshooting Guide](https://help.sonatype.com/index.html?lang=en)
