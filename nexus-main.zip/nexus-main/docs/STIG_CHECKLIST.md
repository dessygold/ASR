# STIG Checklist: Nexus / Nexus IQ

Target application and version:  
Target host / environment:  
STIG benchmark and version: 

## STIG review status

Current metrics on STIG review.

* Date: 
* By: 
* Total rules: 
* Open (non-compliant): 
* Not applicable (N/A): 
* Not reviewed: 
* Closed (compliant): 

## Notes

Some notes can go here. Notes on specifc rules can be found below.

## Rules

Enter notes on any specific rules below.

### Notes on a specific rule

### Notes on another rule

### More notes on a third rule
