################################################################################
# Core-Test Variables
################################################################################

environment                  = "test"
cluster_name                 = "core-test-cluster"
cluster_version              = "1.35"
logging_bucket_name          = "dso-test-logs"
env_private_hosted_zone_name = "core-test.dso"
runners_vpc_primary_cidr     = "10.132.14.0/23"
runners_aws_account_id       = "186621868926"
