################################################################################
# Core-Dev Variables
################################################################################

environment                  = "dev"
cluster_name                 = "core-dev-cluster"
cluster_version              = "1.35"
logging_bucket_name          = "dsop-dev-logs"
env_private_hosted_zone_name = "core-dev.dso"
runners_vpc_primary_cidr     = "10.136.0.0/23"
runners_aws_account_id       = "186596499620"
