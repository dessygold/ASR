################################################################################
# Variables
################################################################################

variable "cluster_name" {
  description = "The name of the EKS cluster"
  type        = string
}

variable "cluster_version" {
  description = "Kubernetes cluster version"
  type        = string
}

variable "logging_bucket_name" {
  description = "The name of the s3 bucket used for logging"
  type        = string
}

variable "runners_vpc_primary_cidr" {
  description = "The runners account VPC primary CIDR. Needed for precog db cross account access."
  type        = string
}

variable "environment" {
  description = "Environment for deployed resources: Matches Matches DSO-<system>-<env>"
  type        = string
  validation {
    condition     = var.environment == "dev" || var.environment == "test" || var.environment == "prod"
    error_message = "Deployment environment must be either 'dev', 'test', or 'prod'."
  }
}

variable "internal_private_hosted_zone_name" {
  description = "Name of the private hosted zone to use for internal DNS resolution"
  type        = string
  default     = "applications.dso"
}

variable "env_private_hosted_zone_name" {
  description = "Name of the private hosted zone to use for cross-account DNS resolution"
  type        = string
}

variable "runners_aws_account_id" {
  description = "The runners account id, based on the environment"
  type        = string
}

variable "ebs_kms_key_alias" {
  description = "KMS key alias for EBS encryption"
  type        = string
  validation {
    condition     = startswith(var.ebs_kms_key_alias, "alias/")
    error_message = "The EBS KMS key alias must start with 'alias/'."
  }
  default = "alias/aws/ebs"
}
