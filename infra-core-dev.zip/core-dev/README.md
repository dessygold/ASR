# Core System Infrastructure

## AWS Accounts

| Environment |    Account     |
| :---------: | :------------: |
|     Dev     | `186527172443` |
|    Test     | `186542266927` |
|    Prod     | `186547511399` |

## Deployment Commands

```bash
# paste core-dev credentials

terraform init -backend-config="dev.tfbackend"

terraform plan -var-file=dev.tfvars -out=tfplan
tf-summarize tfplan

terraform apply -var-file=dev.tfvars

# paste core-test credentials

terraform init -backend-config="test.tfbackend"

terraform plan -var-file=test.tfvars -out=tfplan
tf-summarize tfplan

terraform apply -var-file=test.tfvars

# paste core-prod credentials

terraform init -backend-config="prod.tfbackend"

terraform plan -var-file=prod.tfvars -out=tfplan
tf-summarize tfplan

terraform apply -var-file=prod.tfvars
```

[Terraform-docs](https://terraform-docs.io/) created by running: `terraform-docs markdown table --output-file README.md --output-mode inject .`

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.10.0 |
| <a name="requirement_argocd"></a> [argocd](#requirement\_argocd) | 7.16.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 6.0 |
| <a name="requirement_helm"></a> [helm](#requirement\_helm) | ~> 3.0 |
| <a name="requirement_kubectl"></a> [kubectl](#requirement\_kubectl) | >= 2.4.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >= 3.6.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 6.61.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_argocd"></a> [argocd](#module\_argocd) | code.cdso.army.mil/dsop/argocd/aws | 2.6.3 |
| <a name="module_aws_ebs_csi_pod_identity"></a> [aws\_ebs\_csi\_pod\_identity](#module\_aws\_ebs\_csi\_pod\_identity) | terraform-aws-modules/eks-pod-identity/aws | 2.8.2 |
| <a name="module_aws_lbc_pod_identity"></a> [aws\_lbc\_pod\_identity](#module\_aws\_lbc\_pod\_identity) | terraform-aws-modules/eks-pod-identity/aws | 2.8.2 |
| <a name="module_dependency_track"></a> [dependency\_track](#module\_dependency\_track) | code.cdso.army.mil/dsop/dep-track/aws | 0.9.3 |
| <a name="module_eks_cluster"></a> [eks\_cluster](#module\_eks\_cluster) | code.cdso.army.mil/dsop/eks-cluster/aws | 3.6.0 |
| <a name="module_external_dns_pod_identity"></a> [external\_dns\_pod\_identity](#module\_external\_dns\_pod\_identity) | terraform-aws-modules/eks-pod-identity/aws | 2.10.0 |
| <a name="module_external_secrets_pod_identity"></a> [external\_secrets\_pod\_identity](#module\_external\_secrets\_pod\_identity) | terraform-aws-modules/eks-pod-identity/aws | 2.8.2 |
| <a name="module_gitaly_cluster"></a> [gitaly\_cluster](#module\_gitaly\_cluster) | code.cdso.army.mil/dsop/gitlab-gitaly-cluster/aws | 3.2.3 |
| <a name="module_gitlab_persistent_storage"></a> [gitlab\_persistent\_storage](#module\_gitlab\_persistent\_storage) | code.cdso.army.mil/dsop/gitlab-persistent-storage/aws | 1.11.2 |
| <a name="module_karpenter"></a> [karpenter](#module\_karpenter) | code.cdso.army.mil/dsop/karpenter/aws | 1.8.0 |
| <a name="module_monitoring"></a> [monitoring](#module\_monitoring) | code.cdso.army.mil/dsop/monitoring/aws | 1.2.3 |
| <a name="module_platform_load_balancer"></a> [platform\_load\_balancer](#module\_platform\_load\_balancer) | code.cdso.army.mil/dsop/platform-load-balancer/aws | 1.2.3 |
| <a name="module_precog_server"></a> [precog\_server](#module\_precog\_server) | code.cdso.army.mil/dsop/precog-server/aws | 2.5.4 |

## Resources

| Name | Type |
|------|------|
| [aws_eks_addon.ebs_csi_driver](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eks_addon) | resource |
| [aws_eks_addon.external_dns](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eks_addon) | resource |
| [aws_eks_pod_identity_association.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eks_pod_identity_association) | resource |
| [aws_iam_policy.aws_lbc_additional](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_policy.external_secrets_resource_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_role.s3_artifacts](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.s3_artifacts](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_eks_cluster_auth.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster_auth) | data source |
| [aws_iam_policy_document.aws_lbc_additional](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.pod_identity_trust](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.s3_artifacts_read](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_kms_key.ebs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/kms_key) | data source |
| [aws_route53_zone.applications](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_route53_zone.core_env](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_subnets.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnets) | data source |
| [aws_vpc.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | The name of the EKS cluster | `string` | n/a | yes |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Kubernetes cluster version | `string` | n/a | yes |
| <a name="input_ebs_kms_key_alias"></a> [ebs\_kms\_key\_alias](#input\_ebs\_kms\_key\_alias) | KMS key alias for EBS encryption | `string` | `"alias/aws/ebs"` | no |
| <a name="input_env_private_hosted_zone_name"></a> [env\_private\_hosted\_zone\_name](#input\_env\_private\_hosted\_zone\_name) | Name of the private hosted zone to use for cross-account DNS resolution | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | Environment for deployed resources: Matches Matches DSO-<system>-<env> | `string` | n/a | yes |
| <a name="input_internal_private_hosted_zone_name"></a> [internal\_private\_hosted\_zone\_name](#input\_internal\_private\_hosted\_zone\_name) | Name of the private hosted zone to use for internal DNS resolution | `string` | `"applications.dso"` | no |
| <a name="input_logging_bucket_name"></a> [logging\_bucket\_name](#input\_logging\_bucket\_name) | The name of the s3 bucket used for logging | `string` | n/a | yes |
| <a name="input_runners_aws_account_id"></a> [runners\_aws\_account\_id](#input\_runners\_aws\_account\_id) | The runners account id, based on the environment | `string` | n/a | yes |
| <a name="input_runners_vpc_primary_cidr"></a> [runners\_vpc\_primary\_cidr](#input\_runners\_vpc\_primary\_cidr) | The runners account VPC primary CIDR. Needed for precog db cross account access. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_gitaly_cluster_outputs"></a> [gitaly\_cluster\_outputs](#output\_gitaly\_cluster\_outputs) | n/a |
| <a name="output_local_aws_account_id"></a> [local\_aws\_account\_id](#output\_local\_aws\_account\_id) | n/a |
| <a name="output_local_primary_subnet_ids"></a> [local\_primary\_subnet\_ids](#output\_local\_primary\_subnet\_ids) | n/a |
| <a name="output_local_vpc_id"></a> [local\_vpc\_id](#output\_local\_vpc\_id) | n/a |
| <a name="output_local_vpc_primary_cidr"></a> [local\_vpc\_primary\_cidr](#output\_local\_vpc\_primary\_cidr) | n/a |
| <a name="output_local_vpc_secondary_cidr"></a> [local\_vpc\_secondary\_cidr](#output\_local\_vpc\_secondary\_cidr) | n/a |
<!-- END_TF_DOCS -->