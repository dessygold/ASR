################################################################################
# EKS Add-ons
################################################################################

################################################################################
# EBS CSI Driver
################################################################################

module "aws_ebs_csi_pod_identity" {
  source  = "terraform-aws-modules/eks-pod-identity/aws"
  version = "2.8.2"

  name                      = "tenant_EBS_CSI"
  aws_ebs_csi_policy_name   = "tenant_EBS_CSI"
  use_name_prefix           = false
  attach_aws_ebs_csi_policy = true

  aws_ebs_csi_kms_arns = [data.aws_kms_key.ebs.arn]
  association_defaults = {
    namespace       = "kube-system"
    service_account = "ebs-csi-controller-sa"
  }

  associations = {
    default = {
      cluster_name = module.eks_cluster.cluster_name
    }
  }
}

resource "aws_eks_addon" "ebs_csi_driver" {
  cluster_name = module.eks_cluster.cluster_name
  addon_name   = "aws-ebs-csi-driver"

  resolve_conflicts_on_create = "OVERWRITE"
  resolve_conflicts_on_update = "OVERWRITE"
}

################################################################################
# External DNS
################################################################################

module "external_dns_pod_identity" {
  source  = "terraform-aws-modules/eks-pod-identity/aws"
  version = "2.10.0"

  name                     = "tenant_EXT_DNS"
  external_dns_policy_name = "tenant_EXT_DNS"
  use_name_prefix          = false

  attach_external_dns_policy    = true
  external_dns_hosted_zone_arns = [data.aws_route53_zone.applications.arn, data.aws_route53_zone.core_env.arn]
}

resource "aws_eks_addon" "external_dns" {
  cluster_name = module.eks_cluster.cluster_name
  addon_name   = "external-dns"

  # latest as of oct 29
  addon_version = "v0.24.0-eksbuild.1"

  resolve_conflicts_on_create = "OVERWRITE"
  resolve_conflicts_on_update = "OVERWRITE"

  pod_identity_association {
    role_arn        = module.external_dns_pod_identity.iam_role_arn
    service_account = "external-dns"
  }

  configuration_values = jsonencode({
    policy        = "sync"
    domainFilters = [data.aws_route53_zone.applications.name, data.aws_route53_zone.core_env.name]
    extraArgs     = ["--aws-zone-type=private"]
    # env / extraVolumes / extraVolumeMounts
  })
}
