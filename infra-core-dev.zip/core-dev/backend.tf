##################################################################################
# Core Partial Backend Configuration
#
# https://developer.hashicorp.com/terraform/language/backend#partial-configuration
##################################################################################

terraform {
  backend "s3" {
    key          = ""
    region       = "us-gov-west-1"
    use_lockfile = true
    encrypt      = true
    bucket       = ""
    kms_key_id   = ""
  }
}
