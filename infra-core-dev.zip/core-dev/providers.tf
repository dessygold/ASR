################################################################################
# Providers
################################################################################

terraform {
  required_version = ">= 1.10.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.6.0"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 3.0"
    }
    kubectl = {
      source  = "alekc/kubectl"
      version = ">= 2.4.0"
    }
    argocd = {
      source  = "argoproj-labs/argocd"
      version = "7.16.0"
    }
  }
}

################################################################################
################ AWS Provider Configs for applying tags ########################
################################################################################

locals {
  common_tags = {
    Platform    = "DSOP"
    System      = "core"
    Environment = var.environment
    created_by  = "terraform"
    Application = "Platform"
  }
}

# default
provider "aws" {
  region = "us-gov-west-1"
  default_tags {
    tags = local.common_tags
  }
}

# override Application tag for Gitlab resources
provider "aws" {
  alias  = "gitlab"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Gitlab" })
  }
}

# override Application tag for Dependency Track resources
provider "aws" {
  alias  = "deptrack"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Dependency Track" })
  }
}

# override Application tag for Precog Server resources
provider "aws" {
  alias  = "precog"
  region = "us-gov-west-1"
  default_tags {
    tags = merge(local.common_tags, { Application = "Precog Server" })
  }
}

############# Using module outputs ###################
provider "helm" {
  kubernetes = {
    host                   = module.eks_cluster.cluster_endpoint
    cluster_ca_certificate = base64decode(module.eks_cluster.cluster_certificate_authority_data)
    token                  = data.aws_eks_cluster_auth.this.token
  }
}

provider "kubectl" {
  host                   = module.eks_cluster.cluster_endpoint
  cluster_ca_certificate = base64decode(module.eks_cluster.cluster_certificate_authority_data)
  token                  = data.aws_eks_cluster_auth.this.token
}

################################################################################
#################### ArgoCD Provider Config (Core API) #########################
# this provider only works with kubeconfig updated with the following commands:
#
# aws eks update-kubeconfig --name <cluster>
# kubectl config set-context --current --namespace=argocd
#
# deploy with -target=module.eks_cluster, set the kubeconfig, and continue

provider "argocd" {
  core = true
}
