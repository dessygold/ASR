################################################################################
# Data
################################################################################

locals {
  vpc_primary_cidr   = data.aws_vpc.this.cidr_block
  vpc_secondary_cidr = data.aws_vpc.this.cidr_block_associations[1].cidr_block
  vpc_id             = data.aws_vpc.this.id
  aws_account_id     = data.aws_caller_identity.current.account_id
  primary_subnet_ids = data.aws_subnets.primary.ids
}

data "aws_eks_cluster_auth" "this" {
  name = module.eks_cluster.cluster_name
}

data "aws_vpc" "this" {}

data "aws_subnets" "primary" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.this.id]
  }
  filter {
    name   = "cidr-block"
    values = ["10.*"]
  }
}

data "aws_caller_identity" "current" {}

data "aws_kms_key" "ebs" {
  key_id = var.ebs_kms_key_alias
}

data "aws_route53_zone" "applications" {
  name         = var.internal_private_hosted_zone_name
  private_zone = true
}

data "aws_route53_zone" "core_env" {
  name         = var.env_private_hosted_zone_name
  private_zone = true
}
