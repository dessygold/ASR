################################################################################
# Core-Prod Variables
################################################################################

environment                  = "prod"
cluster_name                 = "dso-services"
cluster_version              = "1.35"
logging_bucket_name          = "dso-logs"
env_private_hosted_zone_name = "core-prod.dso"
runners_vpc_primary_cidr     = "10.140.4.0/23"
runners_aws_account_id       = "186630534491"
