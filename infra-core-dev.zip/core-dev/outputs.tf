################################################################################
# Outputs
################################################################################

# gitaly cluster module outputs commands to run/debug ansible ssm associations

output "gitaly_cluster_outputs" {
  value = module.gitaly_cluster
}

output "local_vpc_primary_cidr" {
  value = local.vpc_primary_cidr
}

output "local_vpc_secondary_cidr" {
  value = local.vpc_secondary_cidr
}

output "local_vpc_id" {
  value = local.vpc_id
}

output "local_aws_account_id" {
  value = local.aws_account_id
}

output "local_primary_subnet_ids" {
  value = local.primary_subnet_ids
}
