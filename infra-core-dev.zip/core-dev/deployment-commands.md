# Deployment commands

```bash
# pull deploy token out of dsop group CI variables and add to ~/.bashrc
export TF_TOKEN_code_cdso_army_mil="<token>"

# install opentofu
brew install opentofu

# show tf-summarize with json plan
tofu show -json tfplan > plan.json
tf-summarize plan.json

# recommended: add 'export TF_BINARY=tofu` to ~/.bashrc instead
```

## Kubeconfig prerequisite (all environments)

The `argocd` provider runs in `core` mode, which talks to the Kubernetes API directly using
whatever is set as the *current context* in the local kubeconfig — not anything passed via
Terraform. This must be set up before any `tofu plan` or `tofu apply` that touches the argocd
provider, and it has to be redone any time the shell's kubeconfig context changes:

```bash
aws eks update-kubeconfig --name <cluster_name>       # e.g. core-dev-cluster
kubectl config set-context --current --namespace=argocd
```

The namespace step is easy to forget and not optional: `core` mode resolves its target
namespace from the current context's namespace, defaulting to `default` if unset — not
hardcoded to `argocd`. Skipping it fails with `configmap "argocd-cm" not found` even though
the configmap exists.

On a brand new cluster (nothing deployed yet, so no kubeconfig can exist), bootstrap in two
passes:

```bash
tofu apply -var-file=dev.tfvars -target=module.eks_cluster   # cluster must exist first
# then run the kubeconfig prerequisite above
tofu apply -var-file=dev.tfvars                               # full apply, no -target
```

## Dev

```bash
# paste AWS credentials

tofu init -backend-config="dev.tfbackend"

# kubeconfig prerequisite — see above

tofu plan -var-file=dev.tfvars -compact-warnings

tofu apply -var-file=dev.tfvars
```

## Test

```bash
# paste AWS credentials

tofu init -backend-config="test.tfbackend"

# kubeconfig prerequisite — see above

tofu plan -var-file=test.tfvars -compact-warnings
tf-summarize tfplan

tofu apply -var-file=test.tfvars
```

## Prod

```bash
# paste AWS credentials

tofu init -backend-config="prod.tfbackend"

# kubeconfig prerequisite — see above

tofu plan -var-file=prod.tfvars -compact-warnings
tf-summarize tfplan

tofu apply -var-file=prod.tfvars
```
