################################################################################
# External Secrets Operator
################################################################################

resource "aws_iam_policy" "external_secrets_resource_policy" {
  name        = "tenant_EXTERNAL_SECRETS_OPERATOR_ResourcePolicy"
  description = "Allow ESO PushSecret reconciles to manage Secrets Manager resource-based policies"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "secretsmanager:PutResourcePolicy",
        "secretsmanager:DeleteResourcePolicy",
      ]
      Resource = "arn:aws-us-gov:secretsmanager:us-gov-west-1:*:secret:*"
    }]
  })
}

module "external_secrets_pod_identity" {
  source  = "terraform-aws-modules/eks-pod-identity/aws"
  version = "2.8.2"

  name                         = "tenant_EXTERNAL_SECRETS_OPERATOR"
  external_secrets_policy_name = "tenant_EXTERNAL_SECRETS_OPERATOR"
  use_name_prefix              = false

  attach_external_secrets_policy        = true
  external_secrets_create_permission    = true
  external_secrets_secrets_manager_arns = ["arn:aws-us-gov:secretsmanager:us-gov-west-1:*:secret:*"]

  additional_policy_arns = {
    ecr_read_only   = "arn:aws-us-gov:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
    resource_policy = aws_iam_policy.external_secrets_resource_policy.arn
  }

  associations = {
    default = {
      cluster_name    = module.eks_cluster.cluster_name
      namespace       = "external-secrets"
      service_account = "external-secrets"
    }
  }
}

################################################################################
# AWS Load Balancer Controller
################################################################################

module "aws_lbc_pod_identity" {
  source  = "terraform-aws-modules/eks-pod-identity/aws"
  version = "2.8.2"

  name                          = "tenant_AWS_LBC"
  aws_lb_controller_policy_name = "tenant_AWS_LBC"
  use_name_prefix               = false

  attach_aws_lb_controller_policy = true
  additional_policy_arns = {
    aws_lbc_additional = aws_iam_policy.aws_lbc_additional.arn
  }

  associations = {
    default = {
      cluster_name    = module.eks_cluster.cluster_name
      namespace       = "kube-system"
      service_account = "aws-load-balancer-controller"
    }
  }
}

resource "aws_iam_policy" "aws_lbc_additional" {
  name        = "tenant_AWS_LBC_ADDITIONAL"
  description = "Prevents AWS Load Balancer Controller from deleting platform load balancer"
  policy      = data.aws_iam_policy_document.aws_lbc_additional.json
}

data "aws_iam_policy_document" "aws_lbc_additional" {
  statement {
    effect    = "Deny"
    resources = ["arn:aws-us-gov:elasticloadbalancing:us-gov-west-1:${local.aws_account_id}:loadbalancer/app/platform-alb/*"]

    actions = ["elasticloadbalancing:DeleteLoadBalancer"]
  }

  statement {
    effect    = "Deny"
    resources = ["*"]

    actions = ["elasticloadbalancing:DeleteLoadBalancer"]

    condition {
      test     = "StringEquals"
      variable = "aws:ResourceTag/ingress.k8s.aws/stack"
      values   = ["platform"]
    }
  }
}
