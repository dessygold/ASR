################################################################################
# DSOP - CORE SYSTEM
################################################################################

module "platform_load_balancer" {
  source  = "code.cdso.army.mil/dsop/platform-load-balancer/aws"
  version = "1.2.3"


  cluster_name               = var.cluster_name
  logging_bucket_name        = var.logging_bucket_name
  default_certificate_domain = var.environment == "prod" ? "dso.army.mil" : "dso-${var.environment}.army.mil"
}

module "eks_cluster" {
  source  = "code.cdso.army.mil/dsop/eks-cluster/aws"
  version = "3.6.0"

  cluster_name    = var.cluster_name
  cluster_version = var.cluster_version
  system          = "core"
  environment     = var.environment

  # phase in steps: enable cilium startup taint, validate cilium in audit mode, then disable network policy enforcement
  cilium_startup_taint  = false # false by default
  enable_network_policy = true  # true by default

  vpc_id             = local.vpc_id
  vpc_primary_cidr   = local.vpc_primary_cidr
  primary_subnet_ids = local.primary_subnet_ids
}

module "karpenter" {
  source  = "code.cdso.army.mil/dsop/karpenter/aws"
  version = "1.8.0"

  vpc_id = local.vpc_id

  ami_owner_id        = var.environment == "dev" ? "103873143660" : "091602470583"
  aws_ebs_csi_kms_arn = data.aws_kms_key.ebs.arn

  cluster_name    = module.eks_cluster.cluster_name
  cluster_version = module.eks_cluster.cluster_version
  system          = "core"
}

module "argocd" {
  source  = "code.cdso.army.mil/dsop/argocd/aws"
  version = "2.6.3"

  environment        = var.environment
  system             = "core"
  cluster_name       = module.eks_cluster.cluster_name
  vpc_id             = local.vpc_id
  aws_account_id     = local.aws_account_id
  primary_subnet_ids = local.primary_subnet_ids

  deployment_group_token_secret = "gitops/dsop_group_token"

  depends_on = [
    module.aws_lbc_pod_identity,
    module.external_secrets_pod_identity
  ]
}

module "gitlab_persistent_storage" {
  source  = "code.cdso.army.mil/dsop/gitlab-persistent-storage/aws"
  version = "1.11.2"

  cluster_name             = module.eks_cluster.cluster_name
  environment              = var.environment
  logging_bucket_name      = var.logging_bucket_name
  private_hosted_zone_name = var.internal_private_hosted_zone_name

  vpc_id             = local.vpc_id
  vpc_primary_cidr   = local.vpc_primary_cidr
  vpc_secondary_cidr = local.vpc_secondary_cidr
  primary_subnet_ids = local.primary_subnet_ids
  aws_account_id     = local.aws_account_id

  # apply gitlab tags
  providers = {
    aws = aws.gitlab
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "gitaly_cluster" {
  source  = "code.cdso.army.mil/dsop/gitlab-gitaly-cluster/aws"
  version = "3.2.3"

  gitlab_version = "19.5.3"

  environment              = var.environment
  private_hosted_zone_name = var.internal_private_hosted_zone_name

  system = "core"

  vpc_id             = local.vpc_id
  vpc_primary_cidr   = local.vpc_primary_cidr
  vpc_secondary_cidr = local.vpc_secondary_cidr
  primary_subnet_ids = local.primary_subnet_ids

  gitaly_node_volume_size = var.environment == "prod" ? 3000 : 20

  # "check mode" is an ansible dry run, var.association_check_mode is true by default
  # turning association_check_mode to "false" will package config changes and run ansible playbook on gitaly/praefect nodes
  # association_check_mode = false

  # configure gitaly/praefect nodes to ship logs to VictoriaLogs ingest endpoint via fluent-bit config
  enable_log_shipping = true

  # enable TLS but keep HTTP listeners enabled until we feel comfortable switching them off
  enable_tls                  = true
  disable_plaintext_listeners = false

  # apply gitlab tags
  providers = {
    aws = aws.gitlab
  }

  depends_on = [
    module.eks_cluster,
    module.gitlab_persistent_storage
  ]
}

module "dependency_track" {
  source  = "code.cdso.army.mil/dsop/dep-track/aws"
  version = "0.9.3"

  environment         = var.environment
  logging_bucket_name = var.logging_bucket_name

  vpc_id             = local.vpc_id
  vpc_primary_cidr   = local.vpc_primary_cidr
  primary_subnet_ids = local.primary_subnet_ids

  aws_account_id = local.aws_account_id

  private_hosted_zone_name = var.internal_private_hosted_zone_name

  cluster_oidc_provider_arn = module.eks_cluster.cluster_oidc_provider_arn

  # apply deptrack tags
  providers = {
    aws = aws.deptrack
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "precog_server" {
  source  = "code.cdso.army.mil/dsop/precog-server/aws"
  version = "2.5.4"

  environment = var.environment

  cluster_name             = module.eks_cluster.cluster_name
  logging_bucket_name      = var.logging_bucket_name
  vpc_id                   = local.vpc_id
  vpc_primary_cidr         = local.vpc_primary_cidr
  vpc_secondary_cidr       = local.vpc_secondary_cidr
  primary_subnet_ids       = local.primary_subnet_ids
  aws_account_id           = local.aws_account_id
  private_hosted_zone_name = var.env_private_hosted_zone_name

  runners_vpc_primary_cidr = var.runners_vpc_primary_cidr
  runners_aws_account_id   = var.runners_aws_account_id

  # apply precog-server tags
  providers = {
    aws = aws.precog
  }

  depends_on = [
    module.eks_cluster
  ]
}

module "monitoring" {
  source  = "code.cdso.army.mil/dsop/monitoring/aws"
  version = "1.2.3"

  cluster_name       = module.eks_cluster.cluster_name
  vpc_id             = local.vpc_id
  primary_subnet_ids = local.primary_subnet_ids

  logging_bucket_name = var.logging_bucket_name
}
