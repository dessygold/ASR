################################################################################
# S3 Bucket Access to dsop-artifacts
################################################################################

# update this local variable with any enterprise worklaods that need access to the dsop-arifacts bucket

locals {
  workloads = {
    grafana = {
      namespace       = "monitoring"
      service_account = "grafana-sa"
    }
  }
}

data "aws_iam_policy_document" "pod_identity_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole", "sts:TagSession"]

    principals {
      type        = "Service"
      identifiers = ["pods.eks.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "s3_artifacts_read" {
  statement {
    sid       = "ReadArtifacts"
    effect    = "Allow"
    actions   = ["s3:GetObject"]
    resources = ["arn:aws-us-gov:s3:::dsop-artifacts/*"]
  }

  statement {
    sid       = "ListArtifacts"
    effect    = "Allow"
    actions   = ["s3:ListBucket"]
    resources = ["arn:aws-us-gov:s3:::dsop-artifacts"]
  }
}

resource "aws_iam_role" "s3_artifacts" {
  name               = "tenant_DSOP_ARTIFACTS_ACCESS"
  assume_role_policy = data.aws_iam_policy_document.pod_identity_trust.json
}

resource "aws_iam_role_policy" "s3_artifacts" {
  name   = "tenant_DSOP_ARTIFACTS_ACCESS"
  role   = aws_iam_role.s3_artifacts.id
  policy = data.aws_iam_policy_document.s3_artifacts_read.json
}

resource "aws_eks_pod_identity_association" "this" {
  for_each = local.workloads

  cluster_name    = module.eks_cluster.cluster_name
  namespace       = each.value.namespace
  service_account = each.value.service_account
  role_arn        = aws_iam_role.s3_artifacts.arn
}