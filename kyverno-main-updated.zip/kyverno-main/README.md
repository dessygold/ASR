# Kyverno

Kyverno is a cloud-native policy engine designed for Kubernetes and JSON-based environments using standard YAML and Common Expression Language (CEL) to automate security, compliance, and best practices validation. This application also deploys with OpenReports, which allows any Kubernetes controller, policy engine, or scanner to produce reports as a Kubernetes custom resource.

**Systems:** Core, Enterprise, Runners, Commercial

## Containers

This chart deploys the following containers (see [cdso_config.yml](./cdso_config.yml) for the full cDSO registration of each):

| Container | Role |
|---|---|
| `kyverno` | Admission controller — main container, handles the validating/mutating admission webhook |
| `kyvernopre` | Admission controller init container — pre-upgrade cleanup of stale webhook/policy state |
| `background-controller` | Runs background scans of existing resources against policies and handles `generate`/`mutate-existing` rules |
| `cleanup-controller` | Executes `CleanupPolicy`/`ClusterCleanupPolicy` resources on their schedule |
| `reports-controller` | Aggregates `PolicyReport`/`ClusterPolicyReport` (and OpenReports) results |
| `kyverno-cli` | Used by the Helm chart's CRD-migration post-upgrade hook |
| `readiness-checker` | Used by the Helm test hook and the pre-delete webhook-cleanup hook |

## References
- [source code repository](https://github.com/kyverno/kyverno)
- [official documentation](https://kyverno.io/docs/introduction/)
- [Kyverno policy library (sample/community policies)](https://kyverno.io/policies/)
- [Kyverno CLI reference](https://kyverno.io/docs/kyverno-cli/)

- **DSOP**: applications terraform module — N/A. Kyverno has no cloud infrastructure dependency; it is deployed entirely via Helm/GitOps into an existing EKS cluster (see [DEPLOYMENT.md](./docs/DEPLOYMENT.md)).

### Documentation

- [DEPLOYMENT.md](./docs/DEPLOYMENT.md)
- [BACKUP-RESTORE.md](./docs/BACKUP-RESTORE.md)
- [SECURITY.md](./docs/SECURITY.md)
- [TROUBLESHOOTING.md](./docs/TROUBLESHOOTING.md)
- [CDSO_STATUS.md](./docs/CDSO_STATUS.md)
- [REFERENCE-GUIDE.md](./docs/REFERENCE-GUIDE.md)

## Reference Commands

```bash
# https://kyverno.io/docs/installation/methods/

helm repo add kyverno https://kyverno.github.io/kyverno/
helm repo update
helm install kyverno kyverno/kyverno -n kyverno --create-namespace -f helm-values/values.yaml

# show unique containers running in the kyverno namespace

kubectl get pods -n kyverno -o json | jq -r ' .items[] | (.spec.initContainers[]? | "[init] \(.name): \(.image)"), (.spec.containers[]? | "\(.name): \(.image)")' | sort -u

# list all cluster-scoped and namespaced policies

kubectl get clusterpolicies,policies -A

# list policy reports (compliance results) across the cluster

kubectl get policyreports,clusterpolicyreports -A

# tail admission controller logs (most common place to look when something is unexpectedly blocked/mutated)

kubectl logs -n kyverno -l app.kubernetes.io/component=admission-controller -f

# dry-run a policy against a resource with the Kyverno CLI before applying it cluster-wide

kyverno apply my-policy.yaml --resource my-resource.yaml
```
