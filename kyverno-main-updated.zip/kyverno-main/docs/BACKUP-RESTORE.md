# Backup & Restoration

This document describes the backup and restoration process for this application.

Kyverno holds no persistent volumes and no database — all of its state is one of:

- **Policy definitions** (`ClusterPolicy`, `Policy`, `CleanupPolicy`, `PolicyException`, and the `policies.kyverno.io` CRDs) — these are expected to be managed declaratively via GitOps (source of truth is Git, not the cluster), so they do not need a dedicated backup process. Recovery is: re-apply from Git.
- **PolicyReport / ClusterPolicyReport / EphemeralReport / OpenReports objects** — derived, disposable state. The reports-controller regenerates these from live cluster state and current policies; nothing is lost if they're wiped, they just repopulate on the next admission/background-scan cycle.
- **The `kyverno` ConfigMap** (`config.create: true`) — generated from Helm values (`helm-values/values.yaml`), not hand-edited. Recovery is: `helm upgrade`/reconcile from the chart + values.

If the whole cluster's etcd is backed up (e.g. via Velero or an EKS-level backup process), Kyverno's CRDs and custom resources are captured incidentally as part of that — no application-specific backup job is required.

**Restoration**: reinstall the Helm release (see [DEPLOYMENT.md](./DEPLOYMENT.md)) and re-apply policy manifests from their Git source. There is no ordering dependency on other data stores.
