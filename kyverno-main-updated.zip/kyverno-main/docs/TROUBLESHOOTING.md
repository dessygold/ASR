# Troubleshooting

This document describes troubleshooting, scripts, tips and tricks for managing this application.

## A deployment/resource is unexpectedly being blocked or mutated

**situation**: a workload create/update is being rejected, or is coming back mutated in a way you didn't expect, and it's not obvious which policy is responsible.

**response**:
```bash
# find which ClusterPolicy/Policy rules exist and whether they're in audit or enforce mode
kubectl get clusterpolicies,policies -A -o custom-columns=NAME:.metadata.name,BACKGROUND:.spec.background,VALIDATIONFAILUREACTION:.spec.validationFailureAction

# check recent admission decisions/events for the resource's namespace
kubectl get events -n <namespace> --field-selector reason=PolicyViolation

# tail the admission-controller logs while reproducing the request
kubectl logs -n kyverno -l app.kubernetes.io/component=admission-controller -f

# dry-run the exact manifest against a specific policy locally with the CLI before touching the cluster
kyverno apply <policy>.yaml --resource <resource>.yaml
```

## Policy shows violations only sometimes ("it passed at apply-time but shows failing now")

**situation**: a resource was accepted at admission time (or predates a policy) but now shows up failing in `PolicyReport`.

**response**: this is the background-controller doing its periodic re-scan (`features.backgroundScan.backgroundScanInterval`, default `1h`) — it evaluates policies against resources that already exist in the cluster, independent of the original admission decision. Check:
```bash
kubectl get policyreports,clusterpolicyreports -A
kubectl logs -n kyverno -l app.kubernetes.io/component=background-controller -f
```

## Admission webhook is timing out / slowing down the API server

**situation**: `kubectl` commands or controller reconciles are slow cluster-wide, and `kubectl get events` shows webhook timeout errors referencing Kyverno's webhook.

**response**: check admission-controller resource pressure and the metrics dashboard first (`kyverno_admission_review_duration_seconds`, see [support-manifests/grafana-dashboard.yaml](../support-manifests/grafana-dashboard.yaml)/[victoria-VMServiceScrape.yaml](../support-manifests/victoria-VMServiceScrape.yaml)):
```bash
kubectl top pods -n kyverno
kubectl get validatingwebhookconfigurations,mutatingwebhookconfigurations -o wide | grep kyverno
```
If a specific policy's rule is expensive (e.g. it makes an external API call via `context.apiCall`), consider whether it needs `background: true`/`admission: false` instead of running synchronously on every request, or whether its `failurePolicy` should be `Ignore` so a slow/unavailable dependency doesn't block unrelated admissions.

## CRD migration job failed after a Helm upgrade

**situation**: `helm upgrade` completed but the post-upgrade migration hook Job (image: `kyverno-cli`, see `crds.migration`) failed or is stuck.

**response**:
```bash
kubectl get jobs -n kyverno
kubectl logs -n kyverno job/<migration-job-name>
```
Re-run the upgrade once the underlying issue is fixed — the migration job is idempotent and safe to re-trigger via `helm upgrade` again.

## Reports controller isn't reflecting recent scan results

**situation**: `kubectl get policyreports -A` looks stale relative to recent admission/background-scan activity.

**response**: `PolicyReport`/`ClusterPolicyReport` objects are aggregated by the reports-controller from `EphemeralReport`/`ClusterEphemeralReport` objects — check that the reports-controller pod is healthy and not falling behind:
```bash
kubectl get pods -n kyverno -l app.kubernetes.io/component=reports-controller
kubectl get ephemeralreports,clusterephemeralreports -A | wc -l
kubectl logs -n kyverno -l app.kubernetes.io/component=reports-controller -f
```
