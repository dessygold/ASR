# Security

This document describes the security posture for this application.

## Admission webhook is a cluster-wide chokepoint

- **situation**: the admission-controller's `ValidatingWebhookConfiguration`/`MutatingWebhookConfiguration` sits in the request path for most resource kinds cluster-wide (`kube-system` and the chart's own resources are excluded via `config.resourceFilters` / `excludeKyvernoNamespace`). If the admission-controller pods are unavailable or slow, this can block or delay unrelated workload creation/updates cluster-wide, depending on each `ClusterPolicy`'s `failurePolicy`.

- **mitigation**: `antiAffinity` spreads admission-controller pods across nodes, `startupProbe`/`livenessProbe`/`readinessProbe` are configured against `/health/liveness` and `/health/readiness`, and `podDisruptionBudget` can be enabled for HA (currently `enabled: false` in the upstream defaults — worth revisiting with a POC if `replicas` > 1 is used). Review each policy's `failurePolicy` (Ignore vs Fail) against how critical it is that the policy actually be enforced vs. that it not block the API server.

## Broad RBAC surface

- **situation**: to validate, mutate, and generate arbitrary resource kinds, Kyverno's ClusterRoles necessarily grant broad read (and, for `generate`/`mutate-existing` policies, write) access across many API groups. `admissionController.rbac.clusterRole.extraResources` and `coreClusterRole.extraResources` can add still more.

- **mitigation**: RBAC is chart-managed (`rbac.roles.aggregate`) rather than hand-maintained, so it tracks upstream's least-privilege intent for each controller. `config.excludeGroups`/`excludeUsernames`/`excludeRoles`/`excludeClusterRoles` scope which callers are exempt from policy evaluation — review these against DSOP's actual privileged service accounts (e.g. cluster-admin tooling, CI service accounts) so policies aren't silently bypassed for accounts that shouldn't be exempt.

## Webhook TLS certificate management

- **situation**: `admissionController.certManager.enabled: false` and `createSelfSignedCert: false` in our current values, meaning the admission-controller relies on Kyverno's own internal self-signed certificate generation/rotation rather than cert-manager-issued certs.

- **mitigation**: acceptable for now since cert-manager is already deployed in-cluster for other apps (see the DSOP `trust-manager` project, a separate repo); if consistency with cert-manager-issued certs is desired DSOP-wide, `admissionController.certManager.enabled: true` with `issuerRef` pointed at an existing (Cluster)Issuer is a low-risk follow-up.

## Supply-chain / image verification policies

- **situation**: Kyverno supports `imageVerify` rules (cosign/Sigstore signature and attestation verification) and a TUF root (`features.tuf`) for keyless/rekor-based verification. These are **not currently enabled** (`features.tuf.enabled: false`) and no image verification policies ship with this repo.

- **mitigation**: N/A today (feature unused) — flagged here so it's visible for a future work item if DSOP wants to enforce signed-image policies at admission time.

## Policy exceptions

- **situation**: `features.policyExceptions.enabled: false` — `PolicyException` objects (a supported way to carve out narrow, auditable exceptions to a policy for a specific resource) are disabled cluster-wide.

- **mitigation**: intentional for now — keeps every policy strictly enforced with no exception mechanism to misuse. If a legitimate need for scoped exceptions comes up, enable this feature and set `features.policyExceptions.namespace` to restrict which namespace(s) may define them, rather than leaving it open cluster-wide.
