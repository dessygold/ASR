# kyverno

## Overview

**Kyverno** is a Kubernetes-native policy engine that validates, mutates, generates, and cleans up resources using policies written as standard Kubernetes YAML custom resources (and, in newer chart versions, CEL-based policy CRDs). It integrates via Kubernetes admission webhooks for real-time enforcement and via a background controller for periodic re-scanning of existing cluster resources. It also produces compliance results as `PolicyReport`/`ClusterPolicyReport` custom resources, and can optionally emit those through the vendor-neutral OpenReports CRDs.

---

## Source Code

The upstream source code is maintained by the Kyverno project (a CNCF incubating project).

- Repository: https://github.com/kyverno/kyverno
- Organization: kyverno (CNCF)

---

## Helm Chart

The official Helm chart is published via GitHub Pages as a traditional (non-OCI) Helm repository.

- Helm Chart:
  - `https://kyverno.github.io/kyverno/` (repo name: `kyverno`, chart: `kyverno/kyverno`)
- Documentation:
  - https://kyverno.io/docs/installation/methods/
  - https://github.com/kyverno/kyverno/tree/main/charts/kyverno

---

## Infrastructure Requirements

Kyverno requires:

- Kubernetes cluster
- Helm 3
- Kubernetes RBAC
- CustomResourceDefinition (CRD) support
- Admission webhooks (validating and mutating)
- ConfigMaps
- Container registry access to pull the controller images

It does **not** require cert-manager for runtime operation — by default it manages its own self-signed webhook certificate and rotation, though cert-manager integration is available (`admissionController.certManager.enabled`) and not currently used in this deployment.

---

## Infrastructure Configuration

Infrastructure is configured through:

- Kubernetes manifests
- Helm values ([helm-values/values.yaml](../helm-values/values.yaml) and the per-environment files)
- Kyverno Custom Resources (`ClusterPolicy`, `Policy`, `CleanupPolicy`, `ClusterCleanupPolicy`, `PolicyException`, and the newer `policies.kyverno.io` CRDs)
- Kubernetes RBAC resources
- Admission Webhook configuration
- Namespace configuration

Infrastructure outside Kubernetes (cloud resources, networking, DNS, etc.) is **not** managed by Kyverno — see [DEPLOYMENT.md](./DEPLOYMENT.md) (no Terraform module).

---

## Infrastructure Deployment

Infrastructure is deployed using:

- Helm
- Kubernetes API
- CRDs installed with the Helm chart (`crds.install: true`)

Typical deployment:

```bash
helm repo add kyverno https://kyverno.github.io/kyverno/
helm repo update
helm upgrade kyverno kyverno/kyverno \
  --install \
  --namespace kyverno \
  --create-namespace \
  -f helm-values/values.yaml
```

The Helm installation creates:

- Deployments (admission-controller, background-controller, cleanup-controller, reports-controller)
- Services (webhook + metrics)
- ValidatingWebhookConfiguration / MutatingWebhookConfiguration
- RBAC (ClusterRoles/ClusterRoleBindings, aggregated to Kubernetes' `admin`/`view` user-facing roles)
- ServiceAccounts per controller
- CRDs (`kyverno.io`, `policies.kyverno.io`, `reports.kyverno.io`, `wgpolicyk8s.io` groups)
- Post-upgrade CRD-migration Job and pre-delete webhook-cleanup Job (Helm hooks)

---

## Application Deployment

The application is deployed via Helm through the DSOP `dsop/pipelines` external-application pipeline (see [.gitlab-ci.yml](../.gitlab-ci.yml)).

Typical deployment steps:

1. Install the Kyverno Helm chart (CRDs included).
2. Author `ClusterPolicy`/`Policy` (or `CleanupPolicy`) resources declaratively in Git and apply via GitOps.
3. Consume `PolicyReport`/`ClusterPolicyReport` (or OpenReports) objects for compliance visibility.

---

## Configuration

Configuration is primarily performed through:

- Helm values (`config.*`, `metricsConfig.*`, `features.*`)
- `ClusterPolicy`/`Policy` custom resources
- `PolicyException` custom resources (currently disabled, see [SECURITY.md](./SECURITY.md))
- RBAC configuration

Common configuration areas:

- `config.resourceFilters` — resource kinds/namespaces excluded from all policy evaluation
- `config.webhooks` / `webhookAnnotations` / `matchConditions` — scope and behavior of the admission webhooks
- `features.backgroundScan` — periodic re-evaluation of existing resources
- `features.reporting` / `features.policyReports` / `openreports.enabled` — which report types are produced

---

## Additional Setup Beyond Helm Values

Yes.

After installation, administrators typically need to:

- Author and apply `ClusterPolicy`/`Policy` resources (the chart ships none by default)
- Review `config.excludeGroups`/`excludeUsernames`/`excludeRoles`/`excludeClusterRoles` against privileged service accounts in the target cluster
- Configure Grafana/VictoriaMetrics scraping if dashboards/alerting are desired (already wired for this deployment — see [support-manifests/](../support-manifests/))
- Decide on `failurePolicy` per policy (Fail vs Ignore) based on how critical enforcement is versus availability risk

---

## Authentication

Kyverno itself does **not** implement end-user authentication.

It relies entirely on Kubernetes authentication and authorization.

Integration includes:

- Kubernetes Service Accounts (one per controller)
- Kubernetes RBAC (aggregated ClusterRoles)
- Kubernetes Admission Webhooks

No OAuth, OIDC, LDAP, SAML, or external identity provider integration is built into Kyverno itself. Policies can, however, reference external systems via `context.apiCall` (with a scoped, audience-bound projected token — `apiCallToken.audience`) if a policy author chooses to call out to an external service.

---

## Supporting Projects

Common supporting projects include:

- Kubernetes
- Helm
- OpenReports (optional companion CRDs for vendor-neutral reporting)
- reports-server (optional, `reportsServer.enabled`)
- Grafana (optional — enabled in this deployment)
- VictoriaMetrics / Prometheus (metrics scraping — VictoriaMetrics used in this deployment)
- Sigstore/cosign + TUF (optional, for image verification policies — not currently enabled)

Supporting Kubernetes resources include:

- ConfigMaps
- ServiceAccounts
- ClusterRoles / ClusterRoleBindings
- CRDs

---

## CI/CD Pipelines

The upstream project is maintained using GitHub and GitHub Actions.

This DSOP deployment installs Kyverno through:

- GitLab CI/CD (`dsop/pipelines` external-application pipeline, pulling from the upstream Helm repo)
- GitOps (`DSOP/Gitops/<system>` projects)

The project itself does not require any specific CI/CD platform to consume its chart.

---

## Upgrades

Upgrades are managed using Helm — see [DEPLOYMENT.md](./DEPLOYMENT.md) for the full DSOP upgrade process.

Typical process:

```bash
helm repo update
helm upgrade kyverno kyverno/kyverno \
  --namespace kyverno \
  -f helm-values/values.yaml
```

Upgrade considerations:

- Review upstream [release notes](https://github.com/kyverno/kyverno/releases) for breaking policy/CRD changes
- The chart's post-upgrade hook migrates CRDs automatically (`crds.migration.enabled: true`) — confirm the migration Job completes successfully
- `upgrade.fromV2` must be explicitly set to `true` after review before a v2→v3 major upgrade is allowed
- Verify `ClusterPolicy`/`Policy` resources still evaluate as expected post-upgrade (`kubectl get policyreports,clusterpolicyreports -A`)

---

## Licensing

Kyverno is licensed under the Apache License 2.0.

This is a permissive open-source license suitable for commercial and enterprise use.

---

## License Management

No license server or license key is required.

Management consists of:

- Tracking upstream releases
- Maintaining license compliance
- Preserving Apache 2.0 license notices where applicable

---

## Required Skills

Maintaining Kyverno typically requires knowledge of:

- Kubernetes
- Helm
- Kubernetes RBAC
- Kubernetes CRDs and Admission Webhooks
- YAML (and, increasingly, CEL for the newer `policies.kyverno.io` policy CRDs)
- Git / GitOps

Helpful but optional skills:

- Prometheus/VictoriaMetrics query language (PromQL/MetricsQL) for the dashboards and alerting rules
- Grafana
- Sigstore/cosign, TUF (only if image-verification policies are adopted)
- Terraform — not required for this application, but useful DSOP-wide context

---

## Projects Used to Maintain the Application

| Project | Purpose |
|----------|---------|
| kyverno | Policy engine (admission, background, cleanup, reports controllers) |
| OpenReports | Vendor-neutral policy/scan reporting CRDs |
| Kubernetes | Runtime platform |
| Helm | Application packaging and deployment |
| Git | Source control / GitOps source of truth for policies |
| GitLab CI/CD | Build and deployment automation (`dsop/pipelines`) |
| Argo CD / GitOps | Cluster deployment |
| VictoriaMetrics | Metrics collection |
| Grafana | Monitoring dashboards |

---

## Summary

Kyverno is a Kubernetes-native policy engine deployed via Helm into every cluster that needs admission-time and background policy enforcement. It has no cloud infrastructure dependency and no persistent state of its own — its source of truth is the set of `ClusterPolicy`/`Policy` resources managed declaratively via GitOps. It is maintained using standard Kubernetes/Helm operational practices, with OpenReports, Grafana, and VictoriaMetrics wired in for visibility. No commercial licensing or proprietary infrastructure is required.
