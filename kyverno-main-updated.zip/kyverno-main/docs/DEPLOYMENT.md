# Deployment

This document describes the deployment process for `Kyverno`.

## Overview

[`Kyverno`](https://kyverno.io/docs/introduction/) is a Kubernetes-native policy engine. Policies are plain Kubernetes resources (`ClusterPolicy`, `Policy`, and the newer `policies.kyverno.io` CRDs such as `ValidatingPolicy`/`ImageValidatingPolicy`/`MutatingPolicy`/`GeneratingPolicy`) written in YAML or CEL — no new language to learn, no sidecar to inject. Kyverno validates, mutates, generates, and cleans up resources by intercepting the Kubernetes API via admission webhooks and by periodically re-scanning the cluster in the background.

The chart installs four components, each with its own Deployment/CronJob:

- **admission-controller** — the core component. Runs the validating/mutating admission webhooks that inspect requests synchronously as they hit the API server.
- **background-controller** — re-evaluates existing (already-admitted) resources against policies on an interval, and handles `generate`/`mutate-existing` policy rules that act outside the request path.
- **cleanup-controller** — executes `CleanupPolicy`/`ClusterCleanupPolicy` resources on a schedule (similar shape to a CronJob).
- **reports-controller** — rolls up per-resource `EphemeralReport`/`ClusterEphemeralReport` objects into `PolicyReport`/`ClusterPolicyReport` (and OpenReports) so compliance status is queryable cluster-wide.

See [diagram.md](../diagram.md) for the request/report flow.

- [Kyverno installation guide](https://kyverno.io/docs/installation/methods/)
- [Kyverno policy types](https://kyverno.io/docs/policy-types/)
- [Kyverno CRDs](https://github.com/kyverno/kyverno/tree/main/config/crds)

## How we deploy it to DSOP

Kyverno is deployed via the standard `dsop/pipelines` external-application pipeline (see [.gitlab-ci.yml](../.gitlab-ci.yml)), which pulls the chart from the upstream Helm repo (`https://kyverno.github.io/kyverno/`, set via `SOURCE_HELM_REPO`) rather than an OCI registry.

- Container images are re-pointed at our GovCloud ECR mirror (`186542266927.dkr.ecr.us-gov-west-1.amazonaws.com/containers/kyverno/*`) in [helm-values/values.yaml](../helm-values/values.yaml), pinned to `v1.18.1` at time of writing. All 7 images used by the chart (admission-controller + its init container, background-controller, cleanup-controller, reports-controller, the CRD-migration job's `kyverno-cli` image, and the `readiness-checker` image used for Helm test/pre-delete hooks) are re-pointed here and registered individually in [cdso_config.yml](../cdso_config.yml).
- **OpenReports** is enabled (`openreports.enabled: true`, `openreports.installCrds: true`) so policy results surface through the vendor-neutral OpenReports CRDs in addition to Kyverno's native `PolicyReport`.
- **Reports Server** CRD group support is enabled (`crds.reportsServer.enabled: true`).
- **Grafana** dashboard creation is enabled (`grafana.enabled: true`, namespace `monitoring`) — see [support-manifests/grafana-dashboard.yaml](../support-manifests/grafana-dashboard.yaml) and [support-manifests/configmap.yaml](../support-manifests/configmap.yaml) (GrafanaFolder).
- Metrics are scraped via VictoriaMetrics — see [support-manifests/victoria-VMServiceScrape.yaml](../support-manifests/victoria-VMServiceScrape.yaml).
- No `ExternalSecret` is required for this application (see [support-manifests/external-secret.yaml](../support-manifests/external-secret.yaml) — left intentionally empty).
- Admission webhook TLS is left on Kyverno's own self-signed cert rotation (`admissionController.certManager.enabled: false`, `createSelfSignedCert: false` — the chart-managed default). cert-manager integration is available but not turned on for this deployment; see [SECURITY.md](./SECURITY.md).

## Environments

- Deployed to every cluster where Kubernetes policy enforcement is required, configured through the `DSOP/Gitops/<system>` projects (same GitOps model as other DSOP applications).
- Requires no Terraform module and no cloud infrastructure of its own — it only needs an existing Kubernetes cluster with CRD and admission-webhook support.
- The environment-specific value files ([helm-values/values-dev.yaml](../helm-values/values-dev.yaml), [values-test.yaml](../helm-values/values-test.yaml), [values-prod.yaml](../helm-values/values-prod.yaml)) currently carry no overrides beyond what's applied in the ArgoCD/GitOps Application manifest per cluster — [helm-values/values.yaml](../helm-values/values.yaml) is the shared baseline across all environments.
- `resyncPeriod: 15m` and `backgroundScanInterval: 1h` (chart defaults, not currently overridden) govern how quickly drift is caught outside the live admission path.

## Risks (integrations with other systems)

- **Admission webhook is in the request path.** Because `admissionController` runs a `ValidatingWebhookConfiguration`/`MutatingWebhookConfiguration` against (by default) most resource kinds, a Kyverno outage or a bad policy can block or mutate unrelated workloads cluster-wide. `config.resourceFilters` and `config.webhooks.namespaceSelector` narrow this, and `kube-system` is excluded by default (`excludeKyvernoNamespace: true`).
- **Background scan lag.** Anything caught only by the background-controller (rather than at admission time) can sit out of compliance for up to `backgroundScanInterval` (default `1h`) before it's reflected in policy reports.
- **CRD migration hook.** Helm upgrades run a post-upgrade migration job (`crds.migration.enabled: true`, using the `kyverno-cli` image) against a long list of CRDs — see `default-helm-values.yaml` `crds.migration.resources`. A failed migration job can leave CRDs at a mismatched version relative to the controllers.

## Upgrade Process

1. Run the CI pipeline to identify new chart/container versions available upstream.
2. Update `helm-values/values.yaml` (and `cdso_config.yml` if the set of images changes) with the new image tags, and update `DSOP/Gitops/<system>` with the new chart version.
3. Verify rollout in `dev` before promoting to `test`/`prod` — confirm the admission webhook comes back healthy (`kubectl get pods -n kyverno`, `startupProbe`/`livenessProbe` on `/health/liveness`) and spot-check that existing `ClusterPolicy`/`Policy` resources still evaluate as expected (`kubectl get policyreports,clusterpolicyreports -A`) before promoting further.
4. Review the [Kyverno release notes](https://github.com/kyverno/kyverno/releases) for breaking policy/CRD changes — Kyverno has, in past majors, changed policy API groups (e.g. the newer `policies.kyverno.io` CRDs alongside the legacy `kyverno.io` ones); `upgrade.fromV2` guards against an unreviewed v2→v3 jump.
