# cDSO Pipeline Status

## Container `kyverno:v1.18.1`

pipeline run: _TODO — link the latest `code.cdso.army.mil/cdso/cdso` pipeline run for this container once the next scan completes_

_TODO — record the outcome (clean / findings + remediation notes) here, following the pattern used in the `trust-manager` project's `docs/CDSO_STATUS.md` (a separate DSOP repo)._

## Container `kyverno-cli:v1.18.1`

pipeline run: _TODO_

## Container `background-controller:v1.18.1`

pipeline run: _TODO_

## Container `cleanup-controller:v1.18.1`

pipeline run: _TODO_

## Container `reports-controller:v1.18.1`

pipeline run: _TODO_

## Container `kyvernopre:v1.18.1`

pipeline run: _TODO_

## Container `readiness-checker:v1.18.1`

pipeline run: _TODO_

---

**Note for whoever picks up the next scan**: this file intentionally does not fabricate pipeline run links or results — all 7 containers registered in [cdso_config.yml](../cdso_config.yml) need a pipeline run recorded here. Update each entry with the actual `code.cdso.army.mil/cdso/cdso/-/pipelines/<id>` link and a one-line finding once the scan has run, same as trust-manager's status doc.
