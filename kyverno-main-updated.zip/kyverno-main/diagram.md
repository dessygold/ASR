# Diagram

```mermaid
flowchart TD
    subgraph apiserver["Kubernetes API Server"]
        req["API request<br/>(create/update/delete)"]
    end

    subgraph kyvernons["kyverno namespace"]
        admctrl["admission-controller<br/>(kyverno container)"]
        bgctrl["background-controller"]
        cleanctrl["cleanup-controller"]
        repctrl["reports-controller"]
        cm["ConfigMap<br/>kyverno (config)"]
    end

    subgraph policies["Policy resources (cluster-wide, GitOps managed)"]
        cpol["ClusterPolicy / Policy"]
        ccup["ClusterCleanupPolicy / CleanupPolicy"]
        pexc["PolicyException"]
    end

    subgraph reports["Reporting"]
        polr["PolicyReport /<br/>ClusterPolicyReport"]
        ephr["EphemeralReport /<br/>ClusterEphemeralReport"]
        openr["OpenReports CRDs"]
    end

    subgraph observability["Observability"]
        grafana["Grafana dashboard<br/>(support-manifests/grafana-dashboard.yaml)"]
        vmss["VMServiceScrape<br/>(support-manifests/victoria-VMServiceScrape.yaml)"]
    end

    req -- "ValidatingWebhookConfiguration /<br/>MutatingWebhookConfiguration" --> admctrl
    admctrl -- "allow / deny / mutate" --> req
    cpol -.->|watched| admctrl
    pexc -.->|watched| admctrl
    cm -.->|resourceFilters, excludeGroups, webhooks config| admctrl

    bgctrl -- "periodic background scan\n(existing cluster resources)" --> cpol
    bgctrl --> ephr
    cleanctrl -- "scheduled cleanup" --> ccup

    admctrl --> ephr
    ephr --> repctrl
    repctrl --> polr
    repctrl --> openr

    admctrl --> vmss
    bgctrl --> vmss
    cleanctrl --> vmss
    repctrl --> vmss
    vmss --> grafana
```

**Legend**
- The **admission-controller** intercepts every matching API request via its validating/mutating webhook and evaluates `ClusterPolicy`/`Policy` rules synchronously, in the request path.
- The **background-controller** periodically re-scans existing cluster resources against the same policy set (`backgroundScan.enabled`) to catch drift and to fulfill `generate`/`mutate-existing` rules.
- The **cleanup-controller** runs `CleanupPolicy`/`ClusterCleanupPolicy` resources on their configured schedule to delete matching resources.
- The **reports-controller** aggregates per-resource `EphemeralReport`/`ClusterEphemeralReport` results into cluster-visible `PolicyReport`/`ClusterPolicyReport` (and OpenReports) objects.
- Policies themselves are plain Kubernetes custom resources — they are expected to be managed declaratively (GitOps), not created ad hoc against the cluster.
