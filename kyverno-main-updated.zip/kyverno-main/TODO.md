# TODO

Carried over (original, unresolved):
- image updater? — is Argo CD Image Updater (or similar) wanted for auto-bumping the pinned `v1.18.1` tags in `helm-values/values.yaml`, or is that intentionally manual via the CI pipeline?
- applicationsets? — should this move to an ArgoCD `ApplicationSet` (trust-manager's DEPLOYMENT.md notes this as a planned future pattern for that app too)?

Found while updating documentation (2026-09-17):
- [`victoria-VMServiceScrape.yaml`](./support-manifests/victoria-VMServiceScrape.yaml) selector/port name needs verification against a rendered chart (`helm template`) or a live cluster — see the note at the bottom of that file.
- [`docs/CDSO_STATUS.md`](./docs/CDSO_STATUS.md) needs real pipeline run links/results for all 7 registered containers — none exist yet.
- Confirm whether `admissionController.certManager.enabled` should be turned on for consistency with cert-manager already running in-cluster (see [docs/SECURITY.md](./docs/SECURITY.md)).
- Confirm whether `podDisruptionBudget.enabled` / `replicas > 1` should be turned on for the admission-controller for HA, given it sits in the live admission path (see [docs/SECURITY.md](./docs/SECURITY.md)).
- Review `config.excludeGroups`/`excludeUsernames`/`excludeRoles`/`excludeClusterRoles` against DSOP's actual privileged/CI service accounts to make sure policy evaluation isn't silently bypassed for the wrong accounts.
- `helm-values/values-dev.yaml`/`values-test.yaml`/`values-prod.yaml` were empty prior to this update; filled with the same "N/A, applied in Application manifest" placeholder used by trust-manager — confirm no per-environment overrides actually exist (or are needed) before treating this as final.
