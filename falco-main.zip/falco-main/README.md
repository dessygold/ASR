# Falco

Falco is a cloud native security tool that provides runtime security across hosts, containers, Kubernetes, and cloud environments. It is designed to detect and alert on abnormal behavior and potential security threats in real-time.

<<<<<<< HEAD
**Systems**: All systems
=======
Systems this application deploys to: **ALL systems**
>>>>>>> 8a9d46b (update from demo)

Badges:
- cdso pipeline status
- latest helm chart version
- latest application version
- application (internal/external)


## References
- [source code repository](https://github.com/falcosecurity/falco)
<<<<<<< HEAD
- [official documentation](https://falco.org/docs/)
- [relevant article or guide]()

- [**DSOP**: applications terraform module (if applicable)]()
=======
  - [helm chart values](https://github.com/falcosecurity/falco/blob/master/chart/falco/values.yaml)
- [official documentation](https://falco.org/docs/)
>>>>>>> 8a9d46b (update from demo)

### Documentation

- [DEPLOYMENT.md](./docs/DEPLOYMENT.md)
- [BACKUP-RESTORE.md](./docs/BACKUP-RESTORE.md)
- [SECURITY.md](./docs/SECURITY.md)
- [TROUBLESHOOTING.md](./docs/TROUBLESHOOTING.md)
- [CDSO_STATUS.md](./docs/CDSO_STATUS.md)

## Reference Commands

```bash

helm repo add some-repo https://some-repo.github.io/org/
helm repo update

...
```
