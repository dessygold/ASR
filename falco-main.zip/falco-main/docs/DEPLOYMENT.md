# Deployment

This document describes the deployment process for `falco`.

## Overview

## How we deploy it to DSOP

## Environments

- Deployed to every cluster where Kubernetes policy enforcement is required, configured through the `DSOP/Deployment/Gitops/Shared ApplicationSets` projects
- Requires no Terraform module and no cloud infrastructure of its own — it only needs an existing Kubernetes cluster with CRD.
- The environment-specific value files ([helm-values/values-dev.yaml](../helm-values/values-dev.yaml), [values-test.yaml](../helm-values/values-test.yaml), [values-prod.yaml](../helm-values/values-prod.yaml)) currently carry no overrides beyond what's applied in the ArgoCD/GitOps Application manifest per cluster — [helm-values/values.yaml](../helm-values/values.yaml) is the shared baseline across all environments.

## Upgrade Process

1. Run the CI pipeline to identify new chart/container versions available upstream.
2. overwrite old default-helm-values.yaml file with new helm chart default values; check to make sure there no code breaking changes or newly required parameters, and check/update any deprecated parameters in use.
2. Update the container image `tag` key value pair with the new available version in `helm-values/values.yaml`.
3. navigate to `DSOP/Deployment/Gitops/Shared ApplicationSets/values-<env>.yaml` and update falco.targetRevision key with the new chart version.
4. Verify rollout in `dev` before promoting to `test`/`prod`

*Note: there is minimal downtime for redeploying falco application after an upgrade*
