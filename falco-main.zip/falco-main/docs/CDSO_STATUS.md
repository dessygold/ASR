# cDSO Pipeline Status

## Container `falcoctl`

### syft_grype https://code.cdso.army.mil/cdso/cdso/-/jobs/24416111
[-] 5 unmitigated vulnerabilities

 »  CVE-2026-34040 (High)
    Description: Moby has AuthZ plugin bypass when provided oversized request bodies in
    github.com/docker/docker
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/bin/falcoctl

 »  CVE-2026-33997 (Medium)
    Description: Moby has an Off-by-one error in its plugin privilege validation
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <29.3.1 (go)
    - Locations: /usr/bin/falcoctl

 »  CVE-2026-41567 (High)
    Description: Docker: `PUT /containers/{id}/archive` executes container binary on the host
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <=28.5.2 (go)
    - Locations: /usr/bin/falcoctl

 »  CVE-2026-42306 (High)
    Description: Docker: Race condition in docker cp allows bind mount redirection to host path
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <=28.5.2 (go)
    - Locations: /usr/bin/falcoctl

 »  CVE-2026-41568 (Medium)
    Description: Docker: Race condition in docker cp allows creation of arbitrary empty files on the host
    via symlink swap
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <=28.5.2 (go)
    - Locations: /usr/bin/falcoctl

## Container `falco`

### syft_grype https://code.cdso.army.mil/cdso/cdso/-/jobs/24416093
[-] 10 unmitigated vulnerabilities

 »  CVE-2026-34040 (High)
    Description: Moby has AuthZ plugin bypass when provided oversized request bodies in
    github.com/docker/docker
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-19499 (High)
    Description: Calling strfmon and strfmon_l in the GNU C Library version 2.38 to 2.44 can write past
    the end of the caller-supplied output buffer when a conversion uses right-justified width padding.  Exploitation
    requires an application code path that calls strfmon or strfmon_l with right-justified width padding into a
    destination buffer that is large enough for the padding to succeed but too small for the internal memmove call. The
    field width or format may be attacker-influenced or a fixed susceptible pattern in the caller.  At the time of
    publication, no network-facing application impact is known.
    Artifact: glibc-2.44
    - Current version: 2.44-r6
    - Vulnerable version(s): >= 2.38, <= 2.44 (unknown)
    - Locations: /usr/lib/apk/db/installed

 »  CVE-2026-56855 (High)
    Description: Previously, after a channel has been established, a malicious peer could send crafted
    messages that would deadlock the entire connection.  Now, we handle all RFC 4254 channel messages; global requests
    are handled explicitly. Then, treat all other messages as a protocol error and tear the connection down instead of
    buffering and blocking.
    Artifact: golang.org/x/crypto
    - Current version: v0.55.0
    - Vulnerable version(s): <0.56.0 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-78662 (High)
    Description: Previously, a channel registered in the mux's chanList is not usable until it is
    established. A malicious peer was able flood the channel's incomingRequests, deadlocking the entire connection.
    Now, we add an atomic established state, set when a channel becomes usable. Until such a time, handlePacket drops
    every packet other than the open confirmation/failure, without blocking and without tearing down the
    connection.
    Artifact: golang.org/x/crypto
    - Current version: v0.55.0
    - Vulnerable version(s): <0.56.0 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-33997 (Medium)
    Description: Moby has an Off-by-one error in its plugin privilege validation
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <29.3.1 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-19542 (Medium)
    Description: Calling tdelete on a sufficiently deep tree in the GNU C Library version 2.1 to 2.44 may
    write one pointer past the end of an alloca-allocated array on the stack, which may crash the application.  The
    tdelete implementation keeps an explicit stack of parent nodes for rebalancing, which is grown as needed while
    descending the tree.  Two rebalancing branches push an additional entry without checking the capacity, and write
    past the array when the stack is exactly full. Triggering this requires a node at a depth of exactly 40 (or 40 plus
    a multiple of 20), which implies a tree with at least a million nodes, so an attacker must drive a large number of
    insertions and deletions through an application that uses tsearch and tdelete.  The written value is a pointer into
    a tree node and is not directly attacker controlled.  No affected application in common distributions has been
    identified.
    Artifact: glibc-2.44
    - Current version: 2.44-r6
    - Vulnerable version(s): >= 2.1, <= 2.44 (unknown)
    - Locations: /usr/lib/apk/db/installed

 »  CVE-2026-41567 (High)
    Description: Docker: `PUT /containers/{id}/archive` executes container binary on the host
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <=28.5.2 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-89092 (Medium)
    Description: The nscd service in the GNU C Library 2.3.4 onwards may crash due to a  stack overflow
    when a malicious DNS server returns too large a response  for a DNS query, resulting in degraded DNS resolution for
    the system.    Exploitation of this bug needs a system that has nscd enabled and using  an untrusted DNS server for
    name resolution, with the compromised DNS  server being capable of processing records large enough to result in a
    stack overflow in an nscd thread stack.  During experimentation, bind 9  was unable to handle large records, but
    that could change in future or  with a different name server.  In typical installations, nscd is  executed in an
    isolated context as its own user without a shell, due to  which any compromise of that service is isolated.    There
    is a remote possibility of nscd cache corruption if an attacker  manages to get the stack pointer into a desired
    point in the heap,  potentially resulting in other caches in nscd being overwritten with  corrupt data through the
    stack overflow, until the buggy code path  eventually results in a crash.    Finally, a crash in nscd may result in
    performance degradation when  resolving names, but it does not result in a denial of service.
    Artifact: glibc-2.44
    - Current version: 2.44-r6
    - Vulnerable version(s): >= 2.3.4, < 2.45 (unknown)
    - Locations: /usr/lib/apk/db/installed

 »  CVE-2026-42306 (High)
    Description: Docker: Race condition in docker cp allows bind mount redirection to host path
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <=28.5.2 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-41568 (Medium)
    Description: Docker: Race condition in docker cp allows creation of arbitrary empty files on the host
    via symlink swap
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <=28.5.2 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so

### layer_scan https://code.cdso.army.mil/cdso/cdso/-/jobs/24416090
 STATUS SUMMARY
 [FAIL]   1 Critical Issues

 [WARN]   4 Warnings

 [SUPPRESSED] 0 Suppressed Findings

 CRITICAL FINDINGS:
  - No root user justification provided for root-running image.

## Container `falco-driver-loader`

### syft_grype https://code.cdso.army.mil/cdso/cdso/-/jobs/24416102
[-] 112 unmitigated vulnerabilities
 »  CVE-2026-34040 (High)
    Description: Moby has AuthZ plugin bypass when provided oversized request bodies in
    github.com/docker/docker
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/falco/plugins/libcontainer.so, /usr/bin/falcoctl

 »  CVE-2023-2953 (High)
    Description: A vulnerability was found in openldap. This security flaw causes a null pointer
    dereference in ber_memalloc_x() function.
    Artifact: libldap-2.5-0
    - Current version: 2.5.13+dfsg-5
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libldap-2.5-0/copyright, /var/lib/dpkg/info/libldap-2.5-0:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libldap-common
    - Current version: 2.5.13+dfsg-5
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libldap-common/copyright, /var/lib/dpkg/info/libldap-common.conffiles,
    /var/lib/dpkg/info/libldap-common.list, /var/lib/dpkg/info/libldap-common.md5sums, /var/lib/dpkg/status

 »  CVE-2026-19931 (Critical)
    Description: A flaw in libcurl makes it wrongly reuse an HTTP connection setup for a given hostname
    using Negotiate authentication, when the initial request is done using empty credentials. This can make user B's
    request get sent over user A's previously authenticated connection.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-63076 (High)
    Description: Issue summary: OpenSSL CMP password based protection verification only checks whether the
    protectionAlg parameter was not NULL and not its ASN.1 type, before treating it as a PBMParameter. A crafted message
    can contain a parameter of a different type, which is then dereferenced as an invalid pointer.  Impact summary: A
    remote, unauthenticated attacker can crash an application acting as a CMP server that accepts PBM-protected
    messages, or a CMP client talking to a malicious or intercepted CMP server, resulting in a Denial of Service.  CWE:
    CWE-476: NULL Pointer Dereference  Description: When verifying the password-based MAC protection of a CMP message,
    OpenSSL library reads the protectionAlg algorithm parameter with X509_ALGOR_get0(), which returns both the parameter
    type and its value pointer. The value is then cast to an ASN1_STRING and treated as the expected PBMParameter after
    only checking that pointer is not NULL. The parameter type returned by X509_ALGOR_get0() was never consulted.  This
    happens during protection verification, before any MAC is computed, so no knowledge of the PBM shared secret is
    required; the only precondition is that PBM verification is reachable. On the server side this is reached from
    OSSL_CMP_SRV_process_request() for any application that stands up a CMP server accepting PBM-protected messages, and
    on the client side from CMP response validation against a malicious or on-path (MITM) server. The reliable
    consequence is a denial of service; there is no memory disclosure, no controlled memory write, and no path to code
    execution. CMP is a specialized feature that an application must explicitly enable.  FIPS impact: no As the CMP code
    lives outside the FIPS module boundary, no FIPS modules are affected by this CVE.
    Artifact: libssl-dev
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl-dev/copyright, /var/lib/dpkg/info/libssl-dev:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libssl3
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl3/copyright, /var/lib/dpkg/info/libssl3:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: openssl
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/openssl/copyright, /var/lib/dpkg/info/openssl.conffiles,
    /var/lib/dpkg/info/openssl.list, /var/lib/dpkg/info/openssl.md5sums, /var/lib/dpkg/info/openssl.postinst,
    /var/lib/dpkg/status

 »  CVE-2025-13151 (High)
    Description: Stack-based buffer overflow in libtasn1 version: v4.20.0. The function fails to validate
    the size of input data resulting in a buffer overflow in asn1_expend_octet_string.
    Artifact: libtasn1-6
    - Current version: 4.19.0-2+deb12u1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libtasn1-6/copyright, /var/lib/dpkg/info/libtasn1-6:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-18924 (Critical)
    Description: A flaw in libcurl's handling of HTTP/2 Server Push streams, when the parent handle is set
    to share connections with other handles, can lead to use-after-free in the cleanup process.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-11856 (Critical)
    Description: Successfully using libcurl to do a transfer to a specific HTTP origin (`hostA`) with
    **Digest** authentication and then changing the origin to a different one (`hostB`) for a second transfer, reusing
    the same handle, makes libcurl wrongly pass on the `Authorization:` header field meant for `hostA`, to
    `hostB`.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-8924 (Critical)
    Description: A flaw in curl’s cookie parsing logic allows a malicious HTTP server to set "super
    cookies" that bypass the Public Suffix List check. This enables an attacker-controlled origin to inject cookies that
    curl subsequently scopes and transmits to unrelated third-party domains.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-10536 (Critical)
    Description: A use-after-free vulnerability exists in libcurl when an application configures an HTTP/2
    stream-dependency tree via `CURLOPT_STREAM_DEPENDS` or `CURLOPT_STREAM_DEPENDS_E`, subsequently invokes
    `curl_easy_reset()`, and finally terminates the handle with `curl_easy_cleanup()`. During this final cleanup phase,
    libcurl attempts to access and modify an internal structure that was already freed during the reset
    operation.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2023-50495 (Medium)
    Description: NCurse v6.4-20230418 was discovered to contain a segmentation fault via the component
    _nc_wrap_entry().
    Artifact: libncursesw6
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/dpkg/info/libncursesw6:amd64.md5sums, /usr/share/doc/libtinfo6/copyright,
    /var/lib/dpkg/status
    Artifact: libtinfo6
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libtinfo6/copyright, /var/lib/dpkg/info/libtinfo6:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: ncurses-base
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/ncurses-base/copyright, /var/lib/dpkg/info/ncurses-base.conffiles,
    /var/lib/dpkg/info/ncurses-base.list, /var/lib/dpkg/info/ncurses-base.md5sums, /var/lib/dpkg/status
    Artifact: ncurses-bin
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/ncurses-bin/copyright, /var/lib/dpkg/info/ncurses-bin.list,
    /var/lib/dpkg/info/ncurses-bin.md5sums, /var/lib/dpkg/status

 »  CVE-2026-63072 (High)
    Description: Issue summary: OpenSSL CMS decryption sizes the key-unwrap output buffer based on
    querying the unwrapped key size, but the AES-WRAP-PAD unwrap primitive can write and cleanse more bytes than that
    query reports, causing an 8-byte out-of-bounds heap write.  Impact summary: An attacker who supplies a crafted CMS
    message can trigger a deterministic 8-byte out-of-bounds heap write when the victim decrypts it with CMS_decrypt(),
    corrupting the heap and typically resulting in a Denial of Service.  CWE: CWE-787: Out-of-bounds Write  Description:
    The key-wrap OID is potentially attacker-controlled on the wire. CMS unwrapping allows both id-aesNNN-wrap-pad and
    id-aesNNN-wrap ciphers. An attacker can take a legitimate message and change a single OID byte to select the padded
    variant while leaving the message otherwise valid. Since the unwrap key is derived from the recipient's private
    operation (ECDH key agreement or ML-KEM decapsulation), the RFC 5649 integrity check cannot pass, and the decryption
    fails with integrity failure.  The write is a fixed-size (8-byte), fixed-value (zero) heap overflow immediately past
    the allocation, requires no special configuration, and is reachable from the public CMS_decrypt() function. The
    consequence is a heap corruption leading to a Denial of Service. The fix in the CMS code sizes the unwrap output
    buffer for the worst case so a failed unwrap cannot write past the allocation.  FIPS impact: no  As the CMS code
    lives outside the FIPS module boundary, no FIPS modules are affected by this CVE.
    Artifact: libssl-dev
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl-dev/copyright, /var/lib/dpkg/info/libssl-dev:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libssl3
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl3/copyright, /var/lib/dpkg/info/libssl3:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: openssl
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/openssl/copyright, /var/lib/dpkg/info/openssl.conffiles,
    /var/lib/dpkg/info/openssl.list, /var/lib/dpkg/info/openssl.md5sums, /var/lib/dpkg/info/openssl.postinst,
    /var/lib/dpkg/status

 »  CVE-2026-13608 (High)
    Description: A flaw in the libcurl SASL negotiation for LDAP authentication allows an incomplete
    handshake sequence to be misinterpreted as a successful cryptographic verification. An attacker executing a
    Man-in-the-Middle (MITM) attack can inject a premature or shortcut response that bypasses complete peer
    validation.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2023-5388 (Medium)
    Description: NSS was susceptible to a timing side-channel attack when performing RSA decryption. This
    attack could potentially allow an attacker to recover the private data. This vulnerability affects Firefox < 124,
    Firefox ESR < 115.9, and Thunderbird < 115.9.
    Artifact: libnss3
    - Current version: 2:3.87.1-1+deb12u4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libnss3/copyright, /var/lib/dpkg/info/libnss3:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-5450 (Critical)
    Description: Calling the scanf family of functions with a %mc (malloc'd character match) in the GNU C
    Library version 2.7 to version 2.43 with a format width specifier with an explicit width greater than 1024 could
    result in a one byte heap buffer overflow.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-8927 (Critical)
    Description: When reusing a libcurl handle for sequential transfers driven by environment-variable
    proxy configuration, libcurl fails to clear the proxy authentication state between requests. Specifically, if the
    initial transfer authenticates against `proxyA` using Digest auth, a subsequent transfer routed through `proxyB`
    erroneously leaks the `Proxy-Authorization:` header intended solely for `proxyA`.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-80230 (High)
    Description: When `CURLOPT_PINNEDPUBLICKEY` is configured alongside options that disable standard peer
    verification (`CURLOPT_SSL_VERIFYPEER = 0` and `CURLOPT_SSL_VERIFYHOST = 0`), libcurl fails to enforce public key
    pinning on connections established without a presented server certificate. Bypassing the pinning check under these
    disabled-verification conditions allows unauthenticated connections to succeed when they should be rejected.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-82209 (High)
    Description: When libpsl support is enabled, libcurl fails to enforce the Public Suffix List boundary
    check when processing a `Set-Cookie` header where the `Domain` attribute explicitly matches an origin host that is
    itself a public suffix (e.g., `Domain=co.uk` set by `co.uk`).  Instead of coercing it into a strict host-only
    cookie, libcurl saves the cookie with wildcard domain scope (`.co.uk`). Consequently, the cookie is inappropriately
    included in subsequent outbound requests or HTTP redirects to arbitrary sibling subdomains under the same public
    suffix (e.g., `attacker.co.uk`).
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-8376 (Critical)
    Description: Perl versions before 5.40.5-RC1, from 5.41.0 before 5.42.3-RC1, from 5.43.0 before
    5.43.11 have a heap buffer overflow when compiling regular expressions with a repeated fixed string on 32-bit
    builds.  Perl_study_chunk in regcomp_study.c checked the size of the joined substring buffer in characters rather
    than bytes. For a quantified fixed substring with a large minimum count, the byte length mincount * l could overflow
    SSize_t, producing an undersized SvGROW allocation; the subsequent copy writes past the end of the buffer.  A caller
    that compiles an attacker-controlled regular expression on a 32-bit perl build triggers a heap buffer overflow at
    compile time.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-54874 (High)
    Description: Issue summary: Receiving a DTLS record for a future epoch while a handshake is in
    progress causes OpenSSL to buffer far more memory than the record itself requires.  Impact summary: A peer can use a
    small amount of network traffic to make an OpenSSL DTLS endpoint retain a disproportionately large amount of memory,
    which may lead to a Denial of Service.  CWE: CWE-405: Asymmetric Resource Consumption (Amplification)  Description:
    While a DTLS handshake is in progress, a peer may legitimately have already moved on to the next epoch (for example,
    having sent its ChangeCipherSpec and Finished messages) before the local endpoint has processed the same transition,
    typically because of reordering on the underlying UDP transport. OpenSSL buffers such early records so that they can
    be processed once the local endpoint catches up.  Buffering a record currently retains the entire read buffer it
    arrived in, which is sized to hold the largest possible DTLS record (around 16 kilobytes), rather than just the
    bytes that make up the record itself. Up to 100 such records may be buffered per connection. As a result, a peer
    that sends a stream of small forged records claiming to belong to the next epoch can cause an OpenSSL DTLS endpoint
    to retain around 1.7 megabytes of memory, despite sending only a small fraction of that amount of data over the
    network.  An attacker therefore gains a memory amplification factor of around 1200, and can multiply the effect
    across as many associations as it is able to open, making this a remote memory exhaustion Denial of Service risk for
    DTLS servers. Since the memory retained per connection remains bounded, and any limit an application already places
    on the number of concurrent associations also bounds the total exposure, this issue has been assessed as Low
    severity.  FIPS impact: no  No FIPS modules are affected by this issue as the affected code is outside the OpenSSL
    FIPS module boundary.  OpenSSL 4.0, 3.6, 3.5, 3.4, 3.0, 1.1.1 and 1.0.2 are vulnerable to this issue.  OpenSSL 4.0
    users should upgrade to OpenSSL 4.0.2. OpenSSL 3.6 users should upgrade to OpenSSL 3.6.4. OpenSSL 3.5 users should
    upgrade to OpenSSL 3.5.8. OpenSSL 3.4 users should upgrade to OpenSSL 3.4.7. OpenSSL 3.0 users should upgrade to
    OpenSSL 3.0.22.  Premium support customers only: OpenSSL 1.1.1 users should upgrade to OpenSSL 1.1.1zi OpenSSL 1.0.2
    users should upgrade to OpenSSL 1.0.2zr  This issue was reported on 18 May 2026 by Amazon Web Services. The fix has
    been developed by Matt Caswell.  -- cut (non-publishing metadata for internal use) -- Reported by: Amazon Web
    Services Fixed by: Matt Caswell
    Artifact: libssl-dev
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl-dev/copyright, /var/lib/dpkg/info/libssl-dev:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libssl3
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl3/copyright, /var/lib/dpkg/info/libssl3:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: openssl
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/openssl/copyright, /var/lib/dpkg/info/openssl.conffiles,
    /var/lib/dpkg/info/openssl.list, /var/lib/dpkg/info/openssl.md5sums, /var/lib/dpkg/info/openssl.postinst,
    /var/lib/dpkg/status

 »  CVE-2026-6253 (Medium)
    Description: curl might erroneously pass on credentials for a first proxy to a second proxy.  This can
    happen when the following conditions are true:  1. curl is setup to use specific different proxies for different URL
    schemes 2. the first proxy needs credentials 3. the second proxy uses no credentials 4. while using the first proxy
    (using say `http://`), curl is asked to follow    a redirect to a URL using another scheme (say `https://`),
    accessed using a    second, different, proxy
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-13221 (Critical)
    Description: Perl versions before 5.40.5-RC1, from 5.41.0 before 5.42.3-RC1, from 5.43.0 before
    5.43.10 produce silently incorrect regular expression matches when an alternation of more than 65535 fixed string
    branches is compiled into a trie in Perl_study_chunk.  When such branches are combined into a trie, the delta
    between the first branch and the shared tail is stored in a 16-bit field. A branch count above 65535 overflows the
    field, and the trie's match decision table is truncated with no warning or error.  A pattern of this shape produces
    false positive matches (matching strings it should not) and false negative matches (failing to match strings it
    should). When such a pattern gates an access or filtering decision, the result is wrong.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-42496 (Critical)
    Description: Archive::Tar versions before 3.08 for Perl extract symlinks with attacker controlled
    targets outside the extraction directory.  _make_special_file() passes the tar header's linkname to symlink()
    without validating it against absolute paths or .. segments. The secure-extract mode check that guards regular file
    extraction does not cover the symlink target.  A subsequent open through the extracted name reads or writes the
    attacker chosen path.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status
    
 »  CVE-2026-85091 (High)
    Description: zlib versions 1.3.1.2 through 1.3.2 contain a heap buffer overflow vulnerability in the
    gz_vacate() function when processing non-blocking gzwrite() operations with stale external buffer pointers.
    Attackers can trigger the overflow by calling gzprintf() or gzvprintf() after a write stall, causing an unchecked
    memmove() to write beyond the internal input buffer boundary.
    Artifact: zlib1g
    - Current version: 1:1.2.13.dfsg-1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/zlib1g/copyright, /var/lib/dpkg/info/zlib1g:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2025-69720 (High)
    Description: The infocmp command-line tool in ncurses before 6.5-20251213 has a stack-based buffer
    overflow in analyze_string in progs/infocmp.c.
    Artifact: libncursesw6
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/dpkg/info/libncursesw6:amd64.md5sums, /usr/share/doc/libtinfo6/copyright,
    /var/lib/dpkg/status
    Artifact: libtinfo6
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libtinfo6/copyright, /var/lib/dpkg/info/libtinfo6:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: ncurses-base
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/ncurses-base/copyright, /var/lib/dpkg/info/ncurses-base.conffiles,
    /var/lib/dpkg/info/ncurses-base.list, /var/lib/dpkg/info/ncurses-base.md5sums, /var/lib/dpkg/status
    Artifact: ncurses-bin
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/ncurses-bin/copyright, /var/lib/dpkg/info/ncurses-bin.list,
    /var/lib/dpkg/info/ncurses-bin.md5sums, /var/lib/dpkg/status

 »  CVE-2026-12087 (Critical)
    Description: Socket versions before 2.041 for Perl have an out-of-bounds heap read.  In Socket.xs,
    pack_ip_mreq_source() checks the length of its source argument before the argument is read, so the check tests the
    byte length carried over from the preceding multiaddr argument instead. Both addresses occupy a 4-byte field, so a
    valid multiaddr lets a source of any length pass the check, and the source is then copied into the 4-byte
    imr_sourceaddr field with a fixed-size copy. A source shorter than 4 bytes is not rejected, and the copy reads up to
    3 bytes past the end of its buffer.  Calling pack_ip_mreq_source() with a source value shorter than 4 bytes copies
    adjacent heap memory into the returned packed structure.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-9538 (High)
    Description: Archive::Tar versions before 3.10 for Perl allow memory exhaustion via attacker
    controlled entry size field in tar header.  _read_tar() reads each entry's payload with $handle->read($$data,
    $block), where $block is derived from the entry's 12-byte size field in the tar header with no upper bound on that
    value.  A crafted header declaring a multi-gigabyte size causes Perl to allocate a scalar of that size.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-57433 (Critical)
    Description: Storable versions before 3.41 for Perl have a signed integer overflow when deserializing
    a crafted SX_HOOK record.  retrieve_hook_common reads a signed 32-bit item count from an SX_HOOK record and calls
    av_extend with that count plus one. A count of I32_MAX wraps the addition to a negative value.  A crafted blob
    passed to thaw or retrieve triggers the overflow; av_extend receives the negative count and dies with a panic,
    terminating the deserialization.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-6653 (Critical)
    Description: Use After Free in libxml2's xmlParseInternalSubset from GNOME libxml2 version 2.9.11 to
    2.11.0 allows a remote attacker to cause a denial-of-service via maliciously crafted XML input with improper entity
    resolution handling.
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2023-6135 (Medium)
    Description: Multiple NSS NIST curves were susceptible to a side-channel attack known as "Minerva".
    This attack could potentially allow an attacker to recover the private key. This vulnerability affects Firefox <
    121.
    Artifact: libnss3
    - Current version: 2:3.87.1-1+deb12u4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libnss3/copyright, /var/lib/dpkg/info/libnss3:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-42497 (High)
    Description: Archive::Tar versions before 3.08 for Perl extract hardlinks to attacker controlled paths
    outside the extraction directory.  _make_special_file() passes the tar header's linkname to link() without
    validating it against absolute paths or .. segments, creating a hardlink that shares the victim file's inode.  A
    subsequent write through the extracted name modifies the victim file, and the post-extraction chmod, chown, and
    utime block in _extract_file() (guarded only against symlinks via -l) applies the tar header's mode, owner, and
    timestamps to the shared inode during extraction alone.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-41992 (High)
    Description: GNU gzip contains a global buffer overflow vulnerability in the LZH decompression logic
    caused by improper reuse of shared global state between different decompression formats within a single execution.
    GNU gzip maintains a global array that is shared across the LZ77, LZW, and LZH decompression routines and is not
    reinitialized between files processed in the same invocation. By decompressing a specially crafted LZW file followed
    by a specially crafted LZH file in a single gzip -d command, an attacker can poison the shared global state and
    subsequently trigger an out‑of‑bounds read in the LZH decoder. The LZH decompression logic follows stale values left
    in the shared array, causing reads past the end of the allocated global buffer.  This issue has been fixed in
    commits 63dbf6b3b9e6e781df1a6a64e609b10e23969681 and e7378c2d421be6a286922374425680bbe9ad8b7d.
    Artifact: gzip
    - Current version: 1.12-1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gzip/copyright, /var/lib/dpkg/info/gzip.list,
    /var/lib/dpkg/info/gzip.md5sums, /var/lib/dpkg/status

 »  CVE-2026-42767 (Medium)
    Description: Issue summary: An attacker-controlled CMP (Certificate Management Protocol) server could
    trigger a NULL pointer dereference in a CMP client application.  Impact summary: A NULL pointer dereference causes a
    crash of the application and a Denial of Service.  An attacker controlling a CMP server (or acting as a
    man-in-the-middle) could craft a CMP response containing a CRMF (Certificate Request Message Format) CertRepMessage
    with an EncryptedValue structure where the symmAlg field has an algorithm OID but no parameters field. When the
    OpenSSL CMP client processes this response, the NULL dereference occurs, causing a crash of the CMP client.
    Applications that process untrusted CMP/CRMF messages may be affected.  The FIPS modules in 4.0, 3.6, 3.5, 3.4, and
    3.0 are not affected by this issue, as the affected code is outside the OpenSSL FIPS module boundary.
    Artifact: libssl-dev
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl-dev/copyright, /var/lib/dpkg/info/libssl-dev:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libssl3
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl3/copyright, /var/lib/dpkg/info/libssl3:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: openssl
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/openssl/copyright, /var/lib/dpkg/info/openssl.conffiles,
    /var/lib/dpkg/info/openssl.list, /var/lib/dpkg/info/openssl.md5sums, /var/lib/dpkg/info/openssl.postinst,
    /var/lib/dpkg/status

 »  CVE-2026-12064 (High)
    Description: When a user invokes curl using a schemeless URL combined with `--proto-default` sftp (or
    scp), a disconnect occurs between the tool layer and libcurl. The tool layer incorrectly infers the URL scheme,
    which erroneously bypasses the initialization of critical SSH security options like
    CURLOPT_SSH_HOST_PUBLIC_KEY_SHA256 and CURLOPT_SSH_KNOWNHOSTS. Conversely, the libcurl runtime successfully honors
    CURLOPT_DEFAULT_PROTOCOL and establishes the connection via SFTP/SCP as specified. Because the tool layer skipped
    the security configuration, these SSH host verification options are silently omitted, causing curl to connect to an
    unverified SSH remote host without throwing an error.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-8932 (High)
    Description: libcurl would reuse a previously created connection even when some mTLS config related
    option had been changed that should have prohibited reuse.  libcurl keeps previously used connections in a
    connection pool for subsequent transfers to reuse if one of them matches the setup. However, some TLS settings
    related to client certificates were left out from the configuration match checks, making them match too easily. In
    particular options related to the private key.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-19499 (High)
    Description: Calling strfmon and strfmon_l in the GNU C Library version 2.38 to 2.44 can write past
    the end of the caller-supplied output buffer when a conversion uses right-justified width padding.  Exploitation
    requires an application code path that calls strfmon or strfmon_l with right-justified width padding into a
    destination buffer that is large enough for the padding to succeed but too small for the internal memmove call. The
    field width or format may be attacker-influenced or a fixed susceptible pattern in the caller.  At the time of
    publication, no network-facing application impact is known.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-56855 (High)
    Description: Previously, after a channel has been established, a malicious peer could send crafted
    messages that would deadlock the entire connection.  Now, we handle all RFC 4254 channel messages; global requests
    are handled explicitly. Then, treat all other messages as a protocol error and tear the connection down instead of
    buffering and blocking.
    Artifact: golang.org/x/crypto
    - Current version: v0.55.0
    - Vulnerable version(s): <0.56.0 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-74860 (High)
    Description: A flaw was found in libxml2 with Python bindings enabled. A remote attacker could exploit
    this vulnerability by providing a specially crafted XML document containing a Document Type Definition (DTD) with
    enumerated attribute values. This triggers a double-free error in the SAX attributeDecl callback handler, where a
    string is freed twice. This flaw can lead to a denial of service (DoS) due to a reproducible crash in Python
    applications using the libxml2 SAX bindings.
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-48959 (High)
    Description: IO::Uncompress::Unzip versions before 2.220 for Perl allow CPU exhaustion via per-byte
    read loop in fastForward.  fastForward() compares length $offset (the digit count of the offset, 1 to 19) against
    the chunk size $c instead of $offset itself, so $c shrinks from 16 KiB to 1-19 bytes per iteration.  Extracting a
    named entry from an attacker supplied zip via IO::Uncompress::Unzip->new($zip, Name => $target) drives a per-byte
    read loop scaling with the entry's compressed size, up to the non-Zip64 4 GiB cap.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-5928 (High)
    Description: Calling the ungetwc function on a FILE stream with wide characters encoded in a character
    set that has overlaps between its single byte and multi-byte character encodings, in the GNU C Library version 2.43
    or earlier, may result in an attempt to read bytes before an allocated buffer, potentially resulting in
    unintentional disclosure of neighboring data in the heap, or a program crash.  A bug in the wide character pushback
    implementation (_IO_wdefault_pbackfail in libio/wgenops.c) causes ungetwc() to operate on the regular character
    buffer (fp->_IO_read_ptr) instead of the actual wide-stream read pointer (fp->_wide_data->_IO_read_ptr). The program
    crash may happen in cases where fp->_IO_read_ptr is not initialized and hence points to NULL. The buffer under-read
    requires a special situation where the input character encoding is such that there are overlaps between single byte
    representations and multibyte representations in that encoding, resulting in spurious matches. The spurious match
    case is not possible in the standard Unicode character sets.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-63074 (Medium)
    Description: Issue summary: The OpenSSL Certificate Management Protocol (CMP) caches additional
    certificates (extraCerts) sent in a CMP message, but never expunges them (for instance if they are invalid).  If a
    server reuses an OSSL_CMP_CTX frequently, this cache of extraCerts may grow unboundedly, and a malicious client may
    flood a CMP server with requests driving this growth.  Impact summary: Users utilizing a CMP server that reuses a
    single OSSL_CMP_CTX for the lifetime of a server process may observe unbounded memory growth in the event a
    malicious client repeatedly sends requests containing unique extra certificates, which may lead to OOM conditions.
    CWE: CWE-770: Allocation of Resources Without Limits or Throttling  Description: If a remote user sends CMP messages
    to a server with a list of extraCerts and the message is rejected, the extraCerts from the message remains in the
    server contexts untrusted certificate stack.  This exposes servers with long lived ctx objects to Denial of Service
    attacks in which an attacker sends messages intending to be rejected with a large list of additional certificates
    repeatedly, forcing the server to store them indefinitely.     The issue was fixed by removing the added extra certs
    if the message is rejected, using the same method as when the context is configured to not do caching at all.  FIPS
    impact: no As the CMP code lives outside the FIPS module boundary, no FIPS modules are affected by this CVE.
    Artifact: libssl-dev
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl-dev/copyright, /var/lib/dpkg/info/libssl-dev:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libssl3
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl3/copyright, /var/lib/dpkg/info/libssl3:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: openssl
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/openssl/copyright, /var/lib/dpkg/info/openssl.conffiles,
    /var/lib/dpkg/info/openssl.list, /var/lib/dpkg/info/openssl.md5sums, /var/lib/dpkg/info/openssl.postinst,
    /var/lib/dpkg/status

 »  CVE-2026-6429 (Medium)
    Description: When asked to both use a `.netrc` file for credentials and to follow HTTP redirects,
    libcurl could leak the password used for the first host to the followed-to host under certain circumstances.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2024-7531 (Medium)
    Description: Calling `PK11_Encrypt()` in NSS using CKM_CHACHA20 and the same buffer for input and
    output can result in plaintext on an Intel Sandy Bridge processor. In Firefox this only affects the QUIC header
    protection feature when the connection is using the ChaCha20-Poly1305 cipher suite. The most likely outcome is
    connection failure, but if the connection persists despite the high packet loss it could be possible for a network
    observer to identify packets as coming from the same source despite a network path change. This vulnerability
    affects Firefox < 129, Firefox ESR < 115.14, and Firefox ESR < 128.1.
    Artifact: libnss3
    - Current version: 2:3.87.1-1+deb12u4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libnss3/copyright, /var/lib/dpkg/info/libnss3:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-8286 (High)
    Description: A vulnerability exists where a new transfer that uses STARTTLS to upgrade the connection
    might reuse an existing live connection even though the TLS configuration mismatches so it should not.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-5545 (Medium)
    Description: libcurl might in some circumstances reuse the wrong connection when asked to do an
    authenticated HTTP(S) request after a Negotiate-authenticated one, when both use the same host.  libcurl features a
    pool of recent connections so that subsequent requests can reuse an existing connection to avoid overhead.  When
    reusing a connection a range of criteria must be met. Due to a logical error in the code, a request that was issued
    by an application could wrongfully reuse an existing connection to the same server that was authenticated using
    different credentials.  An application that first uses Negotiate authentication to a server with `user1:password1`
    and then does another operation to the same server asking for any authentication method but for `user2:password2`
    (while the previous connection is still alive) - the second request gets confused and wrongly reuses the same
    connection and sends the new request over that connection thinking it uses a mix of user1's and user2's credentials
    when it is in fact still using the connection authenticated for user1...
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-78662 (High)
    Description: Previously, a channel registered in the mux's chanList is not usable until it is
    established. A malicious peer was able flood the channel's incomingRequests, deadlocking the entire connection.
    Now, we add an atomic established state, set when a channel becomes usable. Until such a time, handlePacket drops
    every packet other than the open confirmation/failure, without blocking and without tearing down the
    connection.
    Artifact: golang.org/x/crypto
    - Current version: v0.55.0
    - Vulnerable version(s): <0.56.0 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-33997 (Medium)
    Description: Moby has an Off-by-one error in its plugin privilege validation
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <29.3.1 (go)
    - Locations: /usr/bin/falcoctl, /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-3184 (Medium)
    Description: A flaw was found in util-linux. Improper hostname canonicalization in the `login(1)`
    utility, when invoked with the `-h` option, can modify the supplied remote hostname before setting `PAM_RHOST`. A
    remote attacker could exploit this by providing a specially crafted hostname, potentially bypassing host-based
    Pluggable Authentication Modules (PAM) access control rules that rely on fully qualified domain names. This could
    lead to unauthorized access.
    Artifact: bsdutils
    - Current version: 1:2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bsdutils/copyright, /var/lib/dpkg/info/bsdutils.list,
    /var/lib/dpkg/info/bsdutils.md5sums, /var/lib/dpkg/status
    Artifact: libblkid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libblkid1/copyright, /var/lib/dpkg/info/libblkid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libmount1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libmount1/copyright, /var/lib/dpkg/info/libmount1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libsmartcols1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsmartcols1/copyright, /var/lib/dpkg/info/libsmartcols1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libuuid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libuuid1/copyright, /var/lib/dpkg/info/libuuid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: mount
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/mount/copyright, /var/lib/dpkg/info/mount.list,
    /var/lib/dpkg/info/mount.md5sums, /var/lib/dpkg/status
    Artifact: util-linux
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux/copyright, /var/lib/dpkg/info/util-linux.conffiles,
    /var/lib/dpkg/info/util-linux.list, /var/lib/dpkg/info/util-linux.md5sums, /var/lib/dpkg/info/util-linux.postinst,
    /var/lib/dpkg/info/util-linux.postrm, /var/lib/dpkg/info/util-linux.prerm, /var/lib/dpkg/status
    Artifact: util-linux-extra
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux-extra/copyright, /var/lib/dpkg/info/util-linux-extra.conffiles,
    /var/lib/dpkg/info/util-linux-extra.list, /var/lib/dpkg/info/util-linux-extra.md5sums,
    /var/lib/dpkg/info/util-linux-extra.postinst, /var/lib/dpkg/info/util-linux-extra.postrm,
    /var/lib/dpkg/info/util-linux-extra.preinst, /var/lib/dpkg/status

 »  CVE-2026-77117 (Medium)
    Description: Converting crafted SHIFT_JISX0213 input to UCS-4 or the internal wide character encoding,
    for example with iconv, in the GNU C Library version 2.3 to 2.44 may result in the converter making no progress,
    causing the calling application to hang.  Some SHIFT_JISX0213 sequences decode to two code points.  If the output
    buffer has room for only the first one, the converter stores the second in the conversion state and returns E2BIG,
    but it never clears that pending character after emitting it on the next call.  The converter then keeps emitting
    the pending character without consuming further input, so an application that retries the conversion loops forever.
    The input must be attacker controlled and the application must convert it with an output buffer small enough to
    split the two code points. Only the SHIFT_JISX0213 character set is affected, which is not commonly used.  The
    related defect in the EUC_JISX0213 converter is tracked separately as CVE-2026-80489.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-80489 (Medium)
    Description: Converting crafted EUC_JISX0213 input to UCS-4 or the internal wide character encoding,
    for example with iconv, in the GNU C Library version 2.3 to 2.44 may result in the converter making no progress,
    causing the calling application to hang.  Some EUC_JISX0213 sequences decode to two code points.  If the output
    buffer has room for only the first one, the converter stores the second in the conversion state and returns E2BIG,
    but it never clears that pending character after emitting it on the next call.  The converter then keeps emitting
    the pending character without consuming further input, so an application that retries the conversion loops forever.
    The input must be attacker controlled and the application must convert it with an output buffer small enough to
    split the two code points. Only the EUC_JISX0213 character set is affected, which is not commonly used.  The related
    defect in SHIFT_JISX0213 converter is tracked separately as CVE-2026-77117.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-48962 (High)
    Description: IO::Compress versions before 2.220 for Perl can execute arbitrary code in
    File::GlobMapper via an attacker-controlled output glob.  _parseOutputGlob() wraps the caller-supplied output glob
    string in double quotes and stores it in the parser state; _getFiles() then runs the stored expression through eval
    STRING. A literal double quote in the output glob closes the dquote wrapper, and the characters that follow are
    evaluated as Perl.  Arbitrary Perl in the output glob executes at the calling process's privilege.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-6276 (High)
    Description: Using libcurl, when a custom `Host:` header is first set for an HTTP request and a second
    request is subsequently done using the same *easy handle* but without the custom `Host:` header set, the second
    request would use stale information and pass on cookies meant for the first host in the second request. Leak
    them.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-19487 (Medium)
    Description: Perl versions from 5.9.4 before 5.41.9 produce incorrect regular expression match results
    when a stale failure flag ends the Aho-Corasick prescan early in S_find_byclass.  The prescan walks the subject for
    positions where the full pattern could match, and the engine tries it from the leftmost one recorded. A failing
    transition sets the failed flag, and a later successful transition does not clear it, so the prescan reads the stale
    flag as a failure and stops before it can record a candidate that starts earlier. It takes a subject where one
    candidate is recorded and a later character then forces a fallback through a fail link that succeeds.  Example:
    "ABCDE" =~ m/ABCF|BCDE|C/;    # matches C at offset 2, not BCDE   "ABCDE" =~ m/ABCF|BCDE|C(G)/; # no match, BCDE
    missed  An alternation like this can miss input it should match, or match it on the wrong branch, so an access or
    filtering decision made from the result can be wrong.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2025-7458 (Critical)
    Description: An integer overflow in the sqlite3KeyInfoFromExprList function in SQLite versions 3.39.2
    through 3.41.1 allows an attacker with the ability to execute arbitrary SQL statements to cause a denial of service
    or disclose sensitive information from process memory via a crafted SELECT statement with a large number of
    expressions in the ORDER BY clause.
    Artifact: libsqlite3-0
    - Current version: 3.40.1-2+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsqlite3-0/copyright, /var/lib/dpkg/info/libsqlite3-0:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-8458 (Medium)
    Description: libcurl might in some circumstances reuse the wrong connection when asked to do
    Negotiate-authenticated ones, even when they are set to use different "services".  libcurl features a pool of recent
    connections so that subsequent requests can reuse an existing connection to avoid overhead.  When reusing a
    connection a range of criteria must be met. Due to a logical error in the code, a request that was issued by an
    application could wrongfully reuse an existing connection to the same server that was authenticated using different
    services.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-5704 (Medium)
    Description: A flaw was found in tar. A remote attacker could exploit this vulnerability by crafting a
    malicious archive, leading to hidden file injection with fully attacker-controlled content. This bypasses
    pre-extraction inspection mechanisms, potentially allowing an attacker to introduce malicious files onto a system
    without detection.
    Artifact: tar
    - Current version: 1.34+dfsg-1.2+deb12u1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/tar/copyright, /var/lib/dpkg/info/tar.list,
    /var/lib/dpkg/info/tar.md5sums, /var/lib/dpkg/info/tar.postinst, /var/lib/dpkg/info/tar.prerm,
    /var/lib/dpkg/status
    
 »  CVE-2026-6238 (Medium)
    Description: The deprecated functions ns_printrrf, ns_printrr and fp_nquery in the GNU C Library
    version 2.0.1 to version 2.43 fail to validate the RDATA content against the RDATA length in a DNS response when
    processing A6, CERT, LOC, TKEY or TSIG records, which may allow an attacker to craft a DNS response, causing a
    target application to crash or read uninitialized memory.  These functions are for application debugging only and
    hence not in the path of code executed by the DNS resolver.  Further, they have been deprecated since version 2.34
    and should not be used by any new applications.  Applications should consider porting away from these interfaces
    since they may be removed in future versions.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2025-7709 (Medium)
    Description: An integer overflow exists in the  FTS5 https://sqlite.org/fts5.html  extension. It
    occurs when the size of an array of tombstone pointers is calculated and truncated into a 32-bit integer. A pointer
    to partially controlled data can then be written out of bounds.
    Artifact: libsqlite3-0
    - Current version: 3.40.1-2+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsqlite3-0/copyright, /var/lib/dpkg/info/libsqlite3-0:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-75803 (Critical)
    Description: Issue summary: ChaCha20-Poly1305 and AES-OCB decryption with an empty ciphertext can
    report success without verifying the supplied authentication tag when the operation is finalized by calling the
    EVP_Cipher() function.  Impact summary: Applications calling EVP_Cipher() on an empty ciphertext and expecting the
    call to check the AEAD tag may accept forged messages.  CWE: CWE-354 (Improper Validation of Integrity Check Value)
    Description: The EVP_Cipher() API call for AEAD ciphers behaves like a one shot encryption and decryption call. It
    also verifies the AEAD tag after the decryption operation. However for AES-OCB and ChaCha20-Poly1305 ciphers it
    skipped the AEAD tag verification when an empty ciphertext was passed to the function. The callers of this function
    might believe that a successful return indicates a valid AEAD tag for these ciphers, even when that has not truly
    been validated in this case.  FIPS impact: no The FIPS modules in 4.0, 3.6, 3.5, 3.4, and 3.0 are not affected by
    this CVE as the affected algorithms are not FIPS approved and thus not implemented in the FIPS module.
    Artifact: libssl-dev
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl-dev/copyright, /var/lib/dpkg/info/libssl-dev:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libssl3
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libssl3/copyright, /var/lib/dpkg/info/libssl3:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: openssl
    - Current version: 3.0.20-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/openssl/copyright, /var/lib/dpkg/info/openssl.conffiles,
    /var/lib/dpkg/info/openssl.list, /var/lib/dpkg/info/openssl.md5sums, /var/lib/dpkg/info/openssl.postinst,
    /var/lib/dpkg/status

 »  CVE-2026-54411 (Medium)
    Description: Linux-PAM through 1.7.2 contains an observable timing discrepancy (CWE-208) in the
    pam_userdb module's plaintext-password comparison path in modules/pam_userdb/pam_userdb.c that allows a local or
    network-adjacent attacker able to repeatedly drive authentication through a calling service to recover the plaintext
    password of a target account by measuring response-timing differences.
    Artifact: libpam-modules
    - Current version: 1.5.2-6+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libpam-modules/copyright,
    /var/lib/dpkg/info/libpam-modules:amd64.conffiles, /var/lib/dpkg/info/libpam-modules:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libpam-modules-bin
    - Current version: 1.5.2-6+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libpam-modules-bin/copyright, /var/lib/dpkg/info/libpam-modules-bin.list,
    /var/lib/dpkg/info/libpam-modules-bin.md5sums, /var/lib/dpkg/status
    Artifact: libpam-runtime
    - Current version: 1.5.2-6+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libpam-runtime/copyright, /var/lib/dpkg/info/libpam-runtime.conffiles,
    /var/lib/dpkg/info/libpam-runtime.list, /var/lib/dpkg/info/libpam-runtime.md5sums,
    /var/lib/dpkg/info/libpam-runtime.postinst, /var/lib/dpkg/info/libpam-runtime.postrm,
    /var/lib/dpkg/info/libpam-runtime.prerm, /var/lib/dpkg/info/libpam-runtime.templates, /var/lib/dpkg/status
    Artifact: libpam0g
    - Current version: 1.5.2-6+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libpam0g/copyright, /var/lib/dpkg/info/libpam0g:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-7017 (High)
    Description: HTTP::Tiny versions before 0.095 for Perl forward credential headers to cross-origin
    redirect targets.  When the server returns a 3xx redirect, `_maybe_redirect` follows the `Location:` header and
    `_prepare_headers_and_cb` re-merges the caller's `headers` argument into the new request, without checking whether
    the redirect target shares an origin with the original URL. Caller-supplied `Authorization`, `Cookie` and
    `Proxy-Authorization` headers are therefore re-sent to whatever host the redirect names, across scheme, host or port
    boundaries, and including `https` to `http` downgrades that expose them in plaintext on the wire.  The HTTP::Tiny
    POD note that "Authorization headers will not be included in a redirected request" applied only to the URL-userinfo
    Basic-auth path, not to headers passed explicitly by the caller.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-4873 (Medium)
    Description: A vulnerability exists where a connection requiring TLS incorrectly reuses an existing
    unencrypted connection from the same connection pool. If an initial transfer is made in clear-text (via IMAP, SMTP,
    or POP3), a subsequent request to that same host bypasses the TLS requirement and instead transmit data
    unencrypted.
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-5435 (High)
    Description: The deprecated functions ns_printrrf, ns_printrr and fp_nquery in the GNU C Library
    version 2.2 and newer fail to enforce the caller-supplied buffer length, and can result in an out-of-bounds write
    when printing TSIG records.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-57432 (High)
    Description: Perl versions before 5.40.5-RC1, from 5.41.0 before 5.42.3-RC1, from 5.43.0 before
    5.43.11 have an integer overflow in S_measure_struct leading to an out-of-bounds heap read in pack and unpack.
    S_measure_struct adds each item's size times its repeat count to a running total with no overflow check, so a large
    repeat count in a pack or unpack template wraps the signed SSize_t total negative. The @, X, and x position codes
    then guard their moves with a signed length comparison that passes when the length is negative, advancing the buffer
    pointer out of bounds.  A template derived from untrusted input can read heap memory past the buffer and return it
    to the caller.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-8674 (Medium)
    Description: Initializing the DNS stub resolver from an /etc/resolv.conf file, or a LOCALDOMAIN
    environment variable, whose search list contains a domain of roughly 200 characters or more in the GNU C Library
    version 2.26 to 2.44 results in an assertion failure which aborts the process.  The resolver truncates the search
    list when copying it into the fixed-size _res.defdname buffer, then asserts that the copy is consistent with the
    full configuration.  The consistency check compared against the wrong size and did not handle a first entry that
    does not fit, so a correctly truncated list failed the assertion.  Any process that resolves names through the
    library is affected, including long-running processes that reload /etc/resolv.conf on the next query after it
    changes.  Search domains are commonly written to /etc/resolv.conf from data received over DHCP or from a VPN server,
    so an attacker on the local network may be able to trigger this without privileges on the target system, subject to
    validation by the network configuration software.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-1965 (Medium)
    Description: libcurl can in some circumstances reuse the wrong connection when asked to do an
    Negotiate-authenticated HTTP or HTTPS request.  libcurl features a pool of recent connections so that subsequent
    requests can reuse an existing connection to avoid overhead.  When reusing a connection a range of criterion must
    first be met. Due to a logical error in the code, a request that was issued by an application could wrongfully reuse
    an existing connection to the same server that was authenticated using different credentials. One underlying reason
    being that Negotiate sometimes authenticates *connections* and not *requests*, contrary to how HTTP is designed to
    work.  An application that allows Negotiate authentication to a server (that responds wanting Negotiate) with
    `user1:password1` and then does another operation to the same server also using Negotiate but with `user2:password2`
    (while the previous connection is still alive) - the second request wrongly reused the same connection and since it
    then sees that the Negotiate negotiation is already made, it sends the request over that connection thinking it uses
    the user2 credentials when it is in fact still using the connection authenticated for user1...  The set of
    authentication methods to use is set with `CURLOPT_HTTPAUTH`.  Applications can disable libcurl's reuse of
    connections and thus mitigate this problem, by using one of the following libcurl options to alter how connections
    are or are not reused: `CURLOPT_FRESH_CONNECT`, `CURLOPT_MAXCONNECTS` and `CURLMOPT_MAX_HOST_CONNECTIONS` (if using
    the curl_multi API).
    Artifact: curl
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/curl/copyright, /var/lib/dpkg/info/curl.list,
    /var/lib/dpkg/info/curl.md5sums, /var/lib/dpkg/status
    Artifact: libcurl3-nss
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl3-nss/copyright, /var/lib/dpkg/info/libcurl3-nss:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libcurl4
    - Current version: 7.88.1-10+deb12u15
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libcurl4/copyright, /var/lib/dpkg/info/libcurl4:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-19542 (Medium)
    Description: Calling tdelete on a sufficiently deep tree in the GNU C Library version 2.1 to 2.44 may
    write one pointer past the end of an alloca-allocated array on the stack, which may crash the application.  The
    tdelete implementation keeps an explicit stack of parent nodes for rebalancing, which is grown as needed while
    descending the tree.  Two rebalancing branches push an additional entry without checking the capacity, and write
    past the array when the stack is exactly full. Triggering this requires a node at a depth of exactly 40 (or 40 plus
    a multiple of 20), which implies a tree with at least a million nodes, so an attacker must drive a large number of
    insertions and deletions through an application that uses tsearch and tdelete.  The written value is a pointer into
    a tree node and is not directly attacker controlled.  No affected application in common distributions has been
    identified.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-58055 (Medium)
    Description: nghttp2's nghttpx proxy through 1.69.0 forwards an HTTP/1.1 Upgrade request that also
    carries a Content-Length header and body onto reusable keep-alive backend connections, re-adding the Upgrade and
    Connection headers while passing Content-Length verbatim. A backend that resolves the resulting ambiguous message in
    the attacker's favor enables HTTP request/response smuggling and cross-client response-queue poisoning.
    Artifact: libnghttp2-14
    - Current version: 1.52.0-1+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libnghttp2-14/copyright, /var/lib/dpkg/info/libnghttp2-14:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-76642 (High)
    Description: util-linux versions through 2.41.5 and 2.42.2 fail to check mount helper exit status
    before running post-mount hooks, allowing unprivileged users to execute privileged operations on pre-existing
    filesystems. Attackers can exploit X-mount.idmap or X-mount.owner hooks to clone filesystems with inherited suid
    bits or modify target inode permissions after a helper fails, achieving privilege escalation.
    Artifact: bsdutils
    - Current version: 1:2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bsdutils/copyright, /var/lib/dpkg/info/bsdutils.list,
    /var/lib/dpkg/info/bsdutils.md5sums, /var/lib/dpkg/status
    Artifact: libblkid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libblkid1/copyright, /var/lib/dpkg/info/libblkid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libmount1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libmount1/copyright, /var/lib/dpkg/info/libmount1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libsmartcols1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsmartcols1/copyright, /var/lib/dpkg/info/libsmartcols1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libuuid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libuuid1/copyright, /var/lib/dpkg/info/libuuid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: mount
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/mount/copyright, /var/lib/dpkg/info/mount.list,
    /var/lib/dpkg/info/mount.md5sums, /var/lib/dpkg/status
    Artifact: util-linux
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux/copyright, /var/lib/dpkg/info/util-linux.conffiles,
    /var/lib/dpkg/info/util-linux.list, /var/lib/dpkg/info/util-linux.md5sums, /var/lib/dpkg/info/util-linux.postinst,
    /var/lib/dpkg/info/util-linux.postrm, /var/lib/dpkg/info/util-linux.prerm, /var/lib/dpkg/status
    Artifact: util-linux-extra
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux-extra/copyright, /var/lib/dpkg/info/util-linux-extra.conffiles,
    /var/lib/dpkg/info/util-linux-extra.list, /var/lib/dpkg/info/util-linux-extra.md5sums,
    /var/lib/dpkg/info/util-linux-extra.postinst, /var/lib/dpkg/info/util-linux-extra.postrm,
    /var/lib/dpkg/info/util-linux-extra.preinst, /var/lib/dpkg/status

 »  CVE-2026-11822 (High)
    Description: SQLite before 3.53.2 contains memory corruption vulnerabilities in the FTS5 full-text
    search extension that allow attackers to cause process crashes, memory exhaustion, or arbitrary code execution by
    supplying a crafted database with malformed FTS5 page data. Attackers can trigger an out-of-bounds read in
    fts5LeafSeek() via an attacker-controlled loop bound and a heap buffer overflow write in fts5ChunkIterate() through
    a crafted continuation page causing an integer underflow, exploitable when an FTS5 MATCH query is executed against
    the malicious database.
    Artifact: libsqlite3-0
    - Current version: 3.40.1-2+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsqlite3-0/copyright, /var/lib/dpkg/info/libsqlite3-0:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-11824 (High)
    Description: SQLite before 3.53.2 contains a heap-based buffer overflow vulnerability in the FTS5
    full-text search extension that allows attackers to cause a crash or execute arbitrary code by supplying a crafted
    database with malicious continuation page metadata specifying a szLeaf value smaller than 4. Attackers can trigger
    an integer underflow in fts5ChunkIterate() causing an inflated remaining byte count during FTS5 MATCH query
    processing, leading to a heap buffer overflow of attacker-controlled data in applications compiled with
    SQLITE_ENABLE_FTS5.
    Artifact: libsqlite3-0
    - Current version: 3.40.1-2+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsqlite3-0/copyright, /var/lib/dpkg/info/libsqlite3-0:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-86144 (High)
    Description: In xinclude in libxml2 before 2.15.4, xmlXIncludeProcess and xmlXIncludeProcessTree do
    not propagate parseFlags. This has security relevance for, for example, the XML_PARSE_NONET flag, if (without it) a
    custom resource loader accesses the internet and triggers XML external entity injection, SSRF, or a denial of
    service (e.g., for an attacker-controlled internet resource that is intentionally slow).
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-7010 (Medium)
    Description: HTTP::Tiny versions before 0.093 for Perl do not validate CRLF in HTTP request lines or
    control field header values.  The unvalidated inputs are the method and URI in the request line, the URL host that
    becomes the `Host:` header, and HTTP/1.1 control data field values.  An attacker who controls one of these inputs,
    for example a user supplied URL passed to a webhook or URL fetch endpoint, can inject additional headers and smuggle
    requests to the upstream server.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2024-10041 (Medium)
    Description: A vulnerability was found in PAM. The secret information is stored in memory, where the
    attacker can trigger the victim program to execute by sending characters to its standard input (stdin). As this
    occurs, the attacker can train the branch predictor to execute an ROP chain speculatively. This flaw could result in
    leaked passwords, such as those found in /etc/shadow while performing authentications.
    Artifact: libpam-modules
    - Current version: 1.5.2-6+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libpam-modules/copyright,
    /var/lib/dpkg/info/libpam-modules:amd64.conffiles, /var/lib/dpkg/info/libpam-modules:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libpam-modules-bin
    - Current version: 1.5.2-6+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libpam-modules-bin/copyright, /var/lib/dpkg/info/libpam-modules-bin.list,
    /var/lib/dpkg/info/libpam-modules-bin.md5sums, /var/lib/dpkg/status
    Artifact: libpam-runtime
    - Current version: 1.5.2-6+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libpam-runtime/copyright, /var/lib/dpkg/info/libpam-runtime.conffiles,
    /var/lib/dpkg/info/libpam-runtime.list, /var/lib/dpkg/info/libpam-runtime.md5sums,
    /var/lib/dpkg/info/libpam-runtime.postinst, /var/lib/dpkg/info/libpam-runtime.postrm,
    /var/lib/dpkg/info/libpam-runtime.prerm, /var/lib/dpkg/info/libpam-runtime.templates, /var/lib/dpkg/status
    Artifact: libpam0g
    - Current version: 1.5.2-6+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libpam0g/copyright, /var/lib/dpkg/info/libpam0g:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-56389 (High)
    Description: GNU Bison allows for an execution of an arbitrary program during HTML report generation
    due to improper handling of grammar-defined configuration variables. A grammar file can override the executable used
    for the XML‑to‑HTML transformation step via %define tool.xsltproc, which is accepted without restriction and passed
    directly to execvp().   When running bison --html on a attacker-provided grammar, this behavior allows execution of
    an arbitrary program with the privileges of the Bison process.   Maintainers of this project were notified about
    this vulnerability, and fixed the issue in commit 3169c1e7a2c6acc4c59dfcf8b089896d6881925b. However, they did not
    provide vulnerable version range. Version 3.8.2 was tested and confirmed as vulnerable, other versions were not
    tested but might also be vulnerable.
    Artifact: bison
    - Current version: 2:3.8.2+dfsg-1+b1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bison/copyright, /var/lib/dpkg/info/bison.list,
    /var/lib/dpkg/info/bison.md5sums, /var/lib/dpkg/info/bison.postinst, /var/lib/dpkg/info/bison.preinst,
    /var/lib/dpkg/info/bison.prerm, /var/lib/dpkg/status

 »  CVE-2026-6791 (Medium)
    Description: When expanding paths that begin with a tilde (~) followed by a username, the internal
    parse_tilde function extracts the username to determine the user's home directory.  The implementation allocates
    memory for this username directly on the stack using the strndupa macro. Because the size of this allocation was
    determined by the length of the user-supplied input without any bounds checks, passing an excessively long username
    e.g. thousands of characters, forces the thread to exhaust its stack space. Thus if an application passes untrusted,
    attacker-controlled input to the wordexp function, an attacker can trigger a stack clash.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-27171 (Medium)
    Description: zlib before 1.3.2 allows CPU consumption via crc32_combine64 and crc32_combine_gen64
    because x2nmodp can do right shifts within a loop that has no termination condition.
    Artifact: zlib1g
    - Current version: 1:1.2.13.dfsg-1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/zlib1g/copyright, /var/lib/dpkg/info/zlib1g:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-41567 (High)
    Description: Docker: `PUT /containers/{id}/archive` executes container binary on the host
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <=28.5.2 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so, /usr/bin/falcoctl

 »  CVE-2026-86142 (High)
    Description: In libxml2 before 2.15.4, there is a heap-based buffer overflow in xmlXPtrEvalXPtrPart
    because of xmlXPtrEval xpointer length saturation.
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-86140 (High)
    Description: In libxml2 before 2.15.4, xmlSnprintfElements in valid.c has a strcat stack-based buffer
    overflow.
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-54369 (High)
    Description: acl before version 2.4.0 contains a symlink traversal vulnerability in the libacl
    pathname-based functions acl_get_file(), acl_set_file(), acl_extended_file(), and acl_delete_def_file() that allows
    local attackers to escalate privileges by replacing any pathname component with a symbolic link. Attackers who
    control any component of a pathname processed by a privileged caller can redirect ACL read or write operations to
    arbitrary files or directories, enabling unauthorized manipulation of access control lists and local privilege
    escalation.
    Artifact: libacl1
    - Current version: 2.3.1-3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libacl1/copyright, /var/lib/dpkg/info/libacl1:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-89092 (Medium)
    Description: The nscd service in the GNU C Library 2.3.4 onwards may crash due to a  stack overflow
    when a malicious DNS server returns too large a response  for a DNS query, resulting in degraded DNS resolution for
    the system.    Exploitation of this bug needs a system that has nscd enabled and using  an untrusted DNS server for
    name resolution, with the compromised DNS  server being capable of processing records large enough to result in a
    stack overflow in an nscd thread stack.  During experimentation, bind 9  was unable to handle large records, but
    that could change in future or  with a different name server.  In typical installations, nscd is  executed in an
    isolated context as its own user without a shell, due to  which any compromise of that service is isolated.    There
    is a remote possibility of nscd cache corruption if an attacker  manages to get the stack pointer into a desired
    point in the heap,  potentially resulting in other caches in nscd being overwritten with  corrupt data through the
    stack overflow, until the buggy code path  eventually results in a crash.    Finally, a crash in nscd may result in
    performance degradation when  resolving names, but it does not result in a denial of service.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2025-6141 (Medium)
    Description: A vulnerability has been found in GNU ncurses up to 6.5-20250322 and classified as
    problematic. This vulnerability affects the function postprocess_termcap of the file tinfo/parse_entry.c. The
    manipulation leads to stack-based buffer overflow. The attack needs to be approached locally. Upgrading to version
    6.5-20250329 is able to address this issue. It is recommended to upgrade the affected component.
    Artifact: libncursesw6
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /var/lib/dpkg/info/libncursesw6:amd64.md5sums, /usr/share/doc/libtinfo6/copyright,
    /var/lib/dpkg/status
    Artifact: libtinfo6
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libtinfo6/copyright, /var/lib/dpkg/info/libtinfo6:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: ncurses-base
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/ncurses-base/copyright, /var/lib/dpkg/info/ncurses-base.conffiles,
    /var/lib/dpkg/info/ncurses-base.list, /var/lib/dpkg/info/ncurses-base.md5sums, /var/lib/dpkg/status
    Artifact: ncurses-bin
    - Current version: 6.4-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/ncurses-bin/copyright, /var/lib/dpkg/info/ncurses-bin.list,
    /var/lib/dpkg/info/ncurses-bin.md5sums, /var/lib/dpkg/status

 »  CVE-2026-86138 (High)
    Description: In libxml2 before 2.15.4, xmlDictAddQString in dict.c has an integer overflow and
    resultant heap-based buffer overflow.
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-86143 (High)
    Description: In xmlIO in libxml2 before 2.15.4, an inconsistency in xmlOutputWriteCallback and
    xmlBufUse causes negative lengths to reach write callbacks, aka a lack of a check for integer overflow before
    calling writecallback. This has security relevance for many types of uses of that length value within a
    callback.
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2025-30258 (Medium)
    Description: In GnuPG before 2.5.5, if a user chooses to import a certificate with certain crafted
    subkey data that lacks a valid backsig or that has incorrect usage flags, the user loses the ability to verify
    signatures made from certain other signing keys, aka a "verification DoS."
    Artifact: dirmngr
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/dirmngr/copyright, /var/lib/dpkg/info/dirmngr.list,
    /var/lib/dpkg/info/dirmngr.md5sums, /var/lib/dpkg/info/dirmngr.postinst, /var/lib/dpkg/info/dirmngr.postrm,
    /var/lib/dpkg/info/dirmngr.preinst, /var/lib/dpkg/info/dirmngr.prerm, /var/lib/dpkg/status
    Artifact: gnupg
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gnupg/copyright, /var/lib/dpkg/info/gnupg.list,
    /var/lib/dpkg/info/gnupg.md5sums, /var/lib/dpkg/status
    Artifact: gnupg-l10n
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gnupg-l10n/copyright, /var/lib/dpkg/info/gnupg-l10n.list,
    /var/lib/dpkg/info/gnupg-l10n.md5sums, /var/lib/dpkg/status
    Artifact: gnupg-utils
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gnupg-utils/copyright, /var/lib/dpkg/info/gnupg-utils.list,
    /var/lib/dpkg/info/gnupg-utils.md5sums, /var/lib/dpkg/status
    Artifact: gpg
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpg/copyright, /var/lib/dpkg/info/gpg.list,
    /var/lib/dpkg/info/gpg.md5sums, /var/lib/dpkg/status
    Artifact: gpg-agent
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpg-agent/copyright, /var/lib/dpkg/info/gpg-agent.conffiles,
    /var/lib/dpkg/info/gpg-agent.list, /var/lib/dpkg/info/gpg-agent.md5sums, /var/lib/dpkg/info/gpg-agent.postinst,
    /var/lib/dpkg/info/gpg-agent.postrm, /var/lib/dpkg/status
    Artifact: gpg-wks-client
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpg-wks-client/copyright, /var/lib/dpkg/info/gpg-wks-client.list,
    /var/lib/dpkg/info/gpg-wks-client.md5sums, /var/lib/dpkg/status
    Artifact: gpg-wks-server
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpg-wks-server/copyright, /var/lib/dpkg/info/gpg-wks-server.list,
    /var/lib/dpkg/info/gpg-wks-server.md5sums, /var/lib/dpkg/status
    Artifact: gpgconf
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpgconf/copyright, /var/lib/dpkg/info/gpgconf.list,
    /var/lib/dpkg/info/gpgconf.md5sums, /var/lib/dpkg/status
    Artifact: gpgsm
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpgsm/copyright, /var/lib/dpkg/info/gpgsm.list,
    /var/lib/dpkg/info/gpgsm.md5sums, /var/lib/dpkg/status
    Artifact: gpgv
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpgv/copyright, /var/lib/dpkg/info/gpgv.list,
    /var/lib/dpkg/info/gpgv.md5sums, /var/lib/dpkg/status

 »  CVE-2026-41991 (Medium)
    Description: GNU gzip contains a vulnerability in the gzexe utility related to insecure temporary file
    handling. When the mktemp utility is not available in the user’s PATH, gzexe falls back to constructing a temporary
    file path based solely on the process ID (PID). This predictable filename is created without exclusive access or
    existence checks. A local attacker can pre‑create the predicted temporary file path as a symbolic link pointing to
    an arbitrary file writable by the victim. When gzexe runs, it follows the symlink and overwrites the target file,
    resulting in a time‑of‑check to time‑of‑use (TOCTOU) condition that allows arbitrary file overwrite.  This issue has
    been fixed in the commit 4e6f8b24ab823146ab8776f0b7fe486ab34d4269
    Artifact: gzip
    - Current version: 1.12-1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gzip/copyright, /var/lib/dpkg/info/gzip.list,
    /var/lib/dpkg/info/gzip.md5sums, /var/lib/dpkg/status

 »  CVE-2026-78409 (High)
    Description: The X-mount.subdir option uses a detached-tree fast path on Linux 6.15 and later and
    passes the configured subdirectory to open_tree() with AT_SYMLINK_NOFOLLOW. That flag does not stop intermediate
    symlink traversal or keep resolution inside the newly mounted filesystem. A local unprivileged user with an
    fstab-authorized X-mount.subdir entry can attach a host path at the intended mountpoint.
    Artifact: bsdutils
    - Current version: 1:2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bsdutils/copyright, /var/lib/dpkg/info/bsdutils.list,
    /var/lib/dpkg/info/bsdutils.md5sums, /var/lib/dpkg/status
    Artifact: libblkid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libblkid1/copyright, /var/lib/dpkg/info/libblkid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libmount1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libmount1/copyright, /var/lib/dpkg/info/libmount1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libsmartcols1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsmartcols1/copyright, /var/lib/dpkg/info/libsmartcols1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libuuid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libuuid1/copyright, /var/lib/dpkg/info/libuuid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: mount
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/mount/copyright, /var/lib/dpkg/info/mount.list,
    /var/lib/dpkg/info/mount.md5sums, /var/lib/dpkg/status
    Artifact: util-linux
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux/copyright, /var/lib/dpkg/info/util-linux.conffiles,
    /var/lib/dpkg/info/util-linux.list, /var/lib/dpkg/info/util-linux.md5sums, /var/lib/dpkg/info/util-linux.postinst,
    /var/lib/dpkg/info/util-linux.postrm, /var/lib/dpkg/info/util-linux.prerm, /var/lib/dpkg/status
    Artifact: util-linux-extra
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux-extra/copyright, /var/lib/dpkg/info/util-linux-extra.conffiles,
    /var/lib/dpkg/info/util-linux-extra.list, /var/lib/dpkg/info/util-linux-extra.md5sums,
    /var/lib/dpkg/info/util-linux-extra.postinst, /var/lib/dpkg/info/util-linux-extra.postrm,
    /var/lib/dpkg/info/util-linux-extra.preinst, /var/lib/dpkg/status

 »  CVE-2026-15534 (Medium)
    Description: Perl versions through 5.45.1 have out-of-bounds heap reads and writes during regular
    expression matching via an undersized superlinear cache in S_regmatch.  The regex engine's superlinear cache holds
    one bit per subject position for each participating WHILEM node, so the bit count is the subject length plus one
    times the number of nodes. Nothing checks that product for positive overflow of the signed 32-bit count: a 286331153
    byte subject matched against a pattern with 15 participating nodes stores the count as 14, leaving a two byte cache.
    The cache is then indexed from the real match position and node number, so reads go past the end of the allocation,
    and on failure CACHEsayNO sets a bit past it.  A caller that matches an attacker controlled subject of this size
    against a pattern of this shape can crash the process or corrupt heap memory.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-78408 (High)
    Description: The nsenter --join-cgroup option opens the target cgroup.procs file as root and leaves
    that file descriptor open across later namespace and credential changes and across execve(). Because the kernel
    checks later cgroup migrations using the credentials from the original open, a program run in an attacker-controlled
    target can inherit root's ability to move host processes between cgroups. After a privileged operator uses
    --join-cgroup against that target, an unprivileged user can migrate and terminate unrelated root processes.
    Artifact: bsdutils
    - Current version: 1:2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bsdutils/copyright, /var/lib/dpkg/info/bsdutils.list,
    /var/lib/dpkg/info/bsdutils.md5sums, /var/lib/dpkg/status
    Artifact: libblkid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libblkid1/copyright, /var/lib/dpkg/info/libblkid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libmount1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libmount1/copyright, /var/lib/dpkg/info/libmount1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libsmartcols1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsmartcols1/copyright, /var/lib/dpkg/info/libsmartcols1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libuuid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libuuid1/copyright, /var/lib/dpkg/info/libuuid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: mount
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/mount/copyright, /var/lib/dpkg/info/mount.list,
    /var/lib/dpkg/info/mount.md5sums, /var/lib/dpkg/status
    Artifact: util-linux
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux/copyright, /var/lib/dpkg/info/util-linux.conffiles,
    /var/lib/dpkg/info/util-linux.list, /var/lib/dpkg/info/util-linux.md5sums, /var/lib/dpkg/info/util-linux.postinst,
    /var/lib/dpkg/info/util-linux.postrm, /var/lib/dpkg/info/util-linux.prerm, /var/lib/dpkg/status
    Artifact: util-linux-extra
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux-extra/copyright, /var/lib/dpkg/info/util-linux-extra.conffiles,
    /var/lib/dpkg/info/util-linux-extra.list, /var/lib/dpkg/info/util-linux-extra.md5sums,
    /var/lib/dpkg/info/util-linux-extra.postinst, /var/lib/dpkg/info/util-linux-extra.postrm,
    /var/lib/dpkg/info/util-linux-extra.preinst, /var/lib/dpkg/status

 »  CVE-2026-13595 (Medium)
    Description: A flaw was found in the libblkid library of util-linux. During nested partition probing,
    the BSD, Minix, Solaris x86, and UnixWare partition probers cache a raw pointer to a parent partition entry in a
    dynamically allocated array. When subsequent partition additions cause the array to be reallocated, this pointer
    becomes stale, leading to a heap use-after-free read. An attacker who can present a crafted block device image (for
    example, via USB insertion or a loop-mounted disk image) can trigger this flaw without user interaction, as libblkid
    is invoked automatically by udev/udisks as root on block-device hot-plug events. This could lead to limited
    information disclosure or denial of service.
    Artifact: bsdutils
    - Current version: 1:2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bsdutils/copyright, /var/lib/dpkg/info/bsdutils.list,
    /var/lib/dpkg/info/bsdutils.md5sums, /var/lib/dpkg/status
    Artifact: libblkid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libblkid1/copyright, /var/lib/dpkg/info/libblkid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libmount1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libmount1/copyright, /var/lib/dpkg/info/libmount1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libsmartcols1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsmartcols1/copyright, /var/lib/dpkg/info/libsmartcols1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libuuid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libuuid1/copyright, /var/lib/dpkg/info/libuuid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: mount
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/mount/copyright, /var/lib/dpkg/info/mount.list,
    /var/lib/dpkg/info/mount.md5sums, /var/lib/dpkg/status
    Artifact: util-linux
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux/copyright, /var/lib/dpkg/info/util-linux.conffiles,
    /var/lib/dpkg/info/util-linux.list, /var/lib/dpkg/info/util-linux.md5sums, /var/lib/dpkg/info/util-linux.postinst,
    /var/lib/dpkg/info/util-linux.postrm, /var/lib/dpkg/info/util-linux.prerm, /var/lib/dpkg/status
    Artifact: util-linux-extra
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux-extra/copyright, /var/lib/dpkg/info/util-linux-extra.conffiles,
    /var/lib/dpkg/info/util-linux-extra.list, /var/lib/dpkg/info/util-linux-extra.md5sums,
    /var/lib/dpkg/info/util-linux-extra.postinst, /var/lib/dpkg/info/util-linux-extra.postrm,
    /var/lib/dpkg/info/util-linux-extra.preinst, /var/lib/dpkg/status

 »  CVE-2026-86139 (High)
    Description: In libxml2 before 2.15.4, xmlURIEscapeStr in uri.c has an integer overflow.
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-50812 (Medium)
    Description: A NULL pointer dereference in the SQLite Session Extension in SQLite 3.53.1 and SQLite
    trunk builds before check-in e807d4e3798efd53 allows an attacker who can supply a malformed changeset blob to cause
    a denial of service. The issue occurs when sqlite3changeset_apply_v3() applies a corrupt changeset and reaches
    sqlite3_value_type() with a NULL sqlite3_value pointer.
    Artifact: libsqlite3-0
    - Current version: 3.40.1-2+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsqlite3-0/copyright, /var/lib/dpkg/info/libsqlite3-0:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-76781 (Medium)
    Description: A flaw was found in libxml2. A local user or an attacker providing a specially crafted
    XML catalog can trigger a NULL pointer dereference during XML catalog parsing. This occurs when a `nextCatalog`
    element lacks its mandatory `catalog` attribute, leading to the application crashing and causing a Denial of Service
    (DoS).
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-50813 (Medium)
    Description: An issue in SQLite before Fossil check-in 869a51ae84df allows a local attacker to obtain
    sensitive information via the Session Extension changeset concat/changegroup merge path
    Artifact: libsqlite3-0
    - Current version: 3.40.1-2+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsqlite3-0/copyright, /var/lib/dpkg/info/libsqlite3-0:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-13757 (Medium)
    Description: A flaw was found in p11-kit. The RPC message attribute parsing functions
    p11_rpc_message_get_attribute() and p11_rpc_message_get_attribute_array_value() form a mutually-recursive call chain
    with no recursion depth limit when processing nested CKA_WRAP_TEMPLATE, CKA_UNWRAP_TEMPLATE, and CKA_DERIVE_TEMPLATE
    attributes. An unauthenticated attacker with local access to the p11-kit RPC Unix domain socket can send a specially
    crafted request with deeply nested template attributes, causing stack exhaustion and crashing the p11-kit server
    process and its dependent services.
    Artifact: libp11-kit0
    - Current version: 0.24.1-2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libp11-kit0/copyright, /var/lib/dpkg/info/libp11-kit0:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-54371 (Medium)
    Description: attr before version 2.6.0 contains a symlink traversal vulnerability in the getfattr and
    setfattr utilities that allows local attackers to escalate privileges by replacing a pathname component with a
    symbolic link during directory hierarchy traversal. Attackers who control a pathname component can redirect getfattr
    and setfattr operations to arbitrary files by substituting a symlink, leading to local privilege escalation when
    getfattr or setfattr is invoked by a privileged process over an attacker-controlled path.
    Artifact: libattr1
    - Current version: 1:2.5.1-4
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libattr1/copyright, /var/lib/dpkg/info/libattr1:amd64.conffiles,
    /var/lib/dpkg/info/libattr1:amd64.md5sums, /var/lib/dpkg/status

 »  CVE-2026-42306 (High)
    Description: Docker: Race condition in docker cp allows bind mount redirection to host path
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <=28.5.2 (go)
    - Locations: /usr/share/falco/plugins/libcontainer.so, /usr/bin/falcoctl

 »  CVE-2026-18374 (Medium)
    Description: Passing an effectively empty string to the `,ccs=` syntax extension of the mode argument
    in the `fopen` function in the GNU C Library version 2.45 or earlier may result in a heap buffer overflow when the
    mode string input to the function is attacker controlled.    This usage pattern is not seen in applications in
    common GNU/Linux distributions and applications that process user-supplied values for `ccs` should not pass them
    through without validation.
    Artifact: libc-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-bin/copyright, /var/lib/dpkg/info/libc-bin.conffiles,
    /var/lib/dpkg/info/libc-bin.list, /var/lib/dpkg/info/libc-bin.md5sums, /var/lib/dpkg/info/libc-bin.postinst,
    /var/lib/dpkg/info/libc-bin.triggers, /var/lib/dpkg/status
    Artifact: libc-dev-bin
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc-dev-bin/copyright, /var/lib/dpkg/info/libc-dev-bin.list,
    /var/lib/dpkg/info/libc-dev-bin.md5sums, /var/lib/dpkg/status
    Artifact: libc6
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6/copyright, /var/lib/dpkg/info/libc6:amd64.conffiles,
    /var/lib/dpkg/info/libc6:amd64.md5sums, /var/lib/dpkg/status
    Artifact: libc6-dev
    - Current version: 2.36-9+deb12u14
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libc6-dev/copyright, /var/lib/dpkg/info/libc6-dev:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-78410 (High)
    Description: A flaw was found in util-linux. Restricted bind mounts take the source path from fstab
    but do not pin that source before the privileged mount. A local unprivileged user who can replace the authorized
    source or a writable ancestor can redirect SUID mount(8) to bind another host directory. If the fstab entry also
    sets X-mount.owner, X-mount.group, or X-mount.mode, root then changes ownership or mode on that redirected
    inode.
    Artifact: bsdutils
    - Current version: 1:2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bsdutils/copyright, /var/lib/dpkg/info/bsdutils.list,
    /var/lib/dpkg/info/bsdutils.md5sums, /var/lib/dpkg/status
    Artifact: libblkid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libblkid1/copyright, /var/lib/dpkg/info/libblkid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libmount1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libmount1/copyright, /var/lib/dpkg/info/libmount1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libsmartcols1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsmartcols1/copyright, /var/lib/dpkg/info/libsmartcols1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libuuid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libuuid1/copyright, /var/lib/dpkg/info/libuuid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: mount
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/mount/copyright, /var/lib/dpkg/info/mount.list,
    /var/lib/dpkg/info/mount.md5sums, /var/lib/dpkg/status
    Artifact: util-linux
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux/copyright, /var/lib/dpkg/info/util-linux.conffiles,
    /var/lib/dpkg/info/util-linux.list, /var/lib/dpkg/info/util-linux.md5sums, /var/lib/dpkg/info/util-linux.postinst,
    /var/lib/dpkg/info/util-linux.postrm, /var/lib/dpkg/info/util-linux.prerm, /var/lib/dpkg/status
    Artifact: util-linux-extra
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux-extra/copyright, /var/lib/dpkg/info/util-linux-extra.conffiles,
    /var/lib/dpkg/info/util-linux-extra.list, /var/lib/dpkg/info/util-linux-extra.md5sums,
    /var/lib/dpkg/info/util-linux-extra.postinst, /var/lib/dpkg/info/util-linux-extra.postrm,
    /var/lib/dpkg/info/util-linux-extra.preinst, /var/lib/dpkg/status

 »  CVE-2026-86137 (Medium)
    Description: In libxml2 before 2.15.4, xmlFAParsePosCharGroup has an out-of-bounds read, aka an
    out-of-bounds read in the NXT macro in xmlregexp.
    Artifact: libxml2
    - Current version: 2.9.14+dfsg-1.3~deb12u6
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libxml2/copyright, /var/lib/dpkg/info/libxml2:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-56390 (Medium)
    Description: GNU Bison improperly handles grammar‑defined output paths. Grammar directives such as
    %output and %header allow specifying file paths, which are accepted without restriction and override caller‑supplied
    output options.  When processing attacker-supplied grammar, this behavior allows directing generated files to
    arbitrary writable locations on the filesystem, potentially overwriting existing files accessible to the Bison
    process.  Maintainers of this project were notified about this vulnerability, and fixed the issue in
    commit 8d101c19d4d9aaedf83a448c925513742d4efcf0. However, they did not provide vulnerable version range. Version
    3.8.2 was tested and confirmed as vulnerable, other versions were not tested but might also be vulnerable.
    Artifact: bison
    - Current version: 2:3.8.2+dfsg-1+b1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bison/copyright, /var/lib/dpkg/info/bison.list,
    /var/lib/dpkg/info/bison.md5sums, /var/lib/dpkg/info/bison.postinst, /var/lib/dpkg/info/bison.preinst,
    /var/lib/dpkg/info/bison.prerm, /var/lib/dpkg/status

 »  CVE-2025-15649 (Medium)
    Description: IO::Uncompress::Unzip versions before 2.215 for Perl propagate uncaught exception when
    parsing zip header with malformed DOS date.  _dosToUnixTime() decodes the local-file-header last-modification date
    field and calls Time::Local::timelocal() without an eval guard. A header whose date field decodes to an out-of-range
    month, day, or hour causes timelocal() to die.  The exception propagates out of IO::Uncompress::Unzip->new($file)
    where callers expect undef plus $UnzipError.
    Artifact: libperl5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libperl5.36/copyright, /var/lib/dpkg/info/libperl5.36:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: perl
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl/copyright, /var/lib/dpkg/info/perl.conffiles,
    /var/lib/dpkg/info/perl.list, /var/lib/dpkg/info/perl.md5sums, /var/lib/dpkg/info/perl.postinst,
    /var/lib/dpkg/info/perl.postrm, /var/lib/dpkg/info/perl.preinst, /var/lib/dpkg/info/perl.prerm,
    /var/lib/dpkg/status
    Artifact: perl-base
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-base/copyright, /var/lib/dpkg/info/perl-base.md5sums,
    /var/lib/dpkg/info/perl-base.postinst, /var/lib/dpkg/info/perl-base.postrm, /var/lib/dpkg/info/perl-base.preinst,
    /var/lib/dpkg/info/perl-base.prerm, /var/lib/dpkg/info/perl-base.list, /var/lib/dpkg/status
    Artifact: perl-modules-5.36
    - Current version: 5.36.0-7+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/perl-modules-5.36/copyright, /var/lib/dpkg/info/perl-modules-5.36.list,
    /var/lib/dpkg/info/perl-modules-5.36.md5sums, /var/lib/dpkg/status

 »  CVE-2026-18508 (Medium)
    Description: A flaw was found in GNU tar. When extracting an archive with the --one-top-level option,
    hardlink targets are not confined to the designated top-level directory and may resolve relative to the extraction
    working directory. A crafted archive can create hardlinks that escape the intended boundary and, when combined with
    a preexisting symbolic link under the working directory, may allow writing outside that boundary during a single
    extraction.
    Artifact: tar
    - Current version: 1.34+dfsg-1.2+deb12u1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/tar/copyright, /var/lib/dpkg/info/tar.list,
    /var/lib/dpkg/info/tar.md5sums, /var/lib/dpkg/info/tar.postinst, /var/lib/dpkg/info/tar.prerm,
    /var/lib/dpkg/status

 »  CVE-2026-54370 (High)
    Description: acl before version 2.4.0 contains a time-of-check to time-of-use (TOCTOU) race condition
    vulnerability that allows local attackers to escalate privileges by replacing a pathname component with a symbolic
    link between an lstat() check and subsequent symlink-following operations such as stat(), chown(), chmod(),
    acl_get_file(), and acl_set_file(). Attackers who control a pathname component can redirect file access control list
    operations to arbitrary files when getfacl, setfacl, or chacl is invoked by a privileged process over an
    attacker-controlled path, resulting in local privilege escalation.
    Artifact: libacl1
    - Current version: 2.3.1-3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libacl1/copyright, /var/lib/dpkg/info/libacl1:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-15059 (Medium)
    Description: Local unprivileged users can terminate arbitrary local processes via a systemd-oomd IPC
    API due to a missing path traversal validation.
    Artifact: libsystemd0
    - Current version: 252.39-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsystemd0/copyright, /var/lib/dpkg/info/libsystemd0:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libudev1
    - Current version: 252.39-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libudev1/copyright, /var/lib/dpkg/info/libudev1:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-42250 (Medium)
    Description: bzip2 contains an off‑by‑one error in the bzip2recover utility. When processing a
    specially crafted file, the application performs an out‑of‑bounds write to a global buffer, resulting in memory
    corruption and a crash (denial of service).  This issue was fixed in bzip2
    patch 35d122a3df8b0cc4082a4d89fdc6ee99f375fe67
    Artifact: bzip2
    - Current version: 1.0.8-5+b1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bzip2/copyright, /var/lib/dpkg/info/bzip2.list,
    /var/lib/dpkg/info/bzip2.md5sums, /var/lib/dpkg/status
    Artifact: libbz2-1.0
    - Current version: 1.0.8-5+b1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libbz2-1.0/copyright, /var/lib/dpkg/info/libbz2-1.0:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-41568 (Medium)
    Description: Docker: Race condition in docker cp allows creation of arbitrary empty files on the host
    via symlink swap
    Artifact: github.com/docker/docker
    - Current version: v28.5.2+incompatible
    - Vulnerable version(s): <=28.5.2 (go)
    - Locations: /usr/bin/falcoctl, /usr/share/falco/plugins/libcontainer.so

 »  CVE-2026-18938 (Medium)
    Description: A flaw was found in p11-kit. A local attacker, or one with equivalent access to a
    reachable RPC channel, could exploit an integer overflow vulnerability. By sending specially crafted messages, the
    attacker can cause the system to miscalculate memory allocation for nested attributes. This leads to a memory
    corruption issue, specifically a heap out-of-bounds write, which can crash the p11-kit RPC parsing process,
    resulting in a Denial of Service (DoS). This vulnerability is only exploitable on 32 bit systems.
    Artifact: libp11-kit0
    - Current version: 0.24.1-2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libp11-kit0/copyright, /var/lib/dpkg/info/libp11-kit0:amd64.md5sums,
    /var/lib/dpkg/status

 »  CVE-2026-27456 (Medium)
    Description: util-linux is a random collection of Linux utilities. Prior to version 2.41.4, a TOCTOU
    (Time-of-Check-Time-of-Use) vulnerability has been identified in the SUID binary /usr/bin/mount from util-linux. The
    mount binary, when setting up loop devices, validates the source file path with user privileges via fork() +
    setuid() + realpath(), but subsequently re-canonicalizes and opens it with root privileges (euid=0) without
    verifying that the path has not been replaced between both operations. Neither O_NOFOLLOW, nor inode comparison, nor
    post-open fstat() are employed. This allows a local unprivileged user to replace the source file with a symlink
    pointing to any root-owned file or device during the race window, causing the SUID binary to open and mount it as
    root. Exploitation requires an /etc/fstab entry with user,loop options whose path points to a directory where the
    attacker has write permission, and that /usr/bin/mount has the SUID bit set (the default configuration on virtually
    all Linux distributions). The impact is unauthorized read access to root-protected files and block devices,
    including backup images, disk volumes, and any file containing a valid filesystem. This issue has been patched in
    version 2.41.4.
    Artifact: bsdutils
    - Current version: 1:2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/bsdutils/copyright, /var/lib/dpkg/info/bsdutils.list,
    /var/lib/dpkg/info/bsdutils.md5sums, /var/lib/dpkg/status
    Artifact: libblkid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libblkid1/copyright, /var/lib/dpkg/info/libblkid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libmount1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libmount1/copyright, /var/lib/dpkg/info/libmount1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libsmartcols1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsmartcols1/copyright, /var/lib/dpkg/info/libsmartcols1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libuuid1
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libuuid1/copyright, /var/lib/dpkg/info/libuuid1:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: mount
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/mount/copyright, /var/lib/dpkg/info/mount.list,
    /var/lib/dpkg/info/mount.md5sums, /var/lib/dpkg/status
    Artifact: util-linux
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux/copyright, /var/lib/dpkg/info/util-linux.conffiles,
    /var/lib/dpkg/info/util-linux.list, /var/lib/dpkg/info/util-linux.md5sums, /var/lib/dpkg/info/util-linux.postinst,
    /var/lib/dpkg/info/util-linux.postrm, /var/lib/dpkg/info/util-linux.prerm, /var/lib/dpkg/status
    Artifact: util-linux-extra
    - Current version: 2.38.1-5+deb12u3
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/util-linux-extra/copyright, /var/lib/dpkg/info/util-linux-extra.conffiles,
    /var/lib/dpkg/info/util-linux-extra.list, /var/lib/dpkg/info/util-linux-extra.md5sums,
    /var/lib/dpkg/info/util-linux-extra.postinst, /var/lib/dpkg/info/util-linux-extra.postrm,
    /var/lib/dpkg/info/util-linux-extra.preinst, /var/lib/dpkg/status

 »  CVE-2025-68972 (Medium)
    Description: In GnuPG through 2.4.8, if a signed message has \f at the end of a plaintext line, an
    adversary can construct a modified message that places additional text after the signed material, such that
    signature verification of the modified message succeeds (although an "invalid armor" message is printed during
    verification). This is related to use of \f as a marker to denote truncation of a long plaintext line.
    Artifact: dirmngr
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/dirmngr/copyright, /var/lib/dpkg/info/dirmngr.list,
    /var/lib/dpkg/info/dirmngr.md5sums, /var/lib/dpkg/info/dirmngr.postinst, /var/lib/dpkg/info/dirmngr.postrm,
    /var/lib/dpkg/info/dirmngr.preinst, /var/lib/dpkg/info/dirmngr.prerm, /var/lib/dpkg/status
    Artifact: gnupg
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gnupg/copyright, /var/lib/dpkg/info/gnupg.list,
    /var/lib/dpkg/info/gnupg.md5sums, /var/lib/dpkg/status
    Artifact: gnupg-l10n
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gnupg-l10n/copyright, /var/lib/dpkg/info/gnupg-l10n.list,
    /var/lib/dpkg/info/gnupg-l10n.md5sums, /var/lib/dpkg/status
    Artifact: gnupg-utils
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gnupg-utils/copyright, /var/lib/dpkg/info/gnupg-utils.list,
    /var/lib/dpkg/info/gnupg-utils.md5sums, /var/lib/dpkg/status
    Artifact: gpg
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpg/copyright, /var/lib/dpkg/info/gpg.list,
    /var/lib/dpkg/info/gpg.md5sums, /var/lib/dpkg/status
    Artifact: gpg-agent
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpg-agent/copyright, /var/lib/dpkg/info/gpg-agent.conffiles,
    /var/lib/dpkg/info/gpg-agent.list, /var/lib/dpkg/info/gpg-agent.md5sums, /var/lib/dpkg/info/gpg-agent.postinst,
    /var/lib/dpkg/info/gpg-agent.postrm, /var/lib/dpkg/status
    Artifact: gpg-wks-client
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpg-wks-client/copyright, /var/lib/dpkg/info/gpg-wks-client.list,
    /var/lib/dpkg/info/gpg-wks-client.md5sums, /var/lib/dpkg/status
    Artifact: gpg-wks-server
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpg-wks-server/copyright, /var/lib/dpkg/info/gpg-wks-server.list,
    /var/lib/dpkg/info/gpg-wks-server.md5sums, /var/lib/dpkg/status
    Artifact: gpgconf
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpgconf/copyright, /var/lib/dpkg/info/gpgconf.list,
    /var/lib/dpkg/info/gpgconf.md5sums, /var/lib/dpkg/status
    Artifact: gpgsm
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpgsm/copyright, /var/lib/dpkg/info/gpgsm.list,
    /var/lib/dpkg/info/gpgsm.md5sums, /var/lib/dpkg/status
    Artifact: gpgv
    - Current version: 2.2.40-1.1+deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/gpgv/copyright, /var/lib/dpkg/info/gpgv.list,
    /var/lib/dpkg/info/gpgv.md5sums, /var/lib/dpkg/status

 »  CVE-2026-18477 (Medium)
    Description: A TOCTOU (Time-of-Check Time-of-Use) vulnerability in GNU tar's incremental dumpdir 'X'
    rename handling allows a local attacker with write access to a directory being backed up to influence the restore
    process if the attacker has access to the system where the restore is being performed. During restoration, files or
    directories may be created, renamed or overwritten outside the intended extraction directory. This could lead to
    unauthorized file modification or, in some cases, privilege escalation. Exploitation does not require the attacker
    to modify or craft the archive, and standard backup and restore workflows—including extracting into a newly created
    directory without using the -P option do not mitigate the issue.
    Artifact: tar
    - Current version: 1.34+dfsg-1.2+deb12u1
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/tar/copyright, /var/lib/dpkg/info/tar.list,
    /var/lib/dpkg/info/tar.md5sums, /var/lib/dpkg/info/tar.postinst, /var/lib/dpkg/info/tar.prerm,
    /var/lib/dpkg/status

 »  CVE-2026-16742 (Medium)
    Description: systemd-homed contains a local privilege escalation bug via arbitrary system group
    addition to a local, logged in, homed-managed user
    Artifact: libsystemd0
    - Current version: 252.39-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libsystemd0/copyright, /var/lib/dpkg/info/libsystemd0:amd64.md5sums,
    /var/lib/dpkg/status
    Artifact: libudev1
    - Current version: 252.39-1~deb12u2
    - Vulnerable version(s): none (unknown)
    - Locations: /usr/share/doc/libudev1/copyright, /var/lib/dpkg/info/libudev1:amd64.md5sums,
    /var/lib/dpkg/status

### layer_scan

 STATUS SUMMARY

 [FAIL]   1 Critical Issues

 [WARN]   5 Warnings
 
 [SUPPRESSED] 0 Suppressed Findings

 CRITICAL FINDINGS:
  - No root user justification provided for root-running image.